import React, { useState, useEffect } from 'react';
import { FileText, Settings } from 'lucide-react';
import { FirmSettings, Product, SessionType, VoucherBill } from './types';
import {
  getCurrentSession,
  getStoredBills,
  getStoredFirmSettings,
  getStoredProducts,
  getTodayISODate,
  saveStoredBills,
  saveStoredFirmSettings,
  saveStoredProducts,
} from './utils/storage';
import { Header } from './components/Header';
import { TodayBillView } from './components/TodayBillView';
import { HistoryView } from './components/HistoryView';
import { DailyStockLaborView } from './components/DailyStockLaborView';
import { ReportView } from './components/ReportView';
import { DailyReportModal } from './components/DailyReportModal';
import { SettingsModal } from './components/SettingsModal';
import { DateRangePickerModal } from './components/DateRangePickerModal';
import { DriveBackupModal } from './components/DriveBackupModal';
import { AutoPrintStationModal } from './components/AutoPrintStationModal';
import { KantaEntryView } from './components/KantaEntryView';
import { KantaRecordsView } from './components/KantaRecordsView';
import { printReceiptDirectly } from './utils/directPrint';
import { isBluetoothConnected } from './utils/bluetoothPrinter';
import {
  subscribeToBills,
  syncBillToCloud,
  deleteBillFromCloud,
  enqueuePrintJob,
  KantaWeighment,
} from './utils/firebaseSync';
import { useAutoPrintStation } from './hooks/useAutoPrintStation';

export default function App() {
  // Directly load data
  const [products, setProducts] = useState<Product[]>(getStoredProducts);
  const [settings, setSettings] = useState<FirmSettings>(getStoredFirmSettings);
  const [bills, setBills] = useState<VoucherBill[]>(getStoredBills);

  // Active view: 'bill', 'kanta', 'kanta-records', 'history', 'labor', or 'report' (persisted across reloads / screen-off)
  const [currentView, setCurrentView] = useState<'bill' | 'kanta' | 'kanta-records' | 'history' | 'labor' | 'report'>(() => {
    try {
      const saved = localStorage.getItem('mandi_app_current_view');
      if (saved === 'bill' || saved === 'kanta' || saved === 'kanta-records' || saved === 'history' || saved === 'labor' || saved === 'report') {
        return saved;
      }
    } catch (e) {}
    return 'bill';
  });

  const handleSetCurrentView = (view: 'bill' | 'kanta' | 'kanta-records' | 'history' | 'labor' | 'report') => {
    setCurrentView(view);
    try {
      localStorage.setItem('mandi_app_current_view', view);
    } catch (e) {}
  };

  // Business Date and Auto-session (M: 12:00-1:30, A: 1:31-12:00)
  const [businessDate, setBusinessDate] = useState<string>(getTodayISODate);
  const [currentSession, setCurrentSession] = useState<SessionType>(getCurrentSession);

  // Date range for Report View (તારીખ ટુ તારીખ)
  const [reportStartDate, setReportStartDate] = useState<string>(getTodayISODate);
  const [reportEndDate, setReportEndDate] = useState<string>(getTodayISODate);
  const [isReportDatePickerOpen, setIsReportDatePickerOpen] = useState<boolean>(false);

  // Modals state
  const [showDailyReport, setShowDailyReport] = useState<boolean>(false);
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const [showDriveBackup, setShowDriveBackup] = useState<boolean>(false);

  const [selectedWeighmentForBill, setSelectedWeighmentForBill] = useState<KantaWeighment | null>(null);
  const [weighmentToEditInKanta, setWeighmentToEditInKanta] = useState<KantaWeighment | null>(null);

  // Auto-Print Station modal
  const [showAutoPrintStation, setShowAutoPrintStation] = useState<boolean>(false);

  const handleSaveSettings = (newSettings: FirmSettings) => {
    setSettings(newSettings);
    saveStoredFirmSettings(newSettings);
  };

  // Auto-Print Station Hook (for zero-touch remote printing in office)
  const {
    jobs: stationJobs,
    isBtConnected: stationBtConnected,
    btDeviceName: stationBtDeviceName,
    currentProcessingJob,
    stationToast,
    handleConnectPrinter: handleStationConnectPrinter,
    handleToggleStationMode,
    handleReprintJob,
    handleSendTestJob,
    handleDeleteJob,
  } = useAutoPrintStation(settings, handleSaveSettings);

  // Universal Direct Print (Zero-modal direct printing)
  const [printingBillId, setPrintingBillId] = useState<string | null>(null);
  const [printToastMsg, setPrintToastMsg] = useState<{ text: string; isError?: boolean } | null>(null);

  const handleDirectPrintBill = async (bill: VoucherBill) => {
    if (printingBillId) return; // Prevent concurrent clicks

    // If this mobile is NOT the print station, and local Bluetooth is not connected, but Cloud Remote Printing is enabled:
    // Enqueue to the office printer queue so office phone prints it!
    if (!settings.isAutoPrintStation && !isBluetoothConnected() && settings.cloudRemotePrintEnabled !== false) {
      setPrintingBillId(bill.id);
      setPrintToastMsg({ text: `📡 ઓફિસ પ્રિન્ટર પર મોકલાઈ રહ્યું છે...` });
      try {
        await enqueuePrintJob({
          type: 'bill',
          bill,
          title: `બિલ ${bill.billNoStr || bill.billNo} - ${bill.customerName}`,
          sourceDevice: 'મોબાઈલ',
        });
        setPrintToastMsg({ text: `✅ ઓફિસ પ્રિન્ટરમાં મોકલાઈ ગયું! (ત્યાં પ્રિન્ટ થઈ જશે)` });
        setTimeout(() => setPrintToastMsg(null), 3500);
        return;
      } catch (e: any) {
        console.warn('Enqueue failed, trying local direct print', e);
      } finally {
        setPrintingBillId(null);
      }
    }

    setPrintingBillId(bill.id);
    setPrintToastMsg({ text: `🖨️ બિલ ${bill.billNoStr || bill.billNo} પ્રિન્ટ થઈ રહ્યું છે...` });

    try {
      await printReceiptDirectly(bill, settings, (status) => {
        setPrintToastMsg({ text: status });
      });
      setPrintToastMsg({ text: `✅ બિલ ${bill.billNoStr || bill.billNo} પ્રિન્ટ સફળ!` });
      setTimeout(() => setPrintToastMsg(null), 3000);
    } catch (err: any) {
      const isUserCancel =
        err?.name === 'NotFoundError' ||
        err?.message?.includes('User cancelled') ||
        err?.message?.includes('કોઈ પ્રિન્ટર પસંદ કરવામાં આવ્યું નથી');
      const isIframeErr =
        err?.message === 'IFRAME_PERMISSION_ERROR' ||
        err?.name === 'SecurityError';

      if (isIframeErr) {
        console.warn('Direct print in iframe:', err);
      } else if (!isUserCancel) {
        console.warn('Direct print warning/error:', err);
        const errorText = `પ્રિન્ટિંગ એરર: ${err?.message || 'પ્રિન્ટર કનેક્ટ થઈ શક્યું નહીં. પ્રિન્ટર ચાલુ છે કે નહીં તે ચકાસો.'}`;
        setPrintToastMsg({ text: errorText, isError: true });
        setTimeout(() => setPrintToastMsg(null), 4500);
      } else {
        setPrintToastMsg(null);
      }
    } finally {
      setPrintingBillId(null);
    }
  };

  // Update business date and session every 30 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setBusinessDate(getTodayISODate());
      setCurrentSession(getCurrentSession());
    }, 30000);
    return () => clearInterval(timer);
  }, []);

  // Real-time Cloud sync for bills across multiple devices
  useEffect(() => {
    const unsubscribe = subscribeToBills((cloudBills) => {
      if (cloudBills && cloudBills.length > 0) {
        setBills((prevLocal) => {
          // Merge cloud bills with local bills by ID, prioritizing latest
          const billMap = new Map<string, VoucherBill>();
          prevLocal.forEach((b) => billMap.set(b.id, b));
          cloudBills.forEach((b) => billMap.set(b.id, b));
          const merged = Array.from(billMap.values()).sort((a, b) => b.createdAt - a.createdAt);
          saveStoredBills(merged);
          return merged;
        });
      }
    });

    return () => unsubscribe();
  }, []);

  const handleSaveBill = (newBill: VoucherBill, updatedProducts: Product[]) => {
    const nextBills = [newBill, ...bills];
    setBills(nextBills);
    saveStoredBills(nextBills);
    syncBillToCloud(newBill); // Real-time sync to Cloud

    setProducts(updatedProducts);
    saveStoredProducts(updatedProducts);
  };

  const handleDeleteBill = (id: string) => {
    const nextBills = bills.filter((b) => b.id !== id);
    setBills(nextBills);
    saveStoredBills(nextBills);
    deleteBillFromCloud(id); // Delete from Cloud
  };

  const handleUpdateBill = (updatedBill: VoucherBill) => {
    const nextBills = bills.map((b) => (b.id === updatedBill.id ? updatedBill : b));
    setBills(nextBills);
    saveStoredBills(nextBills);
    syncBillToCloud(updatedBill); // Update in Cloud
  };

  const handleSaveProducts = (newProducts: Product[]) => {
    setProducts(newProducts);
    saveStoredProducts(newProducts);
  };

  const handleRestoreData = (
    restoredBills: VoucherBill[],
    restoredProducts: Product[],
    restoredSettings: FirmSettings
  ) => {
    setBills(restoredBills);
    saveStoredBills(restoredBills);

    setProducts(restoredProducts);
    saveStoredProducts(restoredProducts);

    setSettings(restoredSettings);
    saveStoredFirmSettings(restoredSettings);
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans text-slate-800 selection:bg-emerald-100 selection:text-emerald-900">
      {/* Top Header with 3 horizontal lines (menu) button */}
      <Header
        businessDate={businessDate}
        settings={settings}
        activeView={currentView}
        onSelectView={(view) => handleSetCurrentView(view)}
        reportStartDate={reportStartDate}
        reportEndDate={reportEndDate}
        onReportStartDateChange={setReportStartDate}
        onReportEndDateChange={setReportEndDate}
        onOpenDatePicker={() => setIsReportDatePickerOpen(true)}
        onOpenDriveBackup={() => setShowDriveBackup(true)}
        onOpenSettings={() => setShowSettings(true)}
        onOpenAutoPrintStation={() => setShowAutoPrintStation(true)}
        isAutoPrintStation={Boolean(settings.isAutoPrintStation)}
      />

      {/* Main Content: Today's Bill Page, Kanta Entry, Kanta Records, History Page, or Daily Stock & Labor Summary Page */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-2 sm:p-4 lg:p-6">
        {currentView === 'kanta' ? (
          <KantaEntryView
            products={products}
            initialWeighmentToEdit={weighmentToEditInKanta}
            onClearInitialWeighmentToEdit={() => setWeighmentToEditInKanta(null)}
            onViewAllRecords={() => handleSetCurrentView('kanta-records')}
            onOpenBillForWeighment={(weighment) => {
              setSelectedWeighmentForBill(weighment);
              handleSetCurrentView('bill');
            }}
          />
        ) : currentView === 'kanta-records' ? (
          <KantaRecordsView
            bills={bills}
            onBack={() => handleSetCurrentView('kanta')}
            onBackToKanta={() => handleSetCurrentView('kanta')}
            onOpenBillForWeighment={(weighment) => {
              setSelectedWeighmentForBill(weighment);
              handleSetCurrentView('bill');
            }}
            onEditInSheet={(weighment) => {
              setWeighmentToEditInKanta(weighment);
              handleSetCurrentView('kanta');
            }}
            onEditInKanta={(weighment) => {
              setWeighmentToEditInKanta(weighment);
              handleSetCurrentView('kanta');
            }}
          />
        ) : currentView === 'history' ? (
          <HistoryView
            bills={bills}
            products={products}
            settings={settings}
            currentDate={businessDate}
            onBack={() => handleSetCurrentView('bill')}
            onOpenReceipt={handleDirectPrintBill}
            onDeleteBill={handleDeleteBill}
            onUpdateBill={handleUpdateBill}
          />
        ) : currentView === 'labor' ? (
          <DailyStockLaborView
            bills={bills}
            products={products}
            settings={settings}
            currentDate={businessDate}
            onBack={() => handleSetCurrentView('bill')}
          />
        ) : currentView === 'report' ? (
          <ReportView
            bills={bills}
            products={products}
            settings={settings}
            currentDate={businessDate}
            startDate={reportStartDate}
            endDate={reportEndDate}
            onStartDateChange={setReportStartDate}
            onEndDateChange={setReportEndDate}
            onOpenDatePicker={() => setIsReportDatePickerOpen(true)}
            onBack={() => handleSetCurrentView('bill')}
            onOpenReceipt={handleDirectPrintBill}
          />
        ) : (
          <TodayBillView
            businessDate={businessDate}
            currentSession={currentSession}
            products={products}
            settings={settings}
            bills={bills}
            initialWeighment={selectedWeighmentForBill}
            onClearInitialWeighment={() => setSelectedWeighmentForBill(null)}
            onSaveBill={handleSaveBill}
            onDeleteBill={handleDeleteBill}
            onSaveProducts={handleSaveProducts}
            onOpenReceipt={handleDirectPrintBill}
            onOpenReport={() => setCurrentView('report')}
            onGoToKanta={() => setCurrentView('kanta')}
          />
        )}
      </main>

      {/* Daily Report Modal */}
      {showDailyReport && (
        <DailyReportModal
          bills={bills}
          products={products}
          currentDate={businessDate}
          onClose={() => setShowDailyReport(false)}
          onOpenReceipt={(bill) => {
            handleDirectPrintBill(bill);
          }}
        />
      )}

      {/* Product & Firm Settings Modal */}
      {showSettings && (
        <SettingsModal
          products={products}
          settings={settings}
          onSaveProducts={handleSaveProducts}
          onSaveSettings={handleSaveSettings}
          onClose={() => setShowSettings(false)}
        />
      )}

      {/* Date Range Picker Modal for Report (1 થી 10 વગેરે તારીખ સિલેક્ટ કરવા) */}
      <DateRangePickerModal
        isOpen={isReportDatePickerOpen}
        startDate={reportStartDate}
        endDate={reportEndDate}
        onClose={() => setIsReportDatePickerOpen(false)}
        onApply={(start, end) => {
          setReportStartDate(start);
          setReportEndDate(end);
        }}
      />

      {/* Google Drive Backup & Restore Modal */}
      {showDriveBackup && (
        <DriveBackupModal
          bills={bills}
          products={products}
          settings={settings}
          onRestoreData={handleRestoreData}
          onClose={() => setShowDriveBackup(false)}
        />
      )}

      {/* Office Auto-Print Station Modal (રિમોટ ઑટો પ્રિન્ટિંગ કંટ્રોલ) */}
      {showAutoPrintStation && (
        <AutoPrintStationModal
          settings={settings}
          jobs={stationJobs}
          isBtConnected={stationBtConnected}
          btDeviceName={stationBtDeviceName}
          currentProcessingJob={currentProcessingJob}
          onClose={() => setShowAutoPrintStation(false)}
          onConnectPrinter={handleStationConnectPrinter}
          onToggleStationMode={handleToggleStationMode}
          onReprintJob={handleReprintJob}
          onSendTestJob={handleSendTestJob}
          onDeleteJob={handleDeleteJob}
        />
      )}

      {/* Floating Direct Print / Station Status Toast */}
      {(printToastMsg || stationToast) && (
        <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 animate-bounce-short pointer-events-none">
          <div
            className={`px-4 py-2.5 rounded-2xl shadow-xl text-xs sm:text-sm font-bold flex items-center gap-2.5 border ${
              (printToastMsg?.isError || stationToast?.isError)
                ? 'bg-rose-900 text-white border-rose-700 shadow-rose-950/40'
                : 'bg-slate-900 text-white border-slate-700 shadow-black/30'
            }`}
          >
            <span>{printToastMsg ? printToastMsg.text : stationToast?.text}</span>
          </div>
        </div>
      )}
    </div>
  );
}

