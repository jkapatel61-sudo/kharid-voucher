import React, { useState } from 'react';
import {
  Search,
  Receipt,
  Trash2,
  ArrowLeft,
  Edit3,
  Printer,
  CheckCircle2,
  X,
  AlertTriangle,
} from 'lucide-react';
import { FirmSettings, Product, VoucherBill } from '../types';
import { formatINR } from '../utils/storage';
import { EditBillModal } from './EditBillModal';

interface HistoryViewProps {
  bills: VoucherBill[];
  products: Product[];
  settings: FirmSettings;
  currentDate: string;
  onBack: () => void;
  onOpenReceipt: (bill: VoucherBill) => void;
  onDeleteBill?: (id: string) => void;
  onUpdateBill: (bill: VoucherBill) => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  bills,
  products,
  settings,
  currentDate,
  onBack,
  onOpenReceipt,
  onDeleteBill,
  onUpdateBill,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [editingBill, setEditingBill] = useState<VoucherBill | null>(null);
  const [billToDelete, setBillToDelete] = useState<VoucherBill | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Filter: ONLY Today's Day History (ખાલી આજના દિવસની હિસ્ટ્રી)
  const todayBills = bills.filter((b) => b.date === currentDate);

  const filteredBills = todayBills.filter((bill) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    const matchCustomer = bill.customerName.toLowerCase().includes(q);
    const matchBillNo =
      bill.billNoStr?.toLowerCase().includes(q) ||
      bill.billNo.toString().includes(q);
    const matchItem = bill.items?.some((it) =>
      it.productName.toLowerCase().includes(q)
    );
    return matchCustomer || matchBillNo || matchItem;
  });

  const handleSaveEditedBill = (updated: VoucherBill) => {
    onUpdateBill(updated);
    setToastMessage(`બિલ #${updated.billNoStr || updated.billNo} અપડેટ થઈ ગયું છે`);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleConfirmDelete = () => {
    if (!billToDelete) return;
    const deletedNo = billToDelete.billNoStr || billToDelete.billNo;
    if (onDeleteBill) {
      onDeleteBill(billToDelete.id);
    }
    setToastMessage(`બિલ #${deletedNo} ડિલીટ થઈ ગયું છે`);
    setTimeout(() => setToastMessage(null), 3500);
    setBillToDelete(null);
  };

  return (
    <div className="space-y-2 pb-10 animate-fade-in">
      {/* Compact Top Bar: Back button & Search input */}
      <div className="bg-white rounded-xl p-2 sm:p-2.5 shadow-2xs border border-slate-200 flex items-center gap-2">
        <button
          onClick={onBack}
          id="history-back-btn"
          className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 transition flex items-center gap-1 font-black text-xs shrink-0 active:scale-95 cursor-pointer shadow-2xs"
          title="નવા બિલ પર પાછા જાઓ"
        >
          <ArrowLeft className="w-3.5 h-3.5 text-emerald-800" />
          <span>નવું બિલ</span>
        </button>

        {/* Compact Search Input */}
        <div className="relative flex-1">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder="ગ્રાહકનું નામ અથવા બિલ નં. શોધો..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-7 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-slate-50 focus:bg-white transition"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Count badge */}
        <span className="text-[11px] font-bold text-slate-500 bg-slate-100 px-2 py-1 rounded-lg shrink-0">
          {filteredBills.length} બિલો
        </span>
      </div>

      {/* Success Toast Notice */}
      {toastMessage && (
        <div className="p-2.5 bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-md animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* High-Density Compact Bill List (વધુમાં વધુ એન્ટ્રીઓ સ્ક્રીન પર દેખાય તેવું કોમ્પેક્ટ લેઆઉટ) */}
      <div className="space-y-1.5">
        {filteredBills.length === 0 ? (
          <div className="bg-white rounded-xl p-8 text-center border border-dashed border-slate-300">
            <Receipt className="w-8 h-8 text-slate-300 mx-auto mb-1.5" />
            <p className="text-xs font-bold text-slate-600">આજે હજી સુધી કોઈ બિલ બનેલ નથી</p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              'નવું બિલ' પર ક્લિક કરી નવું વાઉચર બનાવો
            </p>
          </div>
        ) : (
          filteredBills.map((bill) => {
            return (
              <div
                key={bill.id}
                className="bg-white rounded-xl px-3 py-2 border border-slate-200 shadow-2xs hover:border-emerald-500 transition flex items-center justify-between gap-2"
              >
                {/* Left side: Bill #, Customer Name, Time & Items in a tight scannable row */}
                <div className="flex-1 min-w-0">
                  {/* Top row: Bill No, Customer Name, Time */}
                  <div className="flex items-center gap-2">
                    <span className="px-1.5 py-0.5 rounded-md bg-slate-900 text-white font-mono font-black text-[11px] shrink-0">
                      {bill.billNoStr}
                    </span>

                    <span className="font-black text-xs sm:text-sm text-slate-900 truncate">
                      {bill.customerName || 'સામાન્ય ગ્રાહક'}
                    </span>

                    <span className="text-[10px] text-slate-400 font-semibold shrink-0">
                      {bill.time}
                    </span>
                  </div>

                  {/* Bottom row: Compact Items string */}
                  <div className="text-[11px] text-slate-600 truncate mt-0.5 font-medium flex items-center gap-1.5">
                    {bill.items?.map((it, idx) => (
                      <span key={idx} className="inline-flex items-center gap-1">
                        <span className="font-semibold text-slate-800">{it.productName}</span>
                        <span className="font-mono text-emerald-800 font-bold">
                          {it.weightKg} kg
                        </span>
                        <span className="text-slate-400 text-[10px]">
                          ({it.ratePer20Kg})
                        </span>
                        {idx < (bill.items?.length || 0) - 1 && (
                          <span className="text-slate-300 mx-0.5">|</span>
                        )}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Right side: Amount & Action buttons in one compact horizontal block */}
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-xs sm:text-sm font-black text-emerald-800 font-mono">
                    {formatINR(bill.finalTotal)}
                  </span>

                  {/* DIRECT PRINT BUTTON */}
                  <button
                    type="button"
                    onClick={() => onOpenReceipt(bill)}
                    id={`history-print-btn-${bill.id}`}
                    className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-black text-xs flex items-center gap-1 shadow-2xs transition active:scale-95 cursor-pointer"
                    title="સીધી પ્રિન્ટ કરો"
                  >
                    <Printer className="w-3 h-3" />
                    <span className="text-[11px]">પ્રિન્ટ</span>
                  </button>

                  {/* EDIT BUTTON */}
                  <button
                    type="button"
                    onClick={() => setEditingBill(bill)}
                    id={`edit-bill-btn-${bill.id}`}
                    className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-black text-xs flex items-center gap-1 shadow-2xs transition active:scale-95 cursor-pointer"
                    title="બિલ એડિટ કરો"
                  >
                    <Edit3 className="w-3 h-3" />
                    <span className="text-[11px]">એડિટ</span>
                  </button>

                  {/* Delete button (Trash icon with comfortable touch area) */}
                  {onDeleteBill && (
                    <button
                      type="button"
                      onClick={() => setBillToDelete(bill)}
                      id={`delete-bill-btn-${bill.id}`}
                      className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition cursor-pointer active:scale-95 flex items-center justify-center"
                      title="બિલ ડિલીટ કરો"
                      aria-label="બિલ ડિલીટ કરો"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Delete Permission / Confirmation Modal (પરમિશન મોડલ: 'શું આ બિલ ડિલીટ કરવું છે?') */}
      {billToDelete && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-in fade-in duration-150"
          onClick={() => setBillToDelete(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 text-center space-y-4 animate-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Warning Icon */}
            <div className="w-13 h-13 rounded-full bg-red-100 text-red-600 mx-auto flex items-center justify-center shadow-inner">
              <AlertTriangle className="w-6 h-6 stroke-[2.5]" />
            </div>

            {/* Main Question / Title */}
            <div className="space-y-1">
              <h3 className="text-base sm:text-lg font-black text-slate-900 leading-tight">
                શું આ બિલ ડિલીટ કરવું છે?
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                આ બિલ લિસ્ટ અને હિસાબમાંથી કાયમ માટે રદ્દ થઈ જશે.
              </p>
            </div>

            {/* Bill Details Summary Card */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-left space-y-2 text-xs">
              <div className="flex items-center justify-between border-b border-slate-200 pb-1.5">
                <span className="text-slate-500 font-semibold">બિલ નં:</span>
                <span className="px-2 py-0.5 rounded bg-slate-900 text-white font-mono font-black text-xs">
                  {billToDelete.billNoStr || billToDelete.billNo}
                </span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-slate-500 font-semibold">ગ્રાહક:</span>
                <span className="font-bold text-slate-900 truncate max-w-[170px]">
                  {billToDelete.customerName || 'સામાન્ય ગ્રાહક'}
                </span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-slate-500 font-semibold">સમય:</span>
                <span className="font-medium text-slate-700">{billToDelete.time}</span>
              </div>

              <div className="flex items-center justify-between pt-1 border-t border-slate-200">
                <span className="text-slate-800 font-black">કુલ રકમ:</span>
                <span className="font-mono font-black text-emerald-800 text-sm">
                  {formatINR(billToDelete.finalTotal)}
                </span>
              </div>

              {billToDelete.items && billToDelete.items.length > 0 && (
                <div className="text-[11px] text-slate-600 bg-white p-2 rounded-lg border border-slate-200 space-y-0.5 max-h-24 overflow-y-auto">
                  {billToDelete.items.map((it, idx) => (
                    <div key={idx} className="flex justify-between items-center">
                      <span className="font-semibold text-slate-800">{it.productName}</span>
                      <span className="text-slate-600">
                        {it.weightKg} kg (@₹{it.ratePer20Kg})
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Action Buttons: Cancel vs Confirm Delete */}
            <div className="flex items-center gap-2.5 pt-1">
              <button
                type="button"
                id="cancel-delete-bill-btn"
                onClick={() => setBillToDelete(null)}
                className="flex-1 py-2.5 px-3 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold text-xs sm:text-sm transition cursor-pointer active:scale-95"
              >
                ના, રદ્દ કરો
              </button>

              <button
                type="button"
                id="confirm-delete-bill-btn"
                onClick={handleConfirmDelete}
                className="flex-1 py-2.5 px-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-md transition cursor-pointer active:scale-95"
              >
                <Trash2 className="w-4 h-4" />
                <span>હા, ડિલીટ કરો</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Bill Modal */}
      {editingBill && (
        <EditBillModal
          bill={editingBill}
          products={products}
          settings={settings}
          onClose={() => setEditingBill(null)}
          onSave={handleSaveEditedBill}
          onOpenReceipt={onOpenReceipt}
        />
      )}
    </div>
  );
};
