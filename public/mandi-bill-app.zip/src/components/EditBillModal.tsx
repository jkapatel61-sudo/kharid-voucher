import React, { useState, useEffect } from 'react';
import { X, Check, Trash2, Plus, Edit3, Printer, Loader2 } from 'lucide-react';
import { BillItem, FirmSettings, Product, VoucherBill } from '../types';
import { formatINR, formatDateDDMMYYYY } from '../utils/storage';
import { printReceiptDirectly } from '../utils/directPrint';

interface EditBillModalProps {
  bill: VoucherBill;
  products: Product[];
  settings?: FirmSettings;
  onClose: () => void;
  onSave: (updatedBill: VoucherBill) => void;
  onOpenReceipt?: (bill: VoucherBill) => void;
}

export const EditBillModal: React.FC<EditBillModalProps> = ({
  bill,
  products,
  settings,
  onClose,
  onSave,
}) => {
  // Always call all hooks unconditionally at top level
  const [customerName, setCustomerName] = useState(() => bill.customerName || '');
  const [items, setItems] = useState<BillItem[]>(() =>
    bill.items?.map((it) => ({ ...it })) || []
  );
  const [isPrinting, setIsPrinting] = useState(false);
  const [printStatus, setPrintStatus] = useState<string | null>(null);

  useEffect(() => {
    setCustomerName(bill.customerName || '');
    setItems(
      bill.items?.map((it) => ({
        ...it,
      })) || []
    );
  }, [bill]);

  // Handle item weight change
  const handleItemWeightChange = (index: number, val: string) => {
    const numWeight = parseFloat(val) || 0;
    setItems((prev) => {
      const next = [...prev];
      const item = { ...next[index], weightKg: numWeight };
      // auto calculate amount = round((weight / 20) * rate)
      if (item.ratePer20Kg > 0) {
        item.amount = Math.round((numWeight / 20) * item.ratePer20Kg);
      }
      next[index] = item;
      return next;
    });
  };

  // Handle item rate change
  const handleItemRateChange = (index: number, val: string) => {
    const numRate = parseFloat(val) || 0;
    setItems((prev) => {
      const next = [...prev];
      const item = { ...next[index], ratePer20Kg: numRate };
      if (item.weightKg > 0) {
        item.amount = Math.round((item.weightKg / 20) * numRate);
      }
      next[index] = item;
      return next;
    });
  };

  // Handle item manual amount change
  const handleItemAmountChange = (index: number, val: string) => {
    const numAmount = parseFloat(val) || 0;
    setItems((prev) => {
      const next = [...prev];
      next[index] = { ...next[index], amount: numAmount };
      return next;
    });
  };

  // Remove an item
  const handleRemoveItem = (index: number) => {
    if (items.length <= 1) {
      alert('ઓછામાં ઓછી એક આઇટમ રાખવી જરૂરી છે');
      return;
    }
    setItems((prev) => prev.filter((_, i) => i !== index));
  };

  // Add a product item
  const handleAddProduct = (prod: Product) => {
    const newItem: BillItem = {
      id: `item_${Date.now()}_${Math.random()}`,
      productId: prod.id,
      productName: prod.name,
      productShortcut: prod.shortcut,
      weightKg: 0,
      ratePer20Kg: prod.lastRatePer20Kg,
      amount: 0,
    };
    setItems((prev) => [...prev, newItem]);
  };

  // Calculate totals
  const totalWeightKg = items.reduce((sum, it) => sum + (it.weightKg || 0), 0);
  const totalWeightMan = Number((totalWeightKg / 20).toFixed(2));
  const totalAmount = items.reduce((sum, it) => sum + (it.amount || 0), 0);

  const handleSave = async (andPrint: boolean = false) => {
    if (items.length === 0) {
      alert('ઓછામાં ઓછી એક આઇટમ હોવી જરૂરી છે');
      return;
    }

    const updatedBill: VoucherBill = {
      ...bill,
      customerName: customerName.trim() || 'સામાન્ય ગ્રાહક',
      items: items,
      totalWeightKg: Math.round(totalWeightKg * 100) / 100,
      totalWeightMan,
      grossAmount: totalAmount,
      discountLess: 0,
      finalTotal: totalAmount,
    };

    if (andPrint) {
      setIsPrinting(true);
      setPrintStatus('પ્રિન્ટ મોકલાઈ રહી છે...');
      try {
        if (settings) {
          await printReceiptDirectly(updatedBill, settings, (st) => setPrintStatus(st));
        }
      } catch (err: any) {
        console.warn('Direct print error in edit modal:', err);
        const isUserCancel =
          err?.name === 'NotFoundError' ||
          err?.message?.includes('User cancelled') ||
          err?.message?.includes('કોઈ પ્રિન્ટર પસંદ કરવામાં આવ્યું નથી');

        if (!isUserCancel) {
          alert(
            err?.message === 'IFRAME_PERMISSION_ERROR'
              ? 'બ્લૂટૂથ પ્રિન્ટિંગ માટે એપ નવી ટેબમાં ખોલવી જરૂરી છે.'
              : `પ્રિન્ટિંગ એરર: ${err?.message || 'પ્રિન્ટર કનેક્ટ થઈ શક્યું નહીં.'}`
          );
        }
      } finally {
        setIsPrinting(false);
      }
    }

    onSave(updatedBill);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden flex flex-col max-h-[92vh] border border-slate-200">
        {/* Modal Header */}
        <div className="p-4 bg-amber-500 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center font-bold">
              <Edit3 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-black text-base leading-tight">
                બિલ એડિટ કરો ({bill.billNoStr})
              </h3>
              <p className="text-[11px] text-amber-100 font-semibold">
                સમય: {bill.time}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition"
          >
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
          {/* Customer Name */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 block">
              ગ્રાહકનું નામ:
            </label>
            <input
              type="text"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-sm focus:ring-2 focus:ring-amber-500 focus:outline-none"
              placeholder="ગ્રાહકનું નામ લખો..."
            />
          </div>

          {/* Items List */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 block">
                આઇટમ્સની વિગત (વજન, ભાવ અને રકમ):
              </label>
            </div>

            {items.map((it, idx) => (
              <div
                key={it.id || idx}
                className="p-3 bg-slate-50 border border-slate-200 rounded-2xl space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="font-black text-sm text-slate-900">
                    {idx + 1}. {it.productName}
                  </span>
                  {items.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveItem(idx)}
                      className="text-slate-400 hover:text-red-600 p-1 rounded-lg transition"
                      title="આઇટમ કાઢી નાખો"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <span className="text-[10px] font-bold text-slate-500 block mb-0.5">
                      વજન (kg)
                    </span>
                    <input
                      type="number"
                      step="any"
                      value={it.weightKg || ''}
                      onChange={(e) => handleItemWeightChange(idx, e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 font-mono font-bold text-sm bg-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
                      placeholder="0"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-500 block mb-0.5">
                      ભાવ (₹/૨૦kg)
                    </span>
                    <input
                      type="number"
                      step="any"
                      value={it.ratePer20Kg || ''}
                      onChange={(e) => handleItemRateChange(idx, e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 font-mono font-bold text-sm bg-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
                      placeholder="0"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-500 block mb-0.5">
                      રકમ (₹)
                    </span>
                    <input
                      type="number"
                      step="any"
                      value={it.amount || ''}
                      onChange={(e) => handleItemAmountChange(idx, e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 font-mono font-black text-sm bg-white text-emerald-800 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                      placeholder="0"
                    />
                  </div>
                </div>
              </div>
            ))}

            {/* Quick Add Product Dropdown / Chips */}
            <div className="pt-1">
              <span className="text-[11px] font-bold text-slate-500 block mb-1">
                + બીજી આઇટમ ઉમેરો:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {products.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => handleAddProduct(p)}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-800 border border-slate-200 rounded-lg text-xs font-bold transition flex items-center gap-1"
                  >
                    <Plus className="w-3 h-3" />
                    <span>{p.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Live Totals summary */}
          <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-2xl flex items-center justify-between">
            <div>
              <span className="text-[11px] font-bold text-emerald-800 block">
                કુલ વજન:
              </span>
              <span className="text-sm font-black text-emerald-950 font-mono">
                {totalWeightKg.toFixed(1)} kg
              </span>
            </div>
            <div className="text-right">
              <span className="text-[11px] font-bold text-emerald-800 block">
                કુલ રકમ:
              </span>
              <span className="text-base sm:text-lg font-black text-emerald-900 font-mono">
                {formatINR(totalAmount)}
              </span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-end gap-2">
          <button
            type="button"
            id="cancel-edit-bill-btn"
            disabled={isPrinting}
            onClick={onClose}
            className="px-3.5 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-100 transition cursor-pointer disabled:opacity-50"
          >
            રદ કરો
          </button>
          <button
            type="button"
            id="save-update-bill-btn"
            disabled={isPrinting}
            onClick={() => handleSave(false)}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-black text-white font-bold text-xs flex items-center gap-1.5 shadow-xs transition cursor-pointer disabled:opacity-50"
          >
            <Check className="w-4 h-4 text-emerald-400" />
            <span>સેવ કરો (Update)</span>
          </button>
          <button
            type="button"
            id="save-and-print-edit-bill-btn"
            disabled={isPrinting}
            onClick={() => handleSave(true)}
            className="px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-black text-xs flex items-center gap-1.5 shadow-sm transition cursor-pointer disabled:opacity-50"
          >
            {isPrinting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>{printStatus || 'પ્રિન્ટ થાય છે...'}</span>
              </>
            ) : (
              <>
                <Printer className="w-4 h-4" />
                <span>સેવ એન્ડ પ્રિન્ટ (Save & Print)</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
