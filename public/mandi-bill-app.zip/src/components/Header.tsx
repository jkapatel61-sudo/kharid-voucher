import React, { useState, useEffect } from 'react';
import {
  Menu,
  FilePlus2,
  History,
  X,
  ChevronRight,
  FileSpreadsheet,
  FileText,
  Calendar,
  Cloud,
  Settings,
  ExternalLink,
  DownloadCloud,
  Scale,
  Printer,
  Radio,
} from 'lucide-react';
import { FirmSettings } from '../types';

interface HeaderProps {
  businessDate: string;
  settings: FirmSettings;
  onSelectView: (view: 'bill' | 'kanta' | 'kanta-records' | 'history' | 'labor' | 'report') => void;
  activeView?: 'bill' | 'kanta' | 'kanta-records' | 'history' | 'labor' | 'report';
  reportStartDate?: string;
  reportEndDate?: string;
  onReportStartDateChange?: (date: string) => void;
  onReportEndDateChange?: (date: string) => void;
  onOpenDatePicker?: () => void;
  onOpenDriveBackup?: () => void;
  onOpenSettings?: () => void;
  onOpenAutoPrintStation?: () => void;
  isAutoPrintStation?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  businessDate,
  settings,
  onSelectView,
  activeView = 'bill',
  reportStartDate,
  reportEndDate,
  onReportStartDateChange,
  onReportEndDateChange,
  onOpenDatePicker,
  onOpenDriveBackup,
  onOpenSettings,
  onOpenAutoPrintStation,
  isAutoPrintStation,
}) => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(() => {
    // Check if already installed / standalone
    const checkStandalone = window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as any).standalone === true;
    setIsStandalone(checkStandalone);

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const choiceResult = await deferredPrompt.userChoice;
      if (choiceResult.outcome === 'accepted') {
        setDeferredPrompt(null);
      }
    } else {
      alert('ક્રોમ બ્રાઉઝરમાં ઉપર આપેલા ૩ ટપકાં (⋮) પર ક્લિક કરીને "Add to Home screen" (હોમ સ્ક્રીન પર ઉમેરો) દબાવો. તેનાથી એપ તમારા ફોનની હોમ સ્ક્રીન પર આવી જશે!');
    }
  };

  // Prevent background scrolling when slider drawer is open
  useEffect(() => {
    if (isDrawerOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isDrawerOpen]);

  const handleNavigate = (view: 'bill' | 'kanta' | 'kanta-records' | 'history' | 'labor' | 'report') => {
    onSelectView(view);
    setIsDrawerOpen(false);
  };

  return (
    <>
      {/* Main App Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex items-center justify-between">
          {/* Left side: 3-line Menu Button & Firm Header info */}
          <div className="flex items-center gap-3">
            {/* 3 Horizontal Lines (Menu) Icon Button to open Slider Page */}
            <button
              type="button"
              onClick={() => setIsDrawerOpen(true)}
              id="header-menu-btn"
              title="મેનૂ સ્લાઇડર ખોલો (Menu)"
              className="w-10 h-10 rounded-2xl flex items-center justify-center shadow-xs shrink-0 cursor-pointer transition active:scale-95 bg-emerald-700 text-white hover:bg-emerald-800"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div className="space-y-0.5">
              {activeView === 'kanta' ? (
                <h1 className="text-base sm:text-lg font-black text-slate-900 tracking-tight leading-tight">
                  કાંટા એન્ટ્રી (વજન & થેલીઓ)
                </h1>
              ) : activeView === 'kanta-records' ? (
                <h1 className="text-base sm:text-lg font-black text-slate-900 tracking-tight leading-tight">
                  આજના કાંટા વજન (પત્રક)
                </h1>
              ) : activeView === 'history' ? (
                <h1 className="text-base sm:text-lg font-black text-slate-900 tracking-tight leading-tight">
                  આજના દિવસ ના બિલો
                </h1>
              ) : activeView === 'labor' ? (
                <h1 className="text-base sm:text-lg font-black text-slate-900 tracking-tight leading-tight">
                  આજનો માલ સ્ટોક (પત્રક)
                </h1>
              ) : activeView === 'report' ? (
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight leading-tight">
                  રિપોર્ટ
                </h1>
              ) : (
                <>
                  {/* 1st Line: Firm Name */}
                  <h1 className="text-base sm:text-lg font-black text-slate-900 tracking-tight leading-tight">
                    {settings.firmName}
                  </h1>

                  {/* 2nd Line: ખરીદ વાઉચર */}
                  <p className="text-xs sm:text-sm font-bold text-emerald-800 leading-tight">
                    ખરીદ વાઉચર
                  </p>
                </>
              )}
            </div>
          </div>

          {/* Right: Actions */}
          <div className="flex items-center gap-2">
            {onOpenAutoPrintStation && (
              <button
                type="button"
                onClick={onOpenAutoPrintStation}
                id="header-auto-print-station-btn"
                title="ઓફિસ ઑટો-પ્રિન્ટ સ્ટેશન (Auto-Print Station)"
                className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-black shadow-xs transition cursor-pointer active:scale-95 whitespace-nowrap ${
                  isAutoPrintStation
                    ? 'bg-emerald-800 text-emerald-100 border border-emerald-500 shadow-emerald-900/20'
                    : 'bg-emerald-50/80 hover:bg-emerald-100 text-emerald-900 border border-emerald-200'
                }`}
              >
                <Printer className={`w-3.5 h-3.5 ${isAutoPrintStation ? 'text-emerald-300 animate-pulse' : 'text-emerald-700'}`} />
                <span className="hidden sm:inline">
                  {isAutoPrintStation ? 'ઓફિસ પ્રિન્ટર [ચાલુ]' : 'ઓફિસ પ્રિન્ટર'}
                </span>
                <span className="sm:hidden">
                  {isAutoPrintStation ? 'પ્રિન્ટર 🟢' : 'પ્રિન્ટર'}
                </span>
              </button>
            )}

            {activeView === 'report' && (
              <button
                type="button"
                onClick={onOpenDatePicker}
                id="header-report-calendar-btn"
                title="કેલેન્ડર"
                className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-black shadow-xs transition cursor-pointer active:scale-95 whitespace-nowrap"
              >
                <Calendar className="w-4 h-4 text-emerald-200 shrink-0" />
                <span>કેલેન્ડર</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* FULL SLIDER PAGE / NAVIGATION DRAWER (સ્લાઇડર પેજ) */}
      {/* Backdrop */}
      <div
        className={`fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 transition-opacity duration-300 ${
          isDrawerOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setIsDrawerOpen(false)}
        aria-hidden="true"
      />

      {/* Sliding Drawer Panel from Left */}
      <aside
        id="navigation-slider-drawer"
        className={`fixed inset-y-0 left-0 w-80 max-w-[85vw] bg-white z-50 shadow-2xl flex flex-col transition-transform duration-300 ease-out transform ${
          isDrawerOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Drawer Header - Compact Green Box without symbol and date */}
        <div className="px-4 py-3 bg-emerald-800 text-white flex items-center justify-between shadow-xs">
          <div className="pr-3">
            <h2 className="text-base font-black tracking-tight leading-tight">
              {settings.firmName}
            </h2>
            <p className="text-xs font-semibold text-emerald-200 mt-0.5">
              ખરીદ વાઉચર મેનેજર
            </p>
          </div>

          <button
            type="button"
            onClick={() => setIsDrawerOpen(false)}
            id="close-slider-btn"
            className="w-8 h-8 rounded-lg bg-white/15 hover:bg-white/25 flex items-center justify-center transition active:scale-95 text-white shrink-0 cursor-pointer"
            title="બંધ કરો (Close)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Drawer Navigation Links */}
        <div className="p-4 space-y-2 flex-1 overflow-y-auto">
          <p className="px-3 text-[11px] font-black uppercase tracking-wider text-slate-400 mb-2">
            મુખ્ય મેનૂ (Navigation)
          </p>

          {/* 1. નવું બિલ (New Bill) */}
          <button
            type="button"
            id="drawer-nav-new-bill"
            onClick={() => handleNavigate('bill')}
            className={`w-full p-3.5 rounded-2xl text-left flex items-center justify-between transition cursor-pointer active:scale-98 ${
              activeView === 'bill'
                ? 'bg-emerald-700 text-white shadow-md shadow-emerald-700/20'
                : 'bg-slate-50 hover:bg-emerald-50 text-slate-800'
            }`}
          >
            <div className="flex items-center gap-3.5">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                  activeView === 'bill'
                    ? 'bg-white/20 text-white'
                    : 'bg-emerald-100 text-emerald-800'
                }`}
              >
                <FilePlus2 className="w-5 h-5" />
              </div>
              <div>
                <span className="block font-black text-sm leading-tight">
                  નવું બિલ (ઓફિસ)
                </span>
                <span
                  className={`text-[11px] font-medium leading-tight block mt-0.5 ${
                    activeView === 'bill' ? 'text-emerald-100' : 'text-slate-500'
                  }`}
                >
                  ખરીદ વાઉચર બનાવો અને પ્રિન્ટ કરો
                </span>
              </div>
            </div>
            <ChevronRight
              className={`w-5 h-5 ${
                activeView === 'bill' ? 'text-white' : 'text-slate-400'
              }`}
            />
          </button>

          {/* 1.5. કાંટા એન્ટ્રી (Kanta Weighment Entry for Outside Table) */}
          <button
            type="button"
            id="drawer-nav-kanta"
            onClick={() => handleNavigate('kanta')}
            className={`w-full p-3.5 rounded-2xl text-left flex items-center justify-between transition cursor-pointer active:scale-98 ${
              activeView === 'kanta'
                ? 'bg-teal-800 text-white shadow-md shadow-teal-800/20'
                : 'bg-teal-50/70 hover:bg-teal-100/60 text-teal-950 border border-teal-200'
            }`}
          >
            <div className="flex items-center gap-3.5">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                  activeView === 'kanta'
                    ? 'bg-white/20 text-white'
                    : 'bg-teal-700 text-white shadow-xs'
                }`}
              >
                <Scale className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="block font-black text-sm leading-tight">
                    કાંટા એન્ટ્રી (બહાર ટેબલ)
                  </span>
                  <span className="text-[10px] bg-teal-200 text-teal-900 font-bold px-1.5 py-0.2 rounded">
                    મોબાઇલ ૨
                  </span>
                </div>
                <span
                  className={`text-[11px] font-medium leading-tight block mt-0.5 ${
                    activeView === 'kanta' ? 'text-teal-100' : 'text-teal-800'
                  }`}
                >
                  માણસ માટે થેલીઓ અને વજન નાખવા
                </span>
              </div>
            </div>
            <ChevronRight
              className={`w-5 h-5 ${
                activeView === 'kanta' ? 'text-white' : 'text-teal-700'
              }`}
            />
          </button>

          {/* 1.6. આજના કાંટા વજન પત્રક (Kanta Weighment Records) */}
          <button
            type="button"
            id="drawer-nav-kanta-records"
            onClick={() => handleNavigate('kanta-records')}
            className={`w-full p-3.5 rounded-2xl text-left flex items-center justify-between transition cursor-pointer active:scale-98 ${
              activeView === 'kanta-records'
                ? 'bg-teal-800 text-white shadow-md shadow-teal-800/20'
                : 'bg-teal-50/40 hover:bg-teal-100/60 text-teal-950 border border-teal-200/70'
            }`}
          >
            <div className="flex items-center gap-3.5">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                  activeView === 'kanta-records'
                    ? 'bg-white/20 text-white'
                    : 'bg-teal-100 text-teal-800'
                }`}
              >
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div>
                <span className="block font-black text-sm leading-tight">
                  આજના કાંટા વજન (પત્રક)
                </span>
                <span
                  className={`text-[11px] font-medium leading-tight block mt-0.5 ${
                    activeView === 'kanta-records' ? 'text-teal-100' : 'text-teal-700'
                  }`}
                >
                  કાંટા પર થયેલા તમામ વજનની યાદી
                </span>
              </div>
            </div>
            <ChevronRight
              className={`w-5 h-5 ${
                activeView === 'kanta-records' ? 'text-white' : 'text-teal-700'
              }`}
            />
          </button>

          {/* 2. આજના દિવસની હિસ્ટ્રી (Today's History) */}
          <button
            type="button"
            id="drawer-nav-today-history"
            onClick={() => handleNavigate('history')}
            className={`w-full p-3.5 rounded-2xl text-left flex items-center justify-between transition cursor-pointer active:scale-98 ${
              activeView === 'history'
                ? 'bg-emerald-700 text-white shadow-md shadow-emerald-700/20'
                : 'bg-slate-50 hover:bg-emerald-50 text-slate-800'
            }`}
          >
            <div className="flex items-center gap-3.5">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                  activeView === 'history'
                    ? 'bg-white/20 text-white'
                    : 'bg-amber-100 text-amber-800'
                }`}
              >
                <History className="w-5 h-5" />
              </div>
              <div>
                <span className="block font-black text-sm leading-tight">
                  આજના દિવસની હિસ્ટ્રી
                </span>
                <span
                  className={`text-[11px] font-medium leading-tight block mt-0.5 ${
                    activeView === 'history' ? 'text-emerald-100' : 'text-slate-500'
                  }`}
                >
                  આજના તમામ બિલોની યાદી
                </span>
              </div>
            </div>
            <ChevronRight
              className={`w-5 h-5 ${
                activeView === 'history' ? 'text-white' : 'text-slate-400'
              }`}
            />
          </button>

          {/* 3. આજનો માલ સ્ટોક (Daily Goods Stock Summary) - હિસ્ટ્રી ની નીચે મૂકો */}
          <button
            type="button"
            id="drawer-nav-stock-labor"
            onClick={() => handleNavigate('labor')}
            className={`w-full p-3.5 rounded-2xl text-left flex items-center justify-between transition cursor-pointer active:scale-98 ${
              activeView === 'labor'
                ? 'bg-emerald-700 text-white shadow-md shadow-emerald-700/20'
                : 'bg-slate-50 hover:bg-emerald-50 text-slate-800'
            }`}
          >
            <div className="flex items-center gap-3.5">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                  activeView === 'labor'
                    ? 'bg-white/20 text-white'
                    : 'bg-emerald-100 text-emerald-800'
                }`}
              >
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div>
                <span className="block font-black text-sm leading-tight">
                  આજનો માલ સ્ટોક (પત્રક)
                </span>
                <span
                  className={`text-[11px] font-medium leading-tight block mt-0.5 ${
                    activeView === 'labor' ? 'text-emerald-100' : 'text-slate-500'
                  }`}
                >
                  ભાવવાર અનાજ/માલ ખરીદીની વિગત
                </span>
              </div>
            </div>
            <ChevronRight
              className={`w-5 h-5 ${
                activeView === 'labor' ? 'text-white' : 'text-slate-400'
              }`}
            />
          </button>

          {/* 4. રિપોર્ટ (દૈનિક અને જૂના રિપોર્ટ - જેથી જૂનું રિપોર્ટ જોઈ શકાય) */}
          <button
            type="button"
            id="drawer-nav-report"
            onClick={() => handleNavigate('report')}
            className={`w-full p-3.5 rounded-2xl text-left flex items-center justify-between transition cursor-pointer active:scale-98 ${
              activeView === 'report'
                ? 'bg-emerald-700 text-white shadow-md shadow-emerald-700/20'
                : 'bg-slate-50 hover:bg-emerald-50 text-slate-800'
            }`}
          >
            <div className="flex items-center gap-3.5">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                  activeView === 'report'
                    ? 'bg-white/20 text-white'
                    : 'bg-blue-100 text-blue-800'
                }`}
              >
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <span className="block font-black text-sm leading-tight">
                  રિપોર્ટ
                </span>
                <span
                  className={`text-[11px] font-medium leading-tight block mt-0.5 ${
                    activeView === 'report' ? 'text-emerald-100' : 'text-slate-500'
                  }`}
                >
                  તારીખવાર જૂના અને આજના રિપોર્ટ
                </span>
              </div>
            </div>
            <ChevronRight
              className={`w-5 h-5 ${
                activeView === 'report' ? 'text-white' : 'text-slate-400'
              }`}
            />
          </button>

          {/* 5. Google Drive બેકઅપ & રીસ્ટોર */}
          {onOpenDriveBackup && (
            <button
              type="button"
              id="drawer-nav-drive-backup"
              onClick={() => {
                setIsDrawerOpen(false);
                onOpenDriveBackup();
              }}
              className="w-full p-3.5 rounded-2xl text-left flex items-center justify-between transition cursor-pointer active:scale-98 bg-emerald-50/70 hover:bg-emerald-100/80 text-emerald-950 border border-emerald-200/60"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 bg-emerald-600 text-white shadow-xs">
                  <Cloud className="w-5 h-5" />
                </div>
                <div>
                  <span className="block font-black text-sm leading-tight text-emerald-900">
                    Google Drive બેકઅપ
                  </span>
                  <span className="text-[11px] font-medium leading-tight block mt-0.5 text-emerald-700">
                    ડેટા સુરક્ષિત સાચવો & રીસ્ટોર કરો
                  </span>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-emerald-600" />
            </button>
          )}

          {/* 5.5. ઓફિસ ઑટો-પ્રિન્ટ સ્ટેશન (Auto-Print Station) */}
          {onOpenAutoPrintStation && (
            <button
              type="button"
              id="drawer-nav-auto-print-station"
              onClick={() => {
                setIsDrawerOpen(false);
                onOpenAutoPrintStation();
              }}
              className={`w-full p-3.5 rounded-2xl text-left flex items-center justify-between transition cursor-pointer active:scale-98 ${
                isAutoPrintStation
                  ? 'bg-emerald-100/90 hover:bg-emerald-100 text-emerald-950 border border-emerald-400 shadow-2xs'
                  : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border border-slate-200'
              }`}
            >
              <div className="flex items-center gap-3.5">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 shadow-xs ${
                    isAutoPrintStation ? 'bg-emerald-700 text-white animate-pulse' : 'bg-slate-700 text-white'
                  }`}
                >
                  <Printer className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="block font-black text-sm leading-tight text-slate-900">
                      ઓફિસ ઑટો-પ્રિન્ટ સ્ટેશન
                    </span>
                    {isAutoPrintStation ? (
                      <span className="text-[10px] font-black bg-emerald-700 text-white px-1.5 py-0.2 rounded">
                        ચાલુ
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold bg-slate-200 text-slate-700 px-1.5 py-0.2 rounded">
                        સેટ કરો
                      </span>
                    )}
                  </div>
                  <span className="text-[11px] font-medium leading-tight block mt-0.5 text-slate-600">
                    બીજા મોબાઈલના બિલ આપોઆપ અહીં પ્રિન્ટ થશે
                  </span>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-400" />
            </button>
          )}

          {/* 6. સેટિંગ્સ (Settings) */}
          {onOpenSettings && (
            <button
              type="button"
              id="drawer-nav-settings"
              onClick={() => {
                setIsDrawerOpen(false);
                onOpenSettings();
              }}
              className="w-full p-3.5 rounded-2xl text-left flex items-center justify-between transition cursor-pointer active:scale-98 bg-slate-100 hover:bg-slate-200/80 text-slate-900 border border-slate-300 shadow-2xs"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 bg-slate-800 text-white shadow-xs">
                  <Settings className="w-5 h-5" />
                </div>
                <div>
                  <span className="block font-black text-sm leading-tight text-slate-900">
                    સેટિંગ્સ (Settings)
                  </span>
                  <span className="text-[11px] font-semibold leading-tight block mt-0.5 text-slate-600">
                    પેઢી વિગત, માલ યાદી & થર્મલ પ્રિન્ટર
                  </span>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-500" />
            </button>
          )}
          {/* 7. એપ ઇન્સ્ટોલ કરો / હોમ સ્ક્રીન પર ઉમેરો (જો પહેલાથી ઇન્સ્ટોલ ન હોય તો) */}
          {!isStandalone && (
            <button
              type="button"
              id="drawer-install-pwa-btn"
              onClick={handleInstallClick}
              className="w-full p-3.5 rounded-2xl text-left flex items-center justify-between transition cursor-pointer active:scale-98 bg-amber-50 hover:bg-amber-100 text-amber-950 border border-amber-200 shadow-2xs mt-2"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 bg-amber-600 text-white shadow-xs">
                  <DownloadCloud className="w-5 h-5" />
                </div>
                <div>
                  <span className="block font-black text-sm leading-tight text-amber-950">
                    ફોનમાં એપ ઇન્સ્ટોલ કરો
                  </span>
                  <span className="text-[11px] font-semibold leading-tight block mt-0.5 text-amber-700">
                    ક્રોમ પટ્ટી વગર ફૂલ સ્ક્રીનમાં વાપરવા
                  </span>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-amber-600" />
            </button>
          )}

          {/* 8. નવી ટેબમાં ખોલો (Open in New Tab for Bluetooth Printing) */}
          <a
            href={window.location.href}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full p-3 rounded-xl text-left flex items-center justify-between transition cursor-pointer active:scale-98 bg-blue-50/80 hover:bg-blue-100 text-blue-950 border border-blue-200 mt-2"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0 bg-blue-600 text-white shadow-xs">
                <ExternalLink className="w-4 h-4" />
              </div>
              <div>
                <span className="block font-black text-xs leading-tight text-blue-900">
                  નવી ટેબમાં એપ ખોલો
                </span>
                <span className="text-[10px] font-semibold leading-tight block mt-0.5 text-blue-700">
                  બ્લૂટૂથ પ્રિન્ટર સીધું વાપરવા માટે
                </span>
              </div>
            </div>
            <ExternalLink className="w-4 h-4 text-blue-500" />
          </a>
        </div>

      </aside>
    </>
  );
};
