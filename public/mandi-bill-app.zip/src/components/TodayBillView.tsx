import React, { useState, useEffect, useRef } from 'react';
import {
  Printer,
  XCircle,
  X,
  Calendar,
  Clock,
  Save,
  Check,
  Plus,
  Loader2,
  Bluetooth,
  RefreshCw,
  Scale,
  Eye,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { BillItem, FirmSettings, Product, SessionType, VoucherBill, WeighmentSlipData } from '../types';
import {
  formatINR,
  getNextBillNo,
  formatDayMonthOnly,
} from '../utils/storage';
import { WeighmentDetailModal } from './WeighmentDetailModal';
import {
  isWebBluetoothSupported,
  isBluetoothConnected,
  subscribeBluetoothStatus,
  attemptSilentReconnect,
  ensureConnectedPrinter,
  requestWakeLock,
} from '../utils/bluetoothPrinter';
import { printReceiptDirectly, printWeighmentDirectly } from '../utils/directPrint';
import { AddItemModal } from './AddItemModal';
import { VoiceBillingBar } from './VoiceBillingBar';
import {
  KantaWeighment,
  subscribeToWeighments,
  updateWeighmentStatus,
  enqueuePrintJob,
} from '../utils/firebaseSync';

const BILL_DRAFT_KEY = 'mandi_bill_active_draft_v1';

const getStoredBillDraft = () => {
  try {
    const raw = localStorage.getItem(BILL_DRAFT_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (e) {
    return null;
  }
};

interface TodayBillViewProps {
  businessDate: string;
  currentSession: SessionType;
  products: Product[];
  settings: FirmSettings;
  bills: VoucherBill[];
  initialWeighment?: KantaWeighment | null;
  onClearInitialWeighment?: () => void;
  onSaveBill: (bill: VoucherBill, updatedProducts: Product[]) => void;
  onDeleteBill?: (id: string) => void;
  onSaveProducts?: (products: Product[]) => void;
  onOpenReceipt: (bill: VoucherBill) => void;
  onOpenReport?: () => void;
  onGoToKanta?: () => void;
}

export const TodayBillView: React.FC<TodayBillViewProps> = ({
  businessDate,
  currentSession,
  products,
  settings,
  bills,
  initialWeighment,
  onClearInitialWeighment,
  onSaveBill,
  onOpenReceipt,
  onSaveProducts,
  onGoToKanta,
}) => {
  const initialBillDraft = useRef(getStoredBillDraft()).current;

  // Form State
  const [customerName, setCustomerName] = useState(() => initialBillDraft?.customerName || '');
  const [voiceResetKey, setVoiceResetKey] = useState(0);
  const [attachedWeighmentId, setAttachedWeighmentId] = useState<string | null>(() => initialBillDraft?.attachedWeighmentId || null);
  const [attachedWeighmentIds, setAttachedWeighmentIds] = useState<string[]>(() => {
    if (initialBillDraft?.attachedWeighmentIds && Array.isArray(initialBillDraft.attachedWeighmentIds)) {
      return initialBillDraft.attachedWeighmentIds;
    }
    return initialBillDraft?.attachedWeighmentId ? [initialBillDraft.attachedWeighmentId] : [];
  });

  // Cloud Kanta Weighments (બહાર કાંટા પરથી આવેલા વજન)
  const [pendingWeighments, setPendingWeighments] = useState<KantaWeighment[]>([]);
  const [allWeighments, setAllWeighments] = useState<KantaWeighment[]>([]);
  const [viewingKantaWeighment, setViewingKantaWeighment] = useState<KantaWeighment | null>(null);
  const [isKantaExpanded, setIsKantaExpanded] = useState<boolean>(false);
  const lastSavedBillRef = useRef<VoucherBill | null>(null);
  const lastSavedWeighmentsRef = useRef<KantaWeighment[]>([]);
  const [isWeightPrinting, setIsWeightPrinting] = useState(false);

  useEffect(() => {
    const unsub = subscribeToWeighments((list) => {
      setAllWeighments(list);
      const pending = list.filter((w) => w.status === 'pending');
      setPendingWeighments(pending);
    });
    return () => unsub();
  }, []);
  // Direct Print state & live Bluetooth status
  const [isDirectPrinting, setIsDirectPrinting] = useState(false);
  const [directPrintStatus, setDirectPrintStatus] = useState<string | null>(null);
  const [btConnected, setBtConnected] = useState<boolean>(() => isBluetoothConnected());
  const [isBtConnecting, setIsBtConnecting] = useState(false);

  useEffect(() => {
    // Keep screen awake while billing page is active
    requestWakeLock();

    // Subscribe to real-time Bluetooth connection status changes
    const unsubscribe = subscribeBluetoothStatus((connected) => {
      setBtConnected(connected);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  // Active product IDs whose input boxes are open
  const [activeProductIds, setActiveProductIds] = useState<string[]>(() => initialBillDraft?.activeProductIds || []);

  // Horizontal sliding carousel ref and active slide tracker
  const productSliderRef = useRef<HTMLDivElement>(null);
  const [activeSlide, setActiveSlide] = useState(0);

  // Real-time live clock ticker (updates every second)
  const [currentTime, setCurrentTime] = useState<Date>(() => new Date());
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // 1. Cleaned products: strictly preserves custom order from Settings
  const cleanProducts = React.useMemo(() => {
    return (products || []).filter(
      (p) => p && p.name !== 'ડાંગર' && p.id !== 'p_dangar'
    );
  }, [products]);

  // Modal to add new item
  const [showAddItemModal, setShowAddItemModal] = useState(false);

  const handleAddNewProduct = (newProduct: Product) => {
    const updated = [...cleanProducts, newProduct];
    if (onSaveProducts) {
      onSaveProducts(updated);
    }
    handleProductToggle(newProduct);
  };

  // Build slides:
  // - Slide 1 (પહેલી સ્લાઇડ): The first 4 products in cleanProducts (મુખ્ય સ્ક્રીન)
  // - Slide 2 (બીજી સ્લાઇડ): The remaining products + [+ એડ આઇટમ] button!
  const slides = React.useMemo(() => {
    type GridSlot =
      | { type: 'product'; product: Product }
      | { type: 'add_button' }
      | { type: 'empty' };

    const slide1Prods = cleanProducts.slice(0, 4);
    const remainingProds = cleanProducts.slice(4);

    const pages: { slots: GridSlot[] }[] = [];

    // Slide 1: exactly the first 4 products
    const page1Slots: GridSlot[] = slide1Prods.map((p) => ({ type: 'product', product: p }));
    while (page1Slots.length < 4) {
      page1Slots.push({ type: 'empty' });
    }
    pages.push({ slots: page1Slots });

    // Secondary slide(s): remaining products + [+ એડ આઇટમ] button
    let currIdx = 0;
    while (currIdx < remainingProds.length || pages.length < 2) {
      const pageSlots: GridSlot[] = [];
      // Take up to 3 products so there's always space for [+ એડ આઇટમ]
      while (pageSlots.length < 3 && currIdx < remainingProds.length) {
        pageSlots.push({ type: 'product', product: remainingProds[currIdx++] });
      }

      // If no more products left, add [+ એડ આઇટમ]
      if (currIdx >= remainingProds.length) {
        pageSlots.push({ type: 'add_button' });
      } else if (pageSlots.length < 4) {
        pageSlots.push({ type: 'product', product: remainingProds[currIdx++] });
      }

      while (pageSlots.length < 4) {
        pageSlots.push({ type: 'empty' });
      }

      pages.push({ slots: pageSlots });

      if (currIdx >= remainingProds.length) {
        break;
      }
    }

    return pages;
  }, [cleanProducts]);

  const totalSlides = slides.length;

  const handleSliderScroll = () => {
    if (productSliderRef.current) {
      const scrollLeft = productSliderRef.current.scrollLeft;
      const width = productSliderRef.current.clientWidth;
      if (width > 0) {
        const index = Math.round(scrollLeft / width);
        setActiveSlide(index);
      }
    }
  };

  // Input states (weight, rate, amount) for each product
  const [productInputs, setProductInputs] = useState<
    Record<string, { weight: string; rate: string; amount?: string }>
  >(() => {
    const init: Record<string, { weight: string; rate: string; amount?: string }> = {};
    (products || []).forEach((p) => {
      const draftVal = initialBillDraft?.productInputs?.[p.id];
      init[p.id] = {
        weight: draftVal?.weight || '',
        rate: draftVal?.rate || p.lastRatePer20Kg.toString(),
        amount: draftVal?.amount || '',
      };
    });
    return init;
  });

  // Keep draft updated in localStorage so mobile screen-off or reload never loses entered values
  useEffect(() => {
    const hasAny =
      customerName.trim().length > 0 ||
      activeProductIds.length > 0 ||
      Object.values(productInputs).some((v: { weight: string }) => v?.weight && v.weight.trim().length > 0);

    if (hasAny) {
      try {
        localStorage.setItem(
          BILL_DRAFT_KEY,
          JSON.stringify({
            customerName,
            activeProductIds,
            productInputs,
            attachedWeighmentId,
            attachedWeighmentIds,
          })
        );
      } catch (e) {}
    }
  }, [customerName, activeProductIds, productInputs, attachedWeighmentId, attachedWeighmentIds]);

  // Handle incoming weighment if opened directly from Kanta view
  useEffect(() => {
    if (initialWeighment) {
      handleAttachWeighment(initialWeighment);
      if (onClearInitialWeighment) {
        onClearInitialWeighment();
      }
    }
  }, [initialWeighment]);

  // Attach a single weighment from outside Kanta to current bill (merges if same customer)
  const handleAttachWeighment = (w: KantaWeighment) => {
    const isSameCustomer =
      !customerName.trim() ||
      customerName.trim().toLowerCase() === (w.customerName || '').trim().toLowerCase();

    const targetProd = cleanProducts.find((p) => p.id === w.productId) || cleanProducts[0];

    if (isSameCustomer) {
      if (!customerName.trim()) {
        setCustomerName(w.customerName);
      }
      if (targetProd) {
        setActiveProductIds((prev) => Array.from(new Set([...prev, targetProd.id])));
        setProductInputs((prev) => ({
          ...prev,
          [targetProd.id]: {
            weight: w.totalWeightKg.toString(),
            rate: w.ratePer20Kg.toString(),
            amount: w.calculatedAmount.toString(),
          },
        }));
      }
      setAttachedWeighmentIds((prev) => Array.from(new Set([...prev, w.id])));
    } else {
      // Different customer name: replace with this customer's details
      setCustomerName(w.customerName);
      setAttachedWeighmentIds([w.id]);
      if (targetProd) {
        setActiveProductIds([targetProd.id]);
        setProductInputs({
          [targetProd.id]: {
            weight: w.totalWeightKg.toString(),
            rate: w.ratePer20Kg.toString(),
            amount: w.calculatedAmount.toString(),
          },
        });
      }
    }
  };

  // Attach ALL pending weighments for a customer into 1 single comprehensive bill
  const handleAttachAllForCustomer = (weighmentsForCust: KantaWeighment[]) => {
    if (weighmentsForCust.length === 0) return;
    const custName = weighmentsForCust[0].customerName;
    setCustomerName(custName);

    const newProdIds: string[] = [];
    const newInputs: Record<string, { weight: string; rate: string; amount?: string }> = { ...productInputs };
    const newAttachedIds: string[] = [...attachedWeighmentIds];

    weighmentsForCust.forEach((w) => {
      const targetProd = cleanProducts.find((p) => p.id === w.productId) || cleanProducts[0];
      if (targetProd) {
        newProdIds.push(targetProd.id);
        newInputs[targetProd.id] = {
          weight: w.totalWeightKg.toString(),
          rate: w.ratePer20Kg.toString(),
          amount: w.calculatedAmount.toString(),
        };
      }
      newAttachedIds.push(w.id);
    });

    setActiveProductIds(Array.from(new Set([...activeProductIds, ...newProdIds])));
    setProductInputs(newInputs);
    setAttachedWeighmentIds(Array.from(new Set(newAttachedIds)));
  };

  // Group pending weighments by customer name for clear visibility
  const groupedPendingWeighments = React.useMemo(() => {
    const map = new Map<string, { customerName: string; weighments: KantaWeighment[] }>();
    pendingWeighments.forEach((w) => {
      const key = (w.customerName || 'સામાન્ય ખેડૂત').trim().toLowerCase();
      if (!map.has(key)) {
        map.set(key, { customerName: w.customerName || 'સામાન્ય ખેડૂત', weighments: [] });
      }
      map.get(key)!.weighments.push(w);
    });
    return Array.from(map.values());
  }, [pendingWeighments]);

  // Ensure all products have initial rates in state
  useEffect(() => {
    setProductInputs((prev) => {
      const updated = { ...prev };
      let changed = false;
      cleanProducts.forEach((p) => {
        if (!updated[p.id]) {
          updated[p.id] = { weight: '', rate: p.lastRatePer20Kg.toString(), amount: '' };
          changed = true;
        }
      });
      return changed ? updated : prev;
    });
  }, [cleanProducts]);

  const customerInputRef = useRef<HTMLInputElement>(null);

  // Function to remove/close an item and reset its weight and amount
  const handleRemoveProduct = (productId: string) => {
    setActiveProductIds((prev) => prev.filter((id) => id !== productId));
    setProductInputs((prev) => {
      const current = prev[productId];
      const prod = cleanProducts.find((p) => p.id === productId);
      const defRate = prod ? prod.lastRatePer20Kg.toString() : current?.rate || '';
      return {
        ...prev,
        [productId]: {
          weight: '',
          rate: defRate,
          amount: '',
        },
      };
    });
  };

  // Toggle product open / close (Tik / select item first)
  const handleProductToggle = (p: Product) => {
    setActiveProductIds((prev) => {
      if (prev.includes(p.id)) {
        // Close and clear if already open
        handleRemoveProduct(p.id);
        return prev.filter((id) => id !== p.id);
      } else {
        return [...prev, p.id];
      }
    });

    // Make sure rate is populated
    setProductInputs((prev) => {
      if (!prev[p.id] || !prev[p.id].rate) {
        return {
          ...prev,
          [p.id]: {
            weight: '',
            rate: p.lastRatePer20Kg.toString(),
            amount: '',
          },
        };
      }
      return prev;
    });
  };

  // Helper to render individual product selection button
  const renderProductButton = (p: Product) => {
    const isOpen = activeProductIds.includes(p.id);
    return (
      <button
        key={p.id}
        type="button"
        id={`product-select-${p.id}`}
        onClick={() => handleProductToggle(p)}
        className={`h-16 sm:h-17 py-2 px-2 rounded-xl border text-center transition flex flex-col items-center justify-center gap-0.5 cursor-pointer select-none active:scale-95 shadow-2xs ${
          isOpen
            ? 'bg-emerald-700 text-white border-emerald-800 ring-2 ring-emerald-600/30'
            : 'bg-white text-slate-800 border-slate-300 hover:border-emerald-500 hover:bg-slate-50'
        }`}
      >
        <span className="font-black text-sm sm:text-base leading-tight truncate max-w-full px-1">
          {p.name}
        </span>
        <span
          className={`font-mono font-bold text-xs sm:text-sm leading-tight ${
            isOpen ? 'text-emerald-100' : 'text-slate-500'
          }`}
        >
          ₹{p.lastRatePer20Kg}
        </span>
      </button>
    );
  };

  // When Enter is pressed in customer name, move down to selected item's rate box (or weight if rate not present)
  const handleCustomerEnter = () => {
    const targetId = activeProductIds[0];
    if (targetId) {
      setTimeout(() => {
        const rateEl = document.getElementById(`rate-input-${targetId}`) as HTMLInputElement | null;
        if (rateEl) {
          rateEl.focus();
          rateEl.select();
        } else {
          const weightEl = document.getElementById(`weight-input-${targetId}`) as HTMLInputElement | null;
          if (weightEl) {
            weightEl.focus();
            weightEl.select();
          }
        }
      }, 50);
    } else {
      // If user hasn't ticked an item yet, inform them gently
      alert('કૃપા કરીને પહેલા આઇટમ ટીક (પસંદ) કરો.');
    }
  };

  const handleProductInputChange = (
    pId: string,
    field: 'weight' | 'rate' | 'amount',
    val: string
  ) => {
    setProductInputs((prev) => {
      const current = prev[pId] || { weight: '', rate: '', amount: '' };
      const next = { ...current, [field]: val };

      // If user altered weight or rate, auto-calculate amount
      if (field === 'weight' || field === 'rate') {
        const w = parseFloat(next.weight) || 0;
        const r = parseFloat(next.rate) || 0;
        if (w > 0 && r > 0) {
          next.amount = Math.round((w / 20) * r).toString();
        } else {
          next.amount = '';
        }
      }

      return {
        ...prev,
        [pId]: next,
      };
    });
  };

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const activeTag = document.activeElement?.tagName?.toLowerCase();
      const isInputFocused =
        activeTag === 'input' || activeTag === 'textarea' || activeTag === 'select';

      const key = e.key ? e.key.toLowerCase() : '';

      // Check if this key matches any product shortcut
      const matchedProduct = key
        ? cleanProducts.find(
            (p) => (p.shortcut || '').toLowerCase() === key
          )
        : undefined;

      if (matchedProduct) {
        if (!isInputFocused || e.altKey) {
          e.preventDefault();
          handleProductToggle(matchedProduct);
        }
      }

      // F2 to quick-save
      if (e.key === 'F2') {
        e.preventDefault();
        handleSubmit(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [cleanProducts, activeProductIds, productInputs, customerName, currentSession]);

  // Compile full list of items from all active products where weight & rate > 0
  const getBillItems = (): BillItem[] => {
    const result: BillItem[] = [];
    activeProductIds.forEach((pId) => {
      const prod = cleanProducts.find((x) => x.id === pId);
      const inp = productInputs[pId];
      if (!prod || !inp) return;
      const w = parseFloat(inp.weight) || 0;
      const r = parseFloat(inp.rate) || 0;
      const customA = parseFloat(inp.amount || '');
      const calcA = Math.round((w / 20) * r);
      const finalAmt = !isNaN(customA) && customA > 0 ? customA : calcA;
      if (w > 0 && r > 0) {
        result.push({
          id: `item_${Date.now()}_${pId}`,
          productId: prod.id,
          productName: prod.name,
          productShortcut: prod.shortcut,
          weightKg: w,
          ratePer20Kg: r,
          amount: finalAmt,
        });
      }
    });
    return result;
  };

  const currentBillItems = getBillItems();
  const totalBillAmount = currentBillItems.reduce((acc, it) => acc + it.amount, 0);

  const currentBillNo = getNextBillNo(bills, businessDate, currentSession);

  // Submit bill
  const handleSubmit = (
    autoPrint: boolean = settings.autoPrintOnSave,
    overrideCustomerName?: string,
    overrideBillItems?: BillItem[]
  ) => {
    const billItems =
      overrideBillItems && overrideBillItems.length > 0
        ? overrideBillItems
        : getBillItems();

    if (billItems.length === 0) {
      alert('કૃપા કરીને વજન (kg) દાખલ કરો.');
      return;
    }

    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });

    const billTotalWeightKg = billItems.reduce((acc, it) => acc + it.weightKg, 0);
    const billTotalWeightMan = Number((billTotalWeightKg / 20).toFixed(2));
    const billGrossAmount = billItems.reduce((acc, it) => acc + it.amount, 0);
    const billFinalTotal = billGrossAmount;

    const sessionLetter = currentSession;
    const sessionBillNo = getNextBillNo(bills, businessDate, sessionLetter);
    const sessionBillNoStr = `${sessionLetter}${sessionBillNo}`;

    const finalCustomerName =
      (overrideCustomerName !== undefined ? overrideCustomerName : customerName).trim() ||
      'સામાન્ય ગ્રાહક';

    const newBill: VoucherBill = {
      id: `bill_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      billNo: sessionBillNo,
      billNoStr: sessionBillNoStr,
      date: businessDate,
      time: timeStr,
      session: sessionLetter,
      customerName: finalCustomerName,
      items: billItems,
      totalWeightKg: Math.round(billTotalWeightKg * 100) / 100,
      totalWeightMan: billTotalWeightMan,
      grossAmount: billGrossAmount,
      discountLess: 0,
      finalTotal: billFinalTotal,
      createdAt: Date.now(),
      // Legacy fields for first item
      productId: billItems[0].productId,
      productName: billItems[0].productName,
      productShortcut: billItems[0].productShortcut,
      weightKg: billItems[0].weightKg,
      ratePer20Kg: billItems[0].ratePer20Kg,
    };

    // Update last remembered rates for all products in this bill
    const rateMap = new Map<string, number>();
    billItems.forEach((it) => rateMap.set(it.productId, it.ratePer20Kg));

    const updatedProducts = cleanProducts.map((p) => {
      const newRate = rateMap.get(p.id);
      return newRate ? { ...p, lastRatePer20Kg: newRate } : p;
    });

    // If this bill came from outside kanta weighment(s), attach weighment slip for combined printing (વજન + બિલ એકસાથે)
    const idsToUpdate =
      attachedWeighmentIds.length > 0
        ? attachedWeighmentIds
        : attachedWeighmentId
        ? [attachedWeighmentId]
        : [];

    let currentAttached = allWeighments.filter((w) => idsToUpdate.includes(w.id));
    if (currentAttached.length === 0 && initialWeighment) {
      currentAttached = [initialWeighment];
    }

    if (currentAttached.length > 0) {
      lastSavedWeighmentsRef.current = currentAttached;
      let totalBags = 0;
      let totalNetW = 0;
      let totalGrossW = 0;
      let totalTareW = 0;
      const slipItems = currentAttached.map((w) => {
        totalBags += w.totalBagsCount || (w.bags ? w.bags.length : 0);
        const bags = w.bags || [];
        const grossFromBags = bags.length > 0
          ? Math.round(bags.reduce((acc, b) => acc + Number(b), 0) * 10) / 10
          : w.totalWeightKg;
        let tareKg = w.tareWeightKg;
        if ((!tareKg || tareKg <= 0) && grossFromBags > w.totalWeightKg) {
          tareKg = Math.round((grossFromBags - w.totalWeightKg) * 10) / 10;
        }
        const netKg = tareKg && tareKg > 0
          ? Math.round((grossFromBags - tareKg) * 10) / 10
          : w.totalWeightKg;

        totalNetW += netKg;
        totalGrossW += grossFromBags;
        if (tareKg && tareKg > 0) totalTareW += tareKg;

        return {
          productName: w.productName,
          weightKg: netKg,
          grossWeightKg: grossFromBags,
          weightMan: Math.round((netKg / 20) * 10) / 10,
          ratePer20Kg: w.ratePer20Kg,
          amount: w.calculatedAmount,
          bags: w.bags,
          tareWeightKg: tareKg && tareKg > 0 ? tareKg : undefined,
        };
      });

      newBill.weighmentSlip = {
        date: currentAttached[0].date || businessDate,
        time: currentAttached[0].time || timeStr,
        customerName: finalCustomerName,
        billNoStr: sessionBillNoStr,
        items: slipItems,
        totalBagsCount: totalBags,
        totalWeightKg: Math.round(totalNetW * 100) / 100,
        grossWeightKg: Math.round(totalGrossW * 100) / 100,
        tareWeightKg: totalTareW > 0 ? Math.round(totalTareW * 100) / 100 : undefined,
        totalWeightMan: Math.round((totalNetW / 20) * 10) / 10,
        totalAmount: billFinalTotal,
      };
      newBill.weighmentId = currentAttached[0].id;
    }

    onSaveBill(newBill, updatedProducts);

    // Save reference for immediate weight printing if requested by farmer
    lastSavedBillRef.current = newBill;

    idsToUpdate.forEach((wId) => {
      updateWeighmentStatus(wId, 'billed', newBill.id, newBill.billNoStr);
    });
    setAttachedWeighmentIds([]);
    setAttachedWeighmentId(null);

    // Reset weight and amount inputs and DESELECT all items so user can choose manually for next customer
    try {
      localStorage.removeItem(BILL_DRAFT_KEY);
    } catch (e) {}
    setCustomerName('');
    setActiveProductIds([]);
    setVoiceResetKey((prev) => prev + 1);
    setProductInputs((prev) => {
      const updated = { ...prev };
      Object.keys(updated).forEach((k) => {
        updated[k] = { ...updated[k], weight: '', amount: '' };
      });
      return updated;
    });

    if (autoPrint) {
      if (settings.isAutoPrintStation) {
        // Office Station itself -> Print directly via Bluetooth
        setIsDirectPrinting(true);
        setDirectPrintStatus('પ્રિન્ટ મોકલાઈ રહી છે...');
        printReceiptDirectly(newBill, settings, (status) => {
          setDirectPrintStatus(status);
        })
          .catch((err) => {
            const isUserCancel =
              err?.name === 'NotFoundError' ||
              err?.message?.includes('User cancelled') ||
              err?.message?.includes('કોઈ પ્રિન્ટર પસંદ કરવામાં આવ્યું નથી');
            const isIframeErr =
              err?.message === 'IFRAME_PERMISSION_ERROR' ||
              err?.name === 'SecurityError';

            if (isIframeErr) {
              console.warn('Direct print in iframe:', err);
            } else if (!isUserCancel) {
              console.warn('Direct print failed:', err);
              alert(
                `પ્રિન્ટિંગ એરર: ${err?.message || 'પ્રિન્ટર કનેક્ટ થઈ શક્યું નહીં. પ્રિન્ટર ચાલુ છે કે નહીં તે ચકાસો.'}`
              );
            }
          })
          .finally(() => {
            setIsDirectPrinting(false);
            setDirectPrintStatus(null);
          });
      } else {
        // Any other phone -> Automatically relay to Office Printer Station via Cloud queue!
        setIsDirectPrinting(true);
        setDirectPrintStatus('📡 ઓફિસ પ્રિન્ટર પર મોકલાઈ રહ્યું છે...');
        enqueuePrintJob({
          type: 'bill',
          bill: newBill,
          title: `બિલ ${newBill.billNoStr} - ${newBill.customerName}`,
          sourceDevice: 'મોબાઈલ',
        })
          .then(() => {
            setDirectPrintStatus('✅ ઓફિસમાં ઑટો-પ્રિન્ટ થઈ જશે!');
            setTimeout(() => {
              setIsDirectPrinting(false);
              setDirectPrintStatus(null);
            }, 2500);
          })
          .catch((err) => {
            console.warn('Failed to enqueue print job, trying direct print:', err);
            printReceiptDirectly(newBill, settings, (status) => {
              setDirectPrintStatus(status);
            })
              .finally(() => {
                setIsDirectPrinting(false);
                setDirectPrintStatus(null);
              });
          });
      }
    }

    setTimeout(() => {
      customerInputRef.current?.focus();
    }, 100);
  };

  // Voice handler to set weight & rate
  const handleVoiceWeightAndRate = (
    productId: string,
    weight?: number,
    rate?: number
  ) => {
    setActiveProductIds((prev) => (prev.includes(productId) ? prev : [...prev, productId]));

    setProductInputs((prev) => {
      const prod = cleanProducts.find((p) => p.id === productId);
      const defaultRate = prod ? prod.lastRatePer20Kg.toString() : '0';
      const current = prev[productId] || { weight: '', rate: defaultRate, amount: '' };
      const nextWeight = weight !== undefined ? weight.toString() : current.weight;
      const nextRate = rate !== undefined ? rate.toString() : current.rate;

      let nextAmount = current.amount;
      const w = parseFloat(nextWeight) || 0;
      const r = parseFloat(nextRate) || 0;
      if (w > 0 && r > 0) {
        nextAmount = Math.round((w / 20) * r).toString();
      }

      return {
        ...prev,
        [productId]: {
          weight: nextWeight,
          rate: nextRate,
          amount: nextAmount,
        },
      };
    });
  };

  // Voice handler to immediately save and print
  const handleVoiceSaveAndPrint = (
    overrideProduct?: Product,
    overrideCustomerName?: string,
    overrideWeight?: number,
    overrideRate?: number
  ) => {
    const targetProd =
      overrideProduct ||
      cleanProducts.find((p) => activeProductIds.includes(p.id)) ||
      cleanProducts[0];

    const currentInp = targetProd ? productInputs[targetProd.id] : undefined;
    const finalWeight =
      overrideWeight !== undefined
        ? overrideWeight
        : parseFloat(currentInp?.weight || '') || 0;

    const finalRate =
      overrideRate !== undefined
        ? overrideRate
        : parseFloat(currentInp?.rate || '') || (targetProd ? targetProd.lastRatePer20Kg : 0);

    if (finalWeight <= 0) {
      alert('કૃપા કરીને વજન બોલો અથવા દાખલ કરો (દા.ત. "૫૪૦ કિલો").');
      return;
    }

    if (!targetProd) {
      alert('કૃપા કરીને પહેલા માલ પસંદ કરો.');
      return;
    }

    const itemAmount = Math.round((finalWeight / 20) * finalRate);
    const voiceItem: BillItem = {
      id: `item_${Date.now()}_${targetProd.id}`,
      productId: targetProd.id,
      productName: targetProd.name,
      productShortcut: targetProd.shortcut,
      weightKg: finalWeight,
      ratePer20Kg: finalRate,
      amount: itemAmount,
    };

    handleSubmit(true, overrideCustomerName, [voiceItem]);
  };

  // Direct Weight Slip Print (કાંટા પર લખેલા વજનની સીધી પ્રિન્ટ)
  const handleDirectWeightPrint = async (customWeighment?: KantaWeighment) => {
    if (isDirectPrinting || isWeightPrinting) return;

    let targetCustomer = customerName.trim();
    let slipData: WeighmentSlipData | null = null;

    // 1. If a specific weighment was passed (e.g. from the live list)
    if (customWeighment) {
      const w = customWeighment;
      const bags = w.bags || [];
      const grossFromBags = bags.length > 0
        ? Math.round(bags.reduce((acc, b) => acc + Number(b), 0) * 10) / 10
        : w.totalWeightKg;

      let tareKg = w.tareWeightKg;
      if ((!tareKg || tareKg <= 0) && grossFromBags > w.totalWeightKg) {
        tareKg = Math.round((grossFromBags - w.totalWeightKg) * 10) / 10;
      }
      const netKg = tareKg && tareKg > 0
        ? Math.round((grossFromBags - tareKg) * 10) / 10
        : w.totalWeightKg;

      slipData = {
        date: w.date || businessDate,
        time: w.time || new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }),
        customerName: w.customerName || 'સામાન્ય ખેડૂત',
        items: [
          {
            productName: w.productName,
            weightKg: netKg,
            grossWeightKg: grossFromBags,
            weightMan: Math.round((netKg / 20) * 10) / 10,
            ratePer20Kg: w.ratePer20Kg,
            amount: w.calculatedAmount,
            bags: w.bags,
            tareWeightKg: tareKg && tareKg > 0 ? tareKg : undefined,
          },
        ],
        totalBagsCount: w.totalBagsCount || (w.bags ? w.bags.length : 0),
        totalWeightKg: netKg,
        grossWeightKg: grossFromBags,
        tareWeightKg: tareKg && tareKg > 0 ? tareKg : undefined,
        totalWeightMan: Math.round((netKg / 20) * 10) / 10,
        totalAmount: w.calculatedAmount,
      };
    } else {
      // 2. Attached weighments in the current form
      const attached = allWeighments.filter((w) => attachedWeighmentIds.includes(w.id));
      if (attached.length > 0) {
        let totalBags = 0;
        let totalNetW = 0;
        let totalGrossW = 0;
        let totalTareW = 0;
        let totalAmt = 0;
        const items = attached.map((w) => {
          totalBags += w.totalBagsCount || (w.bags ? w.bags.length : 0);
          const bags = w.bags || [];
          const grossFromBags = bags.length > 0
            ? Math.round(bags.reduce((acc, b) => acc + Number(b), 0) * 10) / 10
            : w.totalWeightKg;
          let tareKg = w.tareWeightKg;
          if ((!tareKg || tareKg <= 0) && grossFromBags > w.totalWeightKg) {
            tareKg = Math.round((grossFromBags - w.totalWeightKg) * 10) / 10;
          }
          const netKg = tareKg && tareKg > 0
            ? Math.round((grossFromBags - tareKg) * 10) / 10
            : w.totalWeightKg;

          totalNetW += netKg;
          totalGrossW += grossFromBags;
          if (tareKg && tareKg > 0) totalTareW += tareKg;
          totalAmt += w.calculatedAmount || 0;

          return {
            productName: w.productName,
            weightKg: netKg,
            grossWeightKg: grossFromBags,
            weightMan: Math.round((netKg / 20) * 10) / 10,
            ratePer20Kg: w.ratePer20Kg,
            amount: w.calculatedAmount,
            bags: w.bags,
            tareWeightKg: tareKg && tareKg > 0 ? tareKg : undefined,
          };
        });

        slipData = {
          date: businessDate,
          time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }),
          customerName: targetCustomer || attached[0].customerName || 'સામાન્ય ખેડૂત',
          items,
          totalBagsCount: totalBags,
          totalWeightKg: Math.round(totalNetW * 100) / 100,
          grossWeightKg: Math.round(totalGrossW * 100) / 100,
          tareWeightKg: totalTareW > 0 ? Math.round(totalTareW * 100) / 100 : undefined,
          totalWeightMan: Math.round((totalNetW / 20) * 10) / 10,
          totalAmount: totalAmt > 0 ? totalAmt : undefined,
        };
      } else if (targetCustomer) {
        // 3. Search weighments with matching customer name
        const matched = allWeighments.filter(
          (w) => w.customerName.trim().toLowerCase() === targetCustomer.toLowerCase()
        );
        if (matched.length > 0) {
          const todayMatched = matched.filter((w) => w.date === businessDate);
          const toUse = todayMatched.length > 0 ? todayMatched : [matched[0]];
          let totalBags = 0;
          let totalNetW = 0;
          let totalGrossW = 0;
          let totalTareW = 0;
          let totalAmt = 0;
          const items = toUse.map((w) => {
            totalBags += w.totalBagsCount || (w.bags ? w.bags.length : 0);
            const bags = w.bags || [];
            const grossFromBags = bags.length > 0
              ? Math.round(bags.reduce((acc, b) => acc + Number(b), 0) * 10) / 10
              : w.totalWeightKg;
            let tareKg = w.tareWeightKg;
            if ((!tareKg || tareKg <= 0) && grossFromBags > w.totalWeightKg) {
              tareKg = Math.round((grossFromBags - w.totalWeightKg) * 10) / 10;
            }
            const netKg = tareKg && tareKg > 0
              ? Math.round((grossFromBags - tareKg) * 10) / 10
              : w.totalWeightKg;

            totalNetW += netKg;
            totalGrossW += grossFromBags;
            if (tareKg && tareKg > 0) totalTareW += tareKg;
            totalAmt += w.calculatedAmount || 0;

            return {
              productName: w.productName,
              weightKg: netKg,
              grossWeightKg: grossFromBags,
              weightMan: Math.round((netKg / 20) * 10) / 10,
              ratePer20Kg: w.ratePer20Kg,
              amount: w.calculatedAmount,
              bags: w.bags,
              tareWeightKg: tareKg && tareKg > 0 ? tareKg : undefined,
            };
          });

          slipData = {
            date: businessDate,
            time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }),
            customerName: targetCustomer,
            items,
            totalBagsCount: totalBags,
            totalWeightKg: Math.round(totalNetW * 100) / 100,
            grossWeightKg: Math.round(totalGrossW * 100) / 100,
            tareWeightKg: totalTareW > 0 ? Math.round(totalTareW * 100) / 100 : undefined,
            totalWeightMan: Math.round((totalNetW / 20) * 10) / 10,
            totalAmount: totalAmt > 0 ? totalAmt : undefined,
          };
        }
      }

      // 4. Current bill items in inputs
      if (!slipData && currentBillItems.length > 0) {
        const totalW = currentBillItems.reduce((acc, it) => acc + it.weightKg, 0);
        slipData = {
          date: businessDate,
          time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }),
          customerName: targetCustomer || 'સામાન્ય ખેડૂત',
          items: currentBillItems.map((it) => ({
            productName: it.productName,
            weightKg: it.weightKg,
            weightMan: Math.round((it.weightKg / 20) * 10) / 10,
            ratePer20Kg: it.ratePer20Kg,
            amount: it.amount,
          })),
          totalWeightKg: Math.round(totalW * 100) / 100,
          totalWeightMan: Math.round((totalW / 20) * 10) / 10,
          totalAmount: totalBillAmount > 0 ? totalBillAmount : undefined,
        };
      }

      // 5. If form is cleared (e.g. just after bill was saved), use last saved bill / weighments
      if (!slipData && (lastSavedWeighmentsRef.current.length > 0 || lastSavedBillRef.current)) {
        if (lastSavedWeighmentsRef.current.length > 0) {
          const toUse = lastSavedWeighmentsRef.current;
          let totalBags = 0;
          let totalNetW = 0;
          let totalGrossW = 0;
          let totalTareW = 0;
          let totalAmt = 0;
          const items = toUse.map((w) => {
            totalBags += w.totalBagsCount || (w.bags ? w.bags.length : 0);
            const bags = w.bags || [];
            const grossFromBags = bags.length > 0
              ? Math.round(bags.reduce((acc, b) => acc + Number(b), 0) * 10) / 10
              : w.totalWeightKg;
            let tareKg = w.tareWeightKg;
            if ((!tareKg || tareKg <= 0) && grossFromBags > w.totalWeightKg) {
              tareKg = Math.round((grossFromBags - w.totalWeightKg) * 10) / 10;
            }
            const netKg = tareKg && tareKg > 0
              ? Math.round((grossFromBags - tareKg) * 10) / 10
              : w.totalWeightKg;

            totalNetW += netKg;
            totalGrossW += grossFromBags;
            if (tareKg && tareKg > 0) totalTareW += tareKg;
            totalAmt += w.calculatedAmount || 0;

            return {
              productName: w.productName,
              weightKg: netKg,
              grossWeightKg: grossFromBags,
              weightMan: Math.round((netKg / 20) * 10) / 10,
              ratePer20Kg: w.ratePer20Kg,
              amount: w.calculatedAmount,
              bags: w.bags,
              tareWeightKg: tareKg && tareKg > 0 ? tareKg : undefined,
            };
          });

          slipData = {
            date: toUse[0].date || businessDate,
            time: toUse[0].time || new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }),
            customerName: toUse[0].customerName || lastSavedBillRef.current?.customerName || 'સામાન્ય ખેડૂત',
            billNoStr: lastSavedBillRef.current?.billNoStr,
            items,
            totalBagsCount: totalBags,
            totalWeightKg: Math.round(totalNetW * 100) / 100,
            grossWeightKg: Math.round(totalGrossW * 100) / 100,
            tareWeightKg: totalTareW > 0 ? Math.round(totalTareW * 100) / 100 : undefined,
            totalWeightMan: Math.round((totalNetW / 20) * 10) / 10,
            totalAmount: totalAmt > 0 ? totalAmt : lastSavedBillRef.current?.finalTotal,
          };
        } else if (lastSavedBillRef.current) {
          const lb = lastSavedBillRef.current;
          slipData = {
            date: lb.date,
            time: lb.time,
            customerName: lb.customerName,
            billNoStr: lb.billNoStr,
            items: lb.items.map((it) => ({
              productName: it.productName,
              weightKg: it.weightKg,
              weightMan: Math.round((it.weightKg / 20) * 10) / 10,
              ratePer20Kg: it.ratePer20Kg,
              amount: it.amount,
            })),
            totalWeightKg: lb.totalWeightKg,
            totalWeightMan: lb.totalWeightMan,
            totalAmount: lb.finalTotal,
          };
        }
      }
    }

    if (!slipData) {
      alert('વજન પ્રિન્ટ માટે કૃપા કરીને ખેડૂતનું નામ અને વજન દાખલ કરો અથવા કાંટાનું પત્રક પસંદ કરો.');
      return;
    }

    setIsWeightPrinting(true);
    setDirectPrintStatus('લખેલા વજનની પ્રિન્ટ નીકળી રહી છે...');
    try {
      await printWeighmentDirectly(slipData, settings, (status) => {
        setDirectPrintStatus(status);
      });
    } catch (err: any) {
      const isUserCancel =
        err?.name === 'NotFoundError' ||
        String(err?.message || '').toLowerCase().includes('cancelled') ||
        String(err?.message || '').toLowerCase().includes('user cancelled');
      const isIframeErr =
        err?.message === 'IFRAME_PERMISSION_ERROR' ||
        err?.name === 'SecurityError';

      if (isIframeErr) {
        console.warn('Direct weight print in iframe:', err);
      } else if (!isUserCancel) {
        console.warn('Direct weight print error:', err);
        alert('વજન પ્રિન્ટ મોકલવામાં ખામી આવી. કૃપા કરીને પ્રિન્ટર ચાલુ છે તે ચકાસો.');
      }
    } finally {
      setIsWeightPrinting(false);
      setDirectPrintStatus(null);
    }
  };

  return (
    <div className="max-w-xl mx-auto w-full">
      {/* BILLING FORM */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
          {/* Header of Form - Session Bill Number with Real-time Clock & Date */}
          <div className="px-4 py-2.5 bg-slate-900 text-white flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-400">બિલ નં:</span>
              <span className="bg-emerald-500/20 text-emerald-400 font-mono font-black text-sm sm:text-base px-3 py-1 rounded-lg border border-emerald-500/40 tracking-wider">
                {currentSession}{currentBillNo}
              </span>
            </div>

            {/* Real-time Clock & Date beside bill number */}
            <div className="flex items-center gap-2 text-xs">
              <div className="flex items-center gap-1.5 bg-slate-800/90 px-2.5 py-1 rounded-lg border border-slate-700/80 text-slate-200">
                <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                <span className="font-semibold text-xs">
                  {formatDayMonthOnly(businessDate)}
                </span>
              </div>
              <div className="flex items-center gap-1.5 bg-slate-800/90 px-2.5 py-1 rounded-lg border border-slate-700/80 text-emerald-300 font-mono font-bold">
                <Clock className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                <span className="text-xs tracking-wide">
                  {currentTime.toLocaleTimeString('en-US', {
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: true,
                  })}
                </span>
              </div>
            </div>
          </div>

          {/* Form Content */}
          <div className="p-5 space-y-4 flex-1">
            {/* LIVE KANTA WEIGHMENTS ALERT - Sleek Horizontal Strip (ક્લિક કરતાં વિગત ખુલે છે) */}
            {pendingWeighments.length > 0 && (
              <div className="space-y-2">
                {/* Sleek Horizontal Strip / Line */}
                <button
                  type="button"
                  id="kanta-pending-toggle-line"
                  onClick={() => setIsKantaExpanded((prev) => !prev)}
                  className="w-full flex items-center justify-between px-3 py-2 bg-gradient-to-r from-amber-50 via-amber-50/70 to-orange-50 hover:from-amber-100 hover:to-orange-100 active:scale-[0.99] border border-amber-300 rounded-xl transition cursor-pointer shadow-2xs group text-left"
                  title="કાંટા પરથી આવેલ વજનની વિગત જુઓ અથવા બંધ કરો"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="font-bold text-xs sm:text-sm text-amber-950 truncate">
                      કાંટા પરથી {pendingWeighments.length} માલ આવ્યા છે
                    </span>
                    {/* Unique farmer names badge */}
                    <span className="text-xs font-black text-amber-900 bg-amber-200/80 px-2 py-0.5 rounded-md truncate max-w-[180px]">
                      {Array.from(new Set(pendingWeighments.map((w) => w.customerName))).join(', ')}
                    </span>
                  </div>

                  <div className="flex items-center gap-1 text-amber-800 text-xs font-black shrink-0 ml-2">
                    <span className="underline text-[11px]">
                      {isKantaExpanded ? 'બંધ કરો' : 'વિગત જુઓ'}
                    </span>
                    {isKantaExpanded ? (
                      <ChevronUp className="w-4 h-4" />
                    ) : (
                      <ChevronDown className="w-4 h-4" />
                    )}
                  </div>
                </button>

                {/* Expanded Box: Only rendered when clicked */}
                {isKantaExpanded && (
                  <div className="bg-gradient-to-r from-amber-500/10 via-amber-50 to-orange-50 border-2 border-amber-400 rounded-2xl p-3 sm:p-3.5 shadow-xs space-y-2.5 animate-in fade-in duration-150">
                    <div className="flex items-center justify-between pb-1 border-b border-amber-200/70">
                      <span className="font-black text-xs sm:text-sm text-amber-950">
                        બહાર કાંટા પરથી આવેલ ખેડૂતનું વજન ({pendingWeighments.length} માલ બાકી)
                      </span>
                      <div className="flex items-center gap-2">
                        {onGoToKanta && (
                          <button
                            type="button"
                            onClick={onGoToKanta}
                            className="text-[11px] font-bold text-amber-800 hover:underline cursor-pointer"
                          >
                            કાંટા પેજ જુઓ ➔
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => setIsKantaExpanded(false)}
                          className="text-[11px] font-bold text-slate-500 hover:text-slate-800 px-1.5 py-0.5 rounded hover:bg-amber-200/50 cursor-pointer"
                        >
                          ✕ બંધ
                        </button>
                      </div>
                    </div>

                    <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                      {groupedPendingWeighments.map((group) => {
                        const hasMultiple = group.weighments.length > 1;

                        return (
                          <div
                            key={group.customerName}
                            className="bg-white border border-amber-300 rounded-xl p-3 space-y-2 shadow-2xs"
                          >
                            {/* Group Header: Only Farmer Name */}
                            <div className="flex items-center justify-between gap-2 flex-wrap pb-1 border-b border-slate-100">
                              <span className="font-black text-base text-slate-900">
                                {group.customerName}
                              </span>

                              {/* Quick button to combine all commodities for this farmer into 1 bill */}
                              {hasMultiple && (
                                <button
                                  type="button"
                                  onClick={() => handleAttachAllForCustomer(group.weighments)}
                                  className="px-2.5 py-1 bg-emerald-800 hover:bg-emerald-900 active:scale-95 text-white rounded-lg text-[11px] font-black shadow-xs transition flex items-center gap-1 cursor-pointer"
                                >
                                  <span>બધા માલ સાથે ૧ જ બિલ બનાવો ➔</span>
                                </button>
                              )}
                            </div>

                            {/* Individual items: Main Highlights (Item Name & Net Weight) */}
                            <div className="space-y-1.5">
                              {group.weighments.map((w) => {
                                const isAlreadyAttached = attachedWeighmentIds.includes(w.id);

                                return (
                                  <div
                                    key={w.id}
                                    className={`flex items-center justify-between gap-3 p-2 rounded-lg border transition ${
                                      isAlreadyAttached
                                        ? 'bg-emerald-50/70 border-emerald-300'
                                        : 'bg-slate-50 border-slate-200 hover:border-emerald-300'
                                    }`}
                                  >
                                    <div className="flex items-center gap-2 flex-wrap min-w-0">
                                      <span className="font-black text-sm text-slate-900 bg-white px-2.5 py-0.5 rounded border border-slate-200 shadow-2xs">
                                        {w.productName}
                                      </span>
                                      <span className="text-xs font-black text-emerald-800 font-mono">
                                        નેટ વજન: {w.totalWeightKg} kg
                                      </span>
                                      {isAlreadyAttached && (
                                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100/70 px-1.5 py-0.2 rounded">
                                          (ઉમેરેલ છે)
                                        </span>
                                      )}
                                    </div>

                                    <div className="shrink-0">
                                      <button
                                        type="button"
                                        disabled={isAlreadyAttached}
                                        onClick={() => handleAttachWeighment(w)}
                                        className={`px-3 py-1.5 rounded-lg text-xs font-black shadow-2xs transition cursor-pointer active:scale-95 ${
                                          isAlreadyAttached
                                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300 opacity-90 cursor-default'
                                            : 'bg-emerald-700 hover:bg-emerald-800 text-white'
                                        }`}
                                      >
                                        {isAlreadyAttached
                                          ? 'ઉમેરેલ છે ✓'
                                          : hasMultiple
                                          ? '+ આ માલ ઉમેરો'
                                          : 'બિલમાં ઉમેરો'}
                                      </button>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Voice Assistant Billing Bar (બોલીને બિલ બનાવો) */}
            <VoiceBillingBar
              cleanProducts={cleanProducts}
              activeProductIds={activeProductIds}
              customerName={customerName}
              resetKey={voiceResetKey}
              onSelectProduct={handleProductToggle}
              onSetCustomerName={setCustomerName}
              onSetWeightAndRate={handleVoiceWeightAndRate}
              onVoiceSaveAndPrint={handleVoiceSaveAndPrint}
            />

            {/* 1. PRODUCT BUTTONS (Sliding 4 items per slide, slightly smaller boxes) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-700 block">
                  ૧. આઇટમ પસંદ કરો
                </label>
              </div>

              {/* Product buttons Slider (4 items per slide, swipe left/right) */}
              <div
                ref={productSliderRef}
                onScroll={handleSliderScroll}
                onWheel={(e) => {
                  if (Math.abs(e.deltaX) < Math.abs(e.deltaY) && productSliderRef.current) {
                    productSliderRef.current.scrollLeft += e.deltaY;
                  }
                }}
                className="flex overflow-x-auto snap-x snap-mandatory scroll-smooth touch-pan-x select-none pb-0.5 -mx-0.5 px-0.5"
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
              >
                {/* Render Slides uniformly: Slide 1 has top 4 products, Slide 2 has next products + Add Item button */}
                {slides.map((page, pIdx) => (
                  <div
                    key={`slide-page-${pIdx}`}
                    className="w-full shrink-0 snap-start grid grid-cols-2 gap-2"
                  >
                    {page.slots.map((slot, sIdx) => {
                      if (slot.type === 'product' && slot.product) {
                        return (
                          <React.Fragment key={slot.product.id}>
                            {renderProductButton(slot.product)}
                          </React.Fragment>
                        );
                      }
                      if (slot.type === 'add_button') {
                        return (
                          <button
                            key={`add-btn-${pIdx}-${sIdx}`}
                            type="button"
                            id="grid-add-item-btn"
                            onClick={() => setShowAddItemModal(true)}
                            className="h-16 sm:h-17 py-2 px-2 rounded-xl border-2 border-dashed border-emerald-500/80 bg-emerald-50/70 hover:bg-emerald-100 text-emerald-800 transition flex flex-col items-center justify-center gap-0.5 cursor-pointer select-none active:scale-95 shadow-2xs"
                            title="નવી આઇટમ ઉમેરો"
                          >
                            <div className="flex items-center gap-1 font-black text-sm sm:text-base text-emerald-800 leading-tight">
                              <Plus className="w-4 h-4 text-emerald-700 stroke-[2.5]" />
                              <span>એડ આઇટમ</span>
                            </div>
                            <span className="text-[11px] font-bold text-emerald-600 leading-tight">
                              + નવી આઇટમ ઉમેરો
                            </span>
                          </button>
                        );
                      }
                      return (
                        <div
                          key={`empty-slot-${pIdx}-${sIdx}`}
                          onClick={() => setShowAddItemModal(true)}
                          className="h-16 sm:h-17 py-2 px-2 rounded-xl border border-dashed border-slate-200 bg-slate-50/40 hover:bg-slate-50 hover:border-slate-300 text-slate-400 transition flex flex-col items-center justify-center gap-0.5 cursor-pointer select-none"
                          title="આઇટમ ઉમેરો"
                        >
                          <span className="text-xs font-semibold text-slate-300">—</span>
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>

              {/* Slider indicator dots (only if multiple slides exist) */}
              {totalSlides > 1 && (
                <div className="flex items-center justify-center gap-1.5 pt-0.5">
                  {Array.from({ length: totalSlides }).map((_, dotIdx) => (
                    <button
                      key={dotIdx}
                      type="button"
                      onClick={() => {
                        if (productSliderRef.current) {
                          productSliderRef.current.scrollTo({
                            left: dotIdx * productSliderRef.current.clientWidth,
                            behavior: 'smooth',
                          });
                        }
                      }}
                      className={`h-1.5 rounded-full transition-all cursor-pointer ${
                        activeSlide === dotIdx ? 'w-5 bg-emerald-700' : 'w-1.5 bg-slate-300'
                      }`}
                      aria-label={`Slide ${dotIdx + 1}`}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* 2. CUSTOMER NAME */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 block">
                ૨. ગ્રાહકનું નામ
              </label>
              <div className="relative flex items-center">
                <input
                  ref={customerInputRef}
                  id="customer-name-input"
                  type="text"
                  placeholder=""
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleCustomerEnter();
                    }
                  }}
                  className="w-full text-sm font-semibold pl-3.5 pr-10 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none transition shadow-2xs"
                />
                {customerName && (
                  <button
                    type="button"
                    onClick={() => {
                      setCustomerName('');
                      customerInputRef.current?.focus();
                    }}
                    className="absolute right-2.5 p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-full transition cursor-pointer"
                    title="નામ સાફ કરો"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* 3. DYNAMIC ITEM INPUT BOXES (Weight & Amount) */}
            <div className="space-y-3">
              <div className="space-y-2.5">
                {activeProductIds.map((pId) => {
                  const prod = cleanProducts.find((x) => x.id === pId);
                  if (!prod) return null;
                  const inputData = productInputs[pId] || {
                    weight: '',
                    rate: prod.lastRatePer20Kg.toString(),
                  };
                  const wNum = parseFloat(inputData.weight) || 0;
                  const rNum = parseFloat(inputData.rate) || 0;
                  const mNum = wNum / 20;
                  const itemAmt = Math.round(mNum * rNum);

                  return (
                    <div
                      key={prod.id}
                      className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5 relative shadow-2xs"
                    >
                      {/* Product Header: Item Name + Compact Rate Box (sized to match item name) + Delete Button */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-black text-sm text-slate-900 flex items-center gap-1.5">
                            <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 inline-block"></span>
                            <span>{prod.name}</span>
                          </span>

                          {/* Small Rate Box next to item name - sized to match item name */}
                          <div className="flex items-center gap-1 bg-white border border-slate-300 rounded-lg px-2 py-0.5 shadow-2xs focus-within:ring-2 focus-within:ring-emerald-500 focus-within:border-emerald-500">
                            <span className="text-xs font-bold text-slate-500">ભાવ: ₹</span>
                            <input
                              id={`rate-input-${prod.id}`}
                              type="number"
                              step="any"
                              placeholder="ભાવ"
                              value={inputData.rate}
                              onChange={(e) =>
                                handleProductInputChange(prod.id, 'rate', e.target.value)
                              }
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  const weightEl = document.getElementById(`weight-input-${prod.id}`) as HTMLInputElement | null;
                                  if (weightEl) {
                                    weightEl.focus();
                                    weightEl.select();
                                  }
                                }
                              }}
                              className="w-14 sm:w-16 text-xs sm:text-sm font-black text-slate-900 bg-transparent focus:outline-none"
                            />
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleRemoveProduct(prod.id)}
                          className="text-slate-400 hover:text-rose-600 p-0.5 rounded transition cursor-pointer"
                          title="કાઢી નાખો"
                        >
                          <XCircle className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Weight & Amount (રકમ) 50% - 50% on one line */}
                      <div className="grid grid-cols-2 gap-3 items-end">
                        {/* Weight (kg) */}
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-700 block">
                            વજન (kg)
                          </label>
                          <input
                            id={`weight-input-${prod.id}`}
                            type="number"
                            step="any"
                            placeholder="દા.ત. 40"
                            value={inputData.weight}
                            onChange={(e) =>
                              handleProductInputChange(prod.id, 'weight', e.target.value)
                            }
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                const amtEl = document.getElementById(
                                  `amount-input-${prod.id}`
                                ) as HTMLInputElement | null;
                                if (amtEl) {
                                  amtEl.focus();
                                  amtEl.select();
                                }
                              }
                            }}
                            className="w-full text-base font-black px-3 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white transition shadow-2xs"
                          />
                        </div>

                        {/* Amount / રકમ (₹) */}
                        <div className="space-y-1">
                          <label className="text-xs font-bold text-slate-700 block">
                            રકમ (₹)
                          </label>
                          <div className="relative flex items-center">
                            <span className="absolute left-3 text-slate-400 font-bold text-sm pointer-events-none select-none">
                              ₹
                            </span>
                            <input
                              id={`amount-input-${prod.id}`}
                              type="number"
                              step="any"
                              placeholder="0"
                              value={
                                inputData.amount !== undefined && inputData.amount !== ''
                                  ? inputData.amount
                                  : itemAmt > 0
                                  ? itemAmt.toString()
                                  : ''
                              }
                              onChange={(e) =>
                                handleProductInputChange(prod.id, 'amount', e.target.value)
                              }
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                  e.preventDefault();
                                  handleSubmit(false);
                                }
                              }}
                              className="w-full text-base font-mono font-black pl-7 pr-3 py-2.5 rounded-xl border border-slate-300 text-emerald-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white transition shadow-2xs"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* SAVE AND PRINT BUTTON */}
              <div className="pt-2">
                <button
                  type="button"
                  id="create-and-print-bill-btn"
                  disabled={isDirectPrinting || isWeightPrinting}
                  onClick={() => handleSubmit(true)}
                  className={`w-full text-white font-black py-3.5 px-4 rounded-xl text-sm sm:text-base flex items-center justify-center gap-2.5 shadow-md transition group cursor-pointer ${
                    isDirectPrinting
                      ? 'bg-emerald-600 opacity-95 cursor-wait'
                      : 'bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900'
                  }`}
                >
                  {isDirectPrinting ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      <span>{directPrintStatus || 'સીધી પ્રિન્ટ મોકલાઈ રહી છે...'}</span>
                    </>
                  ) : (
                    <>
                      <Printer className="w-5 h-5 group-hover:scale-110 transition-transform" />
                      <span>
                        સેવ એન્ડ પ્રિન્ટ {totalBillAmount > 0 ? `• ${formatINR(totalBillAmount)}` : ''}
                      </span>
                    </>
                  )}
                </button>

                {/* Direct Printer Info Badge */}
                <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 px-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <Bluetooth className={`w-3.5 h-3.5 ${btConnected ? 'text-blue-600' : 'text-slate-400'}`} />
                    <span className="font-semibold text-slate-700">
                      {settings.pairedPrinterName || 'PSF588'}:
                    </span>
                    {btConnected ? (
                      <span className="text-emerald-700 font-bold flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping"></span>
                        કનેક્ટેડ (સતત એક્ટિવ)
                      </span>
                    ) : (
                      <button
                        type="button"
                        disabled={isBtConnecting}
                        onClick={async () => {
                          setIsBtConnecting(true);
                          try {
                            const reconnected = await attemptSilentReconnect();
                            if (!reconnected) {
                              await ensureConnectedPrinter(settings);
                            }
                          } catch (e: any) {
                            console.warn('Manual reconnect:', e);
                          } finally {
                            setIsBtConnecting(false);
                          }
                        }}
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-bold hover:bg-blue-100 transition cursor-pointer border border-blue-200 active:scale-95"
                        title="પ્રિન્ટર તરત ફરી કનેક્ટ કરો"
                      >
                        {isBtConnecting ? (
                          <>
                            <Loader2 className="w-3 h-3 animate-spin" />
                            <span>કનેક્ટ થાય છે...</span>
                          </>
                        ) : (
                          <>
                            <RefreshCw className="w-3 h-3" />
                            <span>કનેક્ટ કરો</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      {/* Add Item Modal */}
      {showAddItemModal && (
        <AddItemModal
          existingProducts={cleanProducts}
          onClose={() => setShowAddItemModal(false)}
          onAdd={handleAddNewProduct}
        />
      )}

      {/* View Weighment Modal (લખેલા વજન જુઓ) */}
      <WeighmentDetailModal
        weighment={viewingKantaWeighment}
        onClose={() => setViewingKantaWeighment(null)}
        onOpenBill={(w) => {
          handleAttachWeighment(w);
          setViewingKantaWeighment(null);
        }}
      />
    </div>
  );
};

