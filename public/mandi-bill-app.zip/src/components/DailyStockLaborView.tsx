import React, { useState, useMemo } from 'react';
import {
  Scale,
  Sun,
  Sunset,
  Sparkles,
} from 'lucide-react';
import { FirmSettings, Product, SessionType, VoucherBill } from '../types';
import { formatINR } from '../utils/storage';

interface DailyStockLaborViewProps {
  bills: VoucherBill[];
  products: Product[];
  settings: FirmSettings;
  currentDate: string;
  onBack?: () => void;
}

interface RateGroup {
  ratePer20Kg: number;
  weightKg: number;
  weightMan: number;
  amount: number;
  billsCount: number;
}

interface ProductStockSummary {
  productId: string;
  productName: string;
  totalWeightKg: number;
  totalWeightMan: number;
  totalAmount: number;
  rates: RateGroup[];
  isDiveli: boolean;
}

interface SessionLaborCalc {
  sessionLabel: string;
  sessionCode: 'ALL' | 'M' | 'A';
  billsCount: number;
  totalWeightKg: number;
  totalWeightMan: number;
  totalAmount: number;
  diveliWeightKg: number;
  diveliWeightMan: number;
  diveliLaborRate: number; // 1.00
  diveliLaborAmount: number;
  otherWeightKg: number;
  otherWeightMan: number;
  otherLaborRate: number; // 0.80
  otherLaborAmount: number;
  totalLaborAmount: number;
  productSummaries: ProductStockSummary[];
}

// Check if a commodity name refers to Diveli / Castor seeds
export function isDiveliProduct(name: string): boolean {
  if (!name) return false;
  const n = name.trim().toLowerCase();
  return (
    n.includes('દિવેલી') ||
    n.includes('દિવેલા') ||
    n.includes('એરંડા') ||
    n.includes('diveli') ||
    n.includes('eranda')
  );
}

export const DailyStockLaborView: React.FC<DailyStockLaborViewProps> = ({
  bills,
  products,
  settings,
  currentDate,
  onBack,
}) => {
  const [activeSessionTab, setActiveSessionTab] = useState<'ALL' | 'M' | 'A'>('ALL');

  // Filter bills for today's business date directly
  const dateBills = useMemo(() => {
    return bills.filter((b) => b.date === currentDate);
  }, [bills, currentDate]);

  // Helper to calculate stock & labor for a given subset of bills
  const calculateSessionMetrics = (
    subBills: VoucherBill[],
    code: 'ALL' | 'M' | 'A',
    label: string
  ): SessionLaborCalc => {
    let totalWeightKg = 0;
    let totalAmount = 0;
    let diveliWeightKg = 0;
    let otherWeightKg = 0;

    // Map: productName -> Map of ratePer20Kg -> { weightKg, amount, billsCount }
    const productMap = new Map<
      string,
      {
        productId: string;
        productName: string;
        isDiveli: boolean;
        ratesMap: Map<number, { weightKg: number; amount: number; billsCount: number }>;
      }
    >();

    subBills.forEach((bill) => {
      // Normalize items from bill
      const items =
        bill.items && bill.items.length > 0
          ? bill.items
          : bill.productName && (bill.weightKg || bill.totalWeightKg)
          ? [
              {
                id: `${bill.id}-0`,
                productId: bill.productId || 'p_unknown',
                productName: bill.productName,
                productShortcut: bill.productShortcut || '',
                weightKg: Number(bill.weightKg || bill.totalWeightKg || 0),
                ratePer20Kg: Number(bill.ratePer20Kg || 0),
                amount:
                  (Number(bill.weightKg || bill.totalWeightKg || 0) / 20) *
                  Number(bill.ratePer20Kg || 0),
              },
            ]
          : [];

      items.forEach((item) => {
        const pName = (item.productName || 'અન્ય').trim();
        const wKg = Number(item.weightKg) || 0;
        const rate = Number(item.ratePer20Kg) || 0;
        const amt = item.amount || (wKg / 20) * rate;
        const isDiv = isDiveliProduct(pName);

        totalWeightKg += wKg;
        totalAmount += amt;

        if (isDiv) {
          diveliWeightKg += wKg;
        } else {
          otherWeightKg += wKg;
        }

        if (!productMap.has(pName)) {
          productMap.set(pName, {
            productId: item.productId || `p_${pName}`,
            productName: pName,
            isDiveli: isDiv,
            ratesMap: new Map(),
          });
        }

        const pEntry = productMap.get(pName)!;
        const rEntry = pEntry.ratesMap.get(rate) || { weightKg: 0, amount: 0, billsCount: 0 };
        rEntry.weightKg += wKg;
        rEntry.amount += amt;
        rEntry.billsCount += 1;
        pEntry.ratesMap.set(rate, rEntry);
      });
    });

    const totalWeightMan = totalWeightKg / 20;
    const diveliWeightMan = diveliWeightKg / 20;
    const otherWeightMan = otherWeightKg / 20;

    // Labor Rates:
    // દિવેલી = ₹1.00 પ્રતિ મણ
    // દિવેલી સિવાયનો તમામ માલ = ₹0.80 (80 પૈસા) પ્રતિ મણ
    const diveliLaborRate = 1.0;
    const otherLaborRate = 0.8;

    const diveliLaborAmount = diveliWeightMan * diveliLaborRate;
    const otherLaborAmount = otherWeightMan * otherLaborRate;
    const totalLaborAmount = diveliLaborAmount + otherLaborAmount;

    // Convert products map to sorted array
    const productSummaries: ProductStockSummary[] = [];
    productMap.forEach((entry) => {
      let pTotalKg = 0;
      let pTotalAmt = 0;
      const rates: RateGroup[] = [];

      entry.ratesMap.forEach((rVal, rateKey) => {
        pTotalKg += rVal.weightKg;
        pTotalAmt += rVal.amount;
        rates.push({
          ratePer20Kg: rateKey,
          weightKg: rVal.weightKg,
          weightMan: rVal.weightKg / 20,
          amount: rVal.amount,
          billsCount: rVal.billsCount,
        });
      });

      // Sort rates ascending or descending (higher rate first)
      rates.sort((a, b) => b.ratePer20Kg - a.ratePer20Kg);

      productSummaries.push({
        productId: entry.productId,
        productName: entry.productName,
        totalWeightKg: pTotalKg,
        totalWeightMan: pTotalKg / 20,
        totalAmount: pTotalAmt,
        rates,
        isDiveli: entry.isDiveli,
      });
    });

    // Sort products: બાજરી, ઘઉં, રાયડો, દિવેલી, રાજગરો, others
    const sortPriority = ['બાજરી', 'ઘઉં', 'જૂની બાજરી', 'રાયડો', 'દિવેલી', 'રાજગરો'];
    productSummaries.sort((a, b) => {
      const idxA = sortPriority.indexOf(a.productName);
      const idxB = sortPriority.indexOf(b.productName);
      if (idxA !== -1 && idxB !== -1) return idxA - idxB;
      if (idxA !== -1) return -1;
      if (idxB !== -1) return 1;
      return a.productName.localeCompare(b.productName, 'gu');
    });

    return {
      sessionLabel: label,
      sessionCode: code,
      billsCount: subBills.length,
      totalWeightKg,
      totalWeightMan,
      totalAmount,
      diveliWeightKg,
      diveliWeightMan,
      diveliLaborRate,
      diveliLaborAmount,
      otherWeightKg,
      otherWeightMan,
      otherLaborRate,
      otherLaborAmount,
      totalLaborAmount,
      productSummaries,
    };
  };

  // Full Day Metrics
  const allDayMetrics = useMemo(
    () => calculateSessionMetrics(dateBills, 'ALL', 'આખો દિવસ (કુલ)'),
    [dateBills]
  );

  // Morning Session (M) Metrics
  const morningMetrics = useMemo(() => {
    const mBills = dateBills.filter((b) => b.session === 'M');
    return calculateSessionMetrics(mBills, 'M', 'સવાર સત્ર (M)');
  }, [dateBills]);

  // Afternoon Session (A) Metrics
  const afternoonMetrics = useMemo(() => {
    const aBills = dateBills.filter((b) => b.session === 'A');
    return calculateSessionMetrics(aBills, 'A', 'બપોર સત્ર (A)');
  }, [dateBills]);

  // Currently active selected metrics
  const activeMetrics = useMemo(() => {
    if (activeSessionTab === 'M') return morningMetrics;
    if (activeSessionTab === 'A') return afternoonMetrics;
    return allDayMetrics;
  }, [activeSessionTab, allDayMetrics, morningMetrics, afternoonMetrics]);

  // Format labor amount for session badges (e.g. 56.7 -> ₹56.7, 0 -> ₹0)
  const formatLaborBadge = (amt: number): string => {
    if (!amt || amt === 0) return '₹0';
    const rounded = Math.round(amt * 10) / 10;
    return `₹${rounded.toLocaleString('en-IN', { minimumFractionDigits: rounded % 1 === 0 ? 0 : 1, maximumFractionDigits: 1 })}`;
  };

  return (
    <div className="space-y-4 pb-12 animate-fade-in">
      {/* 3 Session Tabs: આખો દિવસ (કુલ), સવાર સત્ર (M), બપોર સત્ર (A) */}
      <div className="grid grid-cols-3 gap-2 bg-slate-200/80 p-1.5 rounded-2xl border border-slate-300/80">
        {/* Tab 1: All Day */}
        <button
          type="button"
          onClick={() => setActiveSessionTab('ALL')}
          id="tab-labor-all-day"
          className={`py-2.5 px-2 rounded-xl text-center transition cursor-pointer active:scale-98 ${
            activeSessionTab === 'ALL'
              ? 'bg-emerald-800 text-white shadow-md'
              : 'bg-white/80 hover:bg-white text-slate-700'
          }`}
        >
          <div className="flex items-center justify-center gap-1.5">
            <Sparkles className={`w-4 h-4 ${activeSessionTab === 'ALL' ? 'text-amber-300' : 'text-slate-500'}`} />
            <span className="font-black text-xs sm:text-sm">આખો દિવસ</span>
          </div>
          <span className={`text-[11px] block mt-0.5 font-bold font-mono ${activeSessionTab === 'ALL' ? 'text-emerald-200' : 'text-slate-500'}`}>
            {formatLaborBadge(allDayMetrics.totalLaborAmount)}
          </span>
        </button>

        {/* Tab 2: Morning */}
        <button
          type="button"
          onClick={() => setActiveSessionTab('M')}
          id="tab-labor-morning"
          className={`py-2.5 px-2 rounded-xl text-center transition cursor-pointer active:scale-98 ${
            activeSessionTab === 'M'
              ? 'bg-emerald-800 text-white shadow-md'
              : 'bg-white/80 hover:bg-white text-slate-700'
          }`}
        >
          <div className="flex items-center justify-center gap-1.5">
            <Sun className={`w-4 h-4 ${activeSessionTab === 'M' ? 'text-amber-300' : 'text-amber-500'}`} />
            <span className="font-black text-xs sm:text-sm">સવાર સત્ર</span>
          </div>
          <span className={`text-[11px] block mt-0.5 font-bold font-mono ${activeSessionTab === 'M' ? 'text-emerald-200' : 'text-slate-500'}`}>
            {formatLaborBadge(morningMetrics.totalLaborAmount)}
          </span>
        </button>

        {/* Tab 3: Afternoon */}
        <button
          type="button"
          onClick={() => setActiveSessionTab('A')}
          id="tab-labor-afternoon"
          className={`py-2.5 px-2 rounded-xl text-center transition cursor-pointer active:scale-98 ${
            activeSessionTab === 'A'
              ? 'bg-emerald-800 text-white shadow-md'
              : 'bg-white/80 hover:bg-white text-slate-700'
          }`}
        >
          <div className="flex items-center justify-center gap-1.5">
            <Sunset className={`w-4 h-4 ${activeSessionTab === 'A' ? 'text-amber-300' : 'text-orange-500'}`} />
            <span className="font-black text-xs sm:text-sm">બપોર સત્ર</span>
          </div>
          <span className={`text-[11px] block mt-0.5 font-bold font-mono ${activeSessionTab === 'A' ? 'text-emerald-200' : 'text-slate-500'}`}>
            {formatLaborBadge(afternoonMetrics.totalLaborAmount)}
          </span>
        </button>
      </div>

      {/* Quick Stat Summary Cards */}
      <div className="grid grid-cols-2 gap-2 sm:gap-3">
        <div className="bg-white rounded-2xl p-3 sm:p-4 border border-slate-200 shadow-xs">
          <span className="text-[11px] sm:text-xs font-bold text-slate-500 block">
            કુલ માલ વજન
          </span>
          <p className="text-base sm:text-xl font-black font-mono text-slate-900 mt-0.5">
            {activeMetrics.totalWeightKg.toLocaleString('en-IN', { maximumFractionDigits: 1 })}{' '}
            <span className="text-xs font-bold text-slate-500">kg</span>
          </p>
        </div>

        <div className="bg-emerald-800 text-white rounded-2xl p-3 sm:p-4 border border-emerald-900 shadow-xs">
          <span className="text-[11px] sm:text-xs font-bold text-emerald-200 block">
            કુલ ખરીદી રકમ
          </span>
          <p className="text-base sm:text-xl font-black font-mono text-amber-300 mt-0.5">
            {formatINR(activeMetrics.totalAmount)}
          </p>
        </div>
      </div>

      {/* COMMODITY STOCK & RATE-WISE BREAKDOWN - SINGLE UNIFIED CLEAN TABLE */}
      <div className="space-y-3">
        {activeMetrics.productSummaries.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 text-center border border-slate-200 text-slate-400 space-y-2">
            <Scale className="w-10 h-10 mx-auto text-slate-300" />
            <p className="font-bold text-sm text-slate-600">
              આ સત્રમાં કોઈ માલ ખરીદાયો નથી.
            </p>
            <p className="text-xs text-slate-400">
              નવા બિલો બનશે એટલે તેની વિગત આપોઆપ અહીં ઉમેરાશે.
            </p>
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <table className="w-full text-left text-xs sm:text-sm border-collapse">
              <thead>
                <tr className="bg-slate-100 border-b border-slate-200 text-slate-700 font-black">
                  <th className="py-2.5 px-3">માલ</th>
                  <th className="py-2.5 px-2 text-center">ભાવ (૨૦kg)</th>
                  <th className="py-2.5 px-2 text-right">વજન (કિલો)</th>
                  <th className="py-2.5 px-3 text-right">રકમ (₹)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {activeMetrics.productSummaries.map((product) => {
                  const hasMultipleRates = product.rates.length > 1;

                  return (
                    <React.Fragment key={product.productName}>
                      {product.rates.map((rate, rIdx) => (
                        <tr
                          key={`${product.productName}-${rate.ratePer20Kg}-${rIdx}`}
                          className="hover:bg-slate-50/80 transition"
                        >
                          <td className="py-2.5 px-3 font-black text-slate-900">
                            <span>{product.productName}</span>
                          </td>
                          <td className="py-2.5 px-2 text-center">
                            <span className="inline-block px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-900 border border-emerald-200 font-mono font-black text-xs">
                              ₹{rate.ratePer20Kg}
                            </span>
                          </td>
                          <td className="py-2.5 px-2 text-right font-bold text-slate-800 font-mono whitespace-nowrap">
                            {rate.weightKg.toLocaleString('en-IN', { maximumFractionDigits: 1 })} kg
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono font-black text-emerald-800 whitespace-nowrap">
                            {formatINR(rate.amount)}
                          </td>
                        </tr>
                      ))}

                      {/* Subtotal row if product has multiple rates */}
                      {hasMultipleRates && (
                        <tr className="bg-emerald-50/60 font-black text-slate-900 border-b border-slate-200">
                          <td className="py-2 px-3 text-emerald-950 font-black text-[11px] sm:text-xs">
                            ↳ કુલ {product.productName}
                          </td>
                          <td className="py-2 px-2 text-center text-slate-400 text-xs">-</td>
                          <td className="py-2 px-2 text-right font-mono font-black text-slate-900 text-[11px] sm:text-xs whitespace-nowrap">
                            {product.totalWeightKg.toLocaleString('en-IN', { maximumFractionDigits: 1 })} kg
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-black text-emerald-900 text-[11px] sm:text-xs whitespace-nowrap">
                            {formatINR(product.totalAmount)}
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="bg-slate-900 text-white font-black border-t-2 border-slate-800">
                  <td className="py-3 px-3 text-emerald-300 font-black text-xs sm:text-sm">
                    કુલ માલ સરવાળો
                  </td>
                  <td className="py-3 px-2 text-center text-slate-500 font-mono text-xs">-</td>
                  <td className="py-3 px-2 text-right font-mono text-emerald-300 font-black text-xs sm:text-sm whitespace-nowrap">
                    {activeMetrics.totalWeightKg.toLocaleString('en-IN', { maximumFractionDigits: 1 })} kg
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-amber-300 font-black text-sm sm:text-base whitespace-nowrap">
                    {formatINR(activeMetrics.totalAmount)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
