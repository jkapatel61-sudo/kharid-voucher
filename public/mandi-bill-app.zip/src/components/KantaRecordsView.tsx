import React, { useState, useEffect, useMemo } from 'react';
import {
  ArrowLeft,
  Scale,
  Plus,
  Search,
  Edit3,
  Printer,
  Clock,
  CheckCircle2,
  X,
} from 'lucide-react';
import {
  KantaWeighment,
  subscribeToWeighments,
  subscribeToBills,
} from '../utils/firebaseSync';
import { formatINR, getStoredFirmSettings, getStoredBills } from '../utils/storage';
import { WeighmentDetailModal } from './WeighmentDetailModal';
import { WeighmentSlipData, VoucherBill } from '../types';
import { printWeighmentDirectly, printCombinedDirectly } from '../utils/directPrint';

interface KantaRecordsViewProps {
  bills?: VoucherBill[];
  onBackToKanta?: () => void;
  onBack?: () => void;
  onEditInKanta?: (weighment: KantaWeighment) => void;
  onEditInSheet?: (weighment: KantaWeighment) => void;
  onOpenBillForWeighment?: (weighment: KantaWeighment) => void;
}

export const KantaRecordsView: React.FC<KantaRecordsViewProps> = ({
  bills,
  onBackToKanta,
  onBack,
  onEditInKanta,
  onEditInSheet,
  onOpenBillForWeighment,
}) => {
  const handleBack = () => {
    if (onBackToKanta) onBackToKanta();
    else if (onBack) onBack();
  };

  const handleEdit = (weighment: KantaWeighment) => {
    if (onEditInKanta) onEditInKanta(weighment);
    else if (onEditInSheet) onEditInSheet(weighment);
  };

  const [weighments, setWeighments] = useState<KantaWeighment[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'billed'>('all');
  const [viewingWeighment, setViewingWeighment] = useState<KantaWeighment | null>(null);
  const [printingId, setPrintingId] = useState<string | null>(null);
  const [liveBills, setLiveBills] = useState<VoucherBill[]>(bills || []);

  // Keep live bills updated
  useEffect(() => {
    if (bills && bills.length > 0) {
      setLiveBills(bills);
    }
  }, [bills]);

  useEffect(() => {
    const unsub = subscribeToBills((list) => {
      if (list && list.length > 0) {
        setLiveBills(list);
      }
    });
    return () => unsub();
  }, []);

  // Subscribe to live Firebase weighments
  useEffect(() => {
    const unsub = subscribeToWeighments((list) => {
      setWeighments(list);
    });
    return () => unsub();
  }, []);

  // Helper to find associated bill info (especially billNoStr)
  const getBillInfoForWeighment = (entry: KantaWeighment) => {
    if (entry.billNoStr) {
      return { billNoStr: entry.billNoStr };
    }
    const allBills = liveBills.length > 0 ? liveBills : getStoredBills();
    if (entry.billId) {
      const found = allBills.find((b) => b.id === entry.billId);
      if (found) return { billNoStr: found.billNoStr, bill: found };
    }
    const byWeighmentId = allBills.find((b) => (b as any).weighmentId === entry.id);
    if (byWeighmentId) {
      return { billNoStr: byWeighmentId.billNoStr, bill: byWeighmentId };
    }
    // Match by customer name and approximate weight on same date
    const byNameAndWeight = allBills.find(
      (b) =>
        b.date === entry.date &&
        b.customerName?.trim().toLowerCase() === entry.customerName?.trim().toLowerCase() &&
        Math.abs(b.totalWeightKg - entry.totalWeightKg) < 1.5
    );
    if (byNameAndWeight) {
      return { billNoStr: byNameAndWeight.billNoStr, bill: byNameAndWeight };
    }
    return { billNoStr: undefined };
  };

  // Filtered list
  const filteredList = useMemo(() => {
    return weighments.filter((w) => {
      if (statusFilter === 'pending' && w.status !== 'pending') return false;
      if (statusFilter === 'billed' && w.status !== 'billed') return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = (w.customerName || '').toLowerCase().includes(q);
        const matchesProduct = (w.productName || '').toLowerCase().includes(q);
        const billInfo = getBillInfoForWeighment(w);
        const matchesBillNo = (billInfo.billNoStr || '').toLowerCase().includes(q);
        if (!matchesName && !matchesProduct && !matchesBillNo) return false;
      }

      return true;
    });
  }, [weighments, statusFilter, searchQuery, liveBills]);

  const pendingCount = useMemo(() => {
    return weighments.filter((w) => w.status === 'pending').length;
  }, [weighments]);

  const billedCount = useMemo(() => {
    return weighments.filter((w) => w.status === 'billed').length;
  }, [weighments]);

  // Helper to construct weighment slip data
  const buildSlipData = (w: KantaWeighment): WeighmentSlipData => {
    const bags = Array.isArray(w.bags) ? w.bags : [];
    const gross =
      bags.length > 0
        ? Math.round(bags.reduce((acc, v) => acc + (Number(v) || 0), 0) * 10) / 10
        : w.totalWeightKg;
    const tare = w.tareWeightKg || 0;
    const net = tare > 0 ? Math.max(0, Math.round((gross - tare) * 10) / 10) : w.totalWeightKg;

    return {
      date: w.date,
      time: w.time,
      customerName: w.customerName,
      items: [
        {
          productName: w.productName,
          weightKg: net,
          grossWeightKg: gross,
          tareWeightKg: tare > 0 ? tare : undefined,
          weightMan: Math.round((net / 20) * 10) / 10,
          ratePer20Kg: w.ratePer20Kg,
          amount: w.calculatedAmount,
          bags: bags,
        },
      ],
      totalBagsCount: w.totalBagsCount,
      totalWeightKg: net,
      grossWeightKg: gross,
      tareWeightKg: tare > 0 ? tare : undefined,
      totalWeightMan: Math.round((net / 20) * 10) / 10,
      totalAmount: w.calculatedAmount,
    };
  };

  // 1. Direct Weight Slip Only Print
  const handlePrintSlip = async (w: KantaWeighment) => {
    if (printingId) return;
    setPrintingId(w.id);
    try {
      const settings = getStoredFirmSettings();
      const slipData = buildSlipData(w);
      await printWeighmentDirectly(slipData, settings);
    } catch (err) {
      console.warn('Print error:', err);
    } finally {
      setPrintingId(null);
    }
  };

  // 2. Combined Print: Weight Slip + Voucher Bill together on a single slip!
  const handlePrintCombined = async (w: KantaWeighment) => {
    if (printingId) return;
    setPrintingId(w.id);
    try {
      const settings = getStoredFirmSettings();
      const slipData = buildSlipData(w);

      // Look up matching bill in stored bills
      const storedBills = liveBills.length > 0 ? liveBills : getStoredBills();
      let matchingBill = storedBills.find(
        (b) =>
          (w.billId && b.id === w.billId) ||
          ((b as any).weighmentId === w.id) ||
          (b.customerName === w.customerName && Math.abs(b.totalWeightKg - slipData.totalWeightKg) < 1.5)
      );

      const billInfo = getBillInfoForWeighment(w);

      if (!matchingBill) {
        matchingBill = {
          id: `bill_${w.id}`,
          billNo: 1,
          billNoStr: billInfo.billNoStr || 'M1',
          date: w.date,
          time: w.time,
          session: 'M',
          customerName: w.customerName,
          items: [
            {
              id: `item_${w.id}`,
              productId: w.productId,
              productName: w.productName,
              productShortcut: '',
              weightKg: slipData.totalWeightKg,
              ratePer20Kg: w.ratePer20Kg,
              amount: w.calculatedAmount,
            },
          ],
          totalWeightKg: slipData.totalWeightKg,
          totalWeightMan: Math.round((slipData.totalWeightKg / 20) * 10) / 10,
          grossAmount: w.calculatedAmount,
          discountLess: 0,
          finalTotal: w.calculatedAmount,
          createdAt: w.createdAt,
          weighmentSlip: slipData,
        };
      } else {
        matchingBill = {
          ...matchingBill,
          weighmentSlip: slipData,
        };
      }

      await printCombinedDirectly(matchingBill, slipData, settings);
    } catch (err) {
      console.warn('Combined print error:', err);
    } finally {
      setPrintingId(null);
    }
  };

  return (
    <div className="space-y-2 pb-12 animate-fade-in">
      {/* Compact Top Bar: Back button & Search input (matching HistoryView) */}
      <div className="bg-white rounded-xl p-2 sm:p-2.5 shadow-2xs border border-slate-200 flex items-center gap-2">
        <button
          onClick={handleBack}
          id="kanta-records-back-btn"
          className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 transition flex items-center gap-1 font-black text-xs shrink-0 active:scale-95 cursor-pointer shadow-2xs"
          title="કાંટા એન્ટ્રી પર પાછા જાઓ"
        >
          <ArrowLeft className="w-3.5 h-3.5 text-emerald-800" />
          <span>કાંટા એન્ટ્રી</span>
        </button>

        {/* Compact Search Input */}
        <div className="relative flex-1">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder="ખેડૂતનું નામ, માલ અથવા બિલ નં..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-7 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-slate-50 focus:bg-white transition"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Count badge */}
        <span className="text-[11px] font-bold text-slate-500 bg-slate-100 px-2 py-1 rounded-lg shrink-0">
          {filteredList.length} નોંધ
        </span>

        {/* New Weight Entry Button */}
        <button
          onClick={handleBack}
          className="px-2.5 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white transition flex items-center gap-1 font-black text-xs shrink-0 active:scale-95 cursor-pointer shadow-2xs"
          title="નવું વજન લખો"
        >
          <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
          <span className="hidden sm:inline">નવું વજન</span>
        </button>
      </div>

      {/* Filter Tabs: બધા, બાકી, બિલ બની ગયું */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 no-scrollbar">
        <button
          type="button"
          onClick={() => setStatusFilter('all')}
          className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer shrink-0 flex items-center gap-1 ${
            statusFilter === 'all'
              ? 'bg-slate-900 text-white shadow-2xs'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <span>બધા</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-white/20">
            {weighments.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter('pending')}
          className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer shrink-0 flex items-center gap-1 ${
            statusFilter === 'pending'
              ? 'bg-amber-600 text-white shadow-2xs'
              : 'bg-white text-amber-900 border border-amber-200 hover:bg-amber-50'
          }`}
        >
          <Clock className="w-3 h-3" />
          <span>બાકી</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-amber-900/15">
            {pendingCount}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter('billed')}
          className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer shrink-0 flex items-center gap-1 ${
            statusFilter === 'billed'
              ? 'bg-emerald-700 text-white shadow-2xs'
              : 'bg-white text-emerald-900 border border-emerald-200 hover:bg-emerald-50'
          }`}
        >
          <CheckCircle2 className="w-3 h-3" />
          <span>બિલ બની ગયું</span>
          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-900/15">
            {billedCount}
          </span>
        </button>
      </div>

      {/* High-Density Compact Weighment List (History ની જેમ જ કોમ્પેક્ટ, સ્પષ્ટ અને બિલ નંબર સાથે) */}
      <div className="space-y-1.5">
        {filteredList.length === 0 ? (
          <div className="bg-white rounded-xl p-8 text-center border border-dashed border-slate-300">
            <Scale className="w-8 h-8 text-slate-300 mx-auto mb-1.5" />
            <p className="text-xs font-bold text-slate-600">
              {searchQuery || statusFilter !== 'all'
                ? 'પસંદ કરેલા ફિલ્ટરમાં કોઈ વજન મળ્યું નથી'
                : 'આજે હજી સુધી કોઈ કાંટા વજન નોંધાયેલ નથી'}
            </p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              'નવું વજન' પર ક્લિક કરી કાંટા વજન નોંધો
            </p>
          </div>
        ) : (
          filteredList.map((entry) => {
            const isPending = entry.status === 'pending';
            const tare = entry.tareWeightKg || 0;
            const gross =
              entry.bags && entry.bags.length > 0
                ? Math.round(entry.bags.reduce((acc, v) => acc + (Number(v) || 0), 0) * 10) / 10
                : entry.totalWeightKg;
            const net = tare > 0 ? Math.max(0, Math.round((gross - tare) * 10) / 10) : entry.totalWeightKg;
            const netMan = Math.round((net / 20) * 10) / 10;
            const billInfo = getBillInfoForWeighment(entry);
            const billNoStr = billInfo.billNoStr;

            return (
              <div
                key={entry.id}
                className="bg-white rounded-xl px-3 py-2 border border-slate-200 shadow-2xs hover:border-emerald-500 transition flex items-center justify-between gap-2"
              >
                {/* Left side: Bill #, Customer Name, Time & Commodity/Weights (HistoryView style) */}
                <div
                  className="flex-1 min-w-0 cursor-pointer"
                  onClick={() => setViewingWeighment(entry)}
                  title="થેલીવાર વજન વિગત જોવા ક્લિક કરો"
                >
                  {/* Top row: Bill No badge, Customer Name, Time, and Pending tag if applicable */}
                  <div className="flex items-center gap-2">
                    {billNoStr ? (
                      <span className="px-1.5 py-0.5 rounded-md bg-slate-900 text-white font-mono font-black text-[11px] shrink-0">
                        {billNoStr}
                      </span>
                    ) : (
                      <span className="px-1.5 py-0.5 rounded-md bg-amber-600 text-white font-mono font-bold text-[10px] shrink-0">
                        કાંટા
                      </span>
                    )}

                    <span className="font-black text-xs sm:text-sm text-slate-900 truncate">
                      {entry.customerName || 'સામાન્ય ગ્રાહક'}
                    </span>

                    <span className="text-[10px] text-slate-400 font-semibold shrink-0">
                      {entry.time}
                    </span>

                    {isPending && (
                      <span className="text-[9px] font-bold text-amber-800 bg-amber-50 px-1.5 py-0.2 rounded border border-amber-200 shrink-0">
                        બાકી
                      </span>
                    )}
                  </div>

                  {/* Bottom row: Compact Commodity, Bags, Net Weight, Man, Tare, Rate */}
                  <div className="text-[11px] text-slate-600 truncate mt-0.5 font-medium flex items-center gap-1.5">
                    <span className="font-semibold text-slate-800">{entry.productName}</span>
                    <span className="text-slate-300 mx-0.5">|</span>
                    <span className="text-slate-700">{entry.totalBagsCount} થેલી</span>
                    <span className="text-slate-300 mx-0.5">|</span>
                    <span className="font-mono text-emerald-800 font-bold">
                      {net} kg
                    </span>
                    <span className="text-slate-400 text-[10px]">
                      ({netMan} મણ)
                    </span>
                    {tare > 0 && (
                      <span className="text-rose-600 text-[10px] font-bold">
                        (-{tare}kg)
                      </span>
                    )}
                    <span className="text-slate-300 mx-0.5">|</span>
                    <span className="text-slate-400 text-[10px]">
                      (₹{entry.ratePer20Kg})
                    </span>
                  </div>
                </div>

                {/* Right side: Amount, Print & Edit buttons - Clean & Uncrowded (HistoryView style) */}
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-xs sm:text-sm font-black text-emerald-800 font-mono">
                    {formatINR(entry.calculatedAmount)}
                  </span>

                  {/* DIRECT PRINT BUTTON */}
                  <button
                    type="button"
                    disabled={printingId === entry.id}
                    onClick={() => (isPending ? handlePrintSlip(entry) : handlePrintCombined(entry))}
                    className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-black text-xs flex items-center gap-1 shadow-2xs transition active:scale-95 cursor-pointer disabled:opacity-50"
                    title={isPending ? 'કાંટા વજન પાવતી પ્રિન્ટ કરો' : 'વજન અને બિલ બંને પ્રિન્ટ કરો'}
                  >
                    <Printer className="w-3 h-3" />
                    <span className="text-[11px]">
                      {printingId === entry.id ? '...' : 'પ્રિન્ટ'}
                    </span>
                  </button>

                  {/* EDIT BUTTON */}
                  <button
                    type="button"
                    onClick={() => handleEdit(entry)}
                    className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-black text-xs flex items-center gap-1 shadow-2xs transition active:scale-95 cursor-pointer"
                    title="કાંટા એન્ટ્રી એડિટ કરો"
                  >
                    <Edit3 className="w-3 h-3" />
                    <span className="text-[11px]">એડિટ</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* View Weighment Modal (લખેલા વજન વિગત) */}
      <WeighmentDetailModal
        weighment={viewingWeighment}
        onClose={() => setViewingWeighment(null)}
        onLoadIntoSheet={(w) => {
          setViewingWeighment(null);
          handleEdit(w);
        }}
        onOpenBill={onOpenBillForWeighment}
      />
    </div>
  );
};

