import React, { useState } from 'react';
import { X, Printer, Edit3, Scale, ChevronRight, CheckCircle2, Clock, Layers } from 'lucide-react';
import { KantaWeighment } from '../utils/firebaseSync';
import { WeighmentSlipData, VoucherBill } from '../types';
import { getStoredFirmSettings, formatINR, getStoredBills } from '../utils/storage';
import { printWeighmentDirectly, printCombinedDirectly } from '../utils/directPrint';

interface WeighmentDetailModalProps {
  weighment: KantaWeighment | null;
  onClose: () => void;
  onLoadIntoSheet?: (weighment: KantaWeighment) => void;
  onOpenBill?: (weighment: KantaWeighment) => void;
}

export const WeighmentDetailModal: React.FC<WeighmentDetailModalProps> = ({
  weighment,
  onClose,
  onLoadIntoSheet,
  onOpenBill,
}) => {
  const [isPrinting, setIsPrinting] = useState(false);
  const [printStatus, setPrintStatus] = useState<string | null>(null);

  if (!weighment) return null;

  const bags = Array.isArray(weighment.bags) ? weighment.bags : [];
  const halfCount = Math.max(10, Math.ceil(bags.length / 2));

  // Compute column subtotals
  let leftTotal = 0;
  for (let i = 0; i < halfCount; i++) {
    if (i < bags.length && !isNaN(bags[i])) {
      leftTotal += Number(bags[i]);
    }
  }
  leftTotal = Math.round(leftTotal * 10) / 10;

  let rightTotal = 0;
  for (let i = halfCount; i < bags.length; i++) {
    if (!isNaN(bags[i])) {
      rightTotal += Number(bags[i]);
    }
  }
  rightTotal = Math.round(rightTotal * 10) / 10;

  const grossWeight =
    bags.length > 0
      ? Math.round(bags.reduce((acc, v) => acc + (Number(v) || 0), 0) * 10) / 10
      : weighment.totalWeightKg;

  const tare = weighment.tareWeightKg || 0;
  const netWeight = tare > 0 ? Math.max(0, Math.round((grossWeight - tare) * 10) / 10) : weighment.totalWeightKg;

  const handlePrint = async () => {
    setIsPrinting(true);
    setPrintStatus('પ્રિન્ટ નીકળી રહી છે...');
    try {
      const settings = getStoredFirmSettings();
      const slipData: WeighmentSlipData = {
        date: weighment.date,
        time: weighment.time,
        customerName: weighment.customerName,
        items: [
          {
            productName: weighment.productName,
            weightKg: netWeight,
            grossWeightKg: grossWeight,
            tareWeightKg: tare > 0 ? tare : undefined,
            weightMan: Math.round((netWeight / 20) * 10) / 10,
            ratePer20Kg: weighment.ratePer20Kg,
            amount: weighment.calculatedAmount,
            bags: bags,
          },
        ],
        totalBagsCount: weighment.totalBagsCount,
        totalWeightKg: netWeight,
        grossWeightKg: grossWeight,
        tareWeightKg: tare > 0 ? tare : undefined,
        totalWeightMan: Math.round((netWeight / 20) * 10) / 10,
        totalAmount: weighment.calculatedAmount,
      };

      await printWeighmentDirectly(slipData, settings, (st) => {
        setPrintStatus(st);
      });
    } catch (err: any) {
      console.warn('Print weighment error:', err);
    } finally {
      setIsPrinting(false);
      setPrintStatus(null);
    }
  };

  const handlePrintCombined = async () => {
    setIsPrinting(true);
    setPrintStatus('વજન અને બિલ પ્રિન્ટ થઈ રહ્યું છે...');
    try {
      const settings = getStoredFirmSettings();
      const slipData: WeighmentSlipData = {
        date: weighment.date,
        time: weighment.time,
        customerName: weighment.customerName,
        items: [
          {
            productName: weighment.productName,
            weightKg: netWeight,
            grossWeightKg: grossWeight,
            tareWeightKg: tare > 0 ? tare : undefined,
            weightMan: Math.round((netWeight / 20) * 10) / 10,
            ratePer20Kg: weighment.ratePer20Kg,
            amount: weighment.calculatedAmount,
            bags: bags,
          },
        ],
        totalBagsCount: weighment.totalBagsCount,
        totalWeightKg: netWeight,
        grossWeightKg: grossWeight,
        tareWeightKg: tare > 0 ? tare : undefined,
        totalWeightMan: Math.round((netWeight / 20) * 10) / 10,
        totalAmount: weighment.calculatedAmount,
      };

      const storedBills = getStoredBills();
      let matchingBill = storedBills.find(
        (b) =>
          (weighment.billId && b.id === weighment.billId) ||
          (b.customerName === weighment.customerName && Math.abs(b.totalWeightKg - netWeight) < 1)
      );

      if (!matchingBill) {
        matchingBill = {
          id: `bill_${weighment.id}`,
          billNo: 1,
          billNoStr: 'M1',
          date: weighment.date,
          time: weighment.time,
          session: 'M',
          customerName: weighment.customerName,
          items: [
            {
              id: `item_${weighment.id}`,
              productId: weighment.productId,
              productName: weighment.productName,
              productShortcut: '',
              weightKg: netWeight,
              ratePer20Kg: weighment.ratePer20Kg,
              amount: weighment.calculatedAmount,
            },
          ],
          totalWeightKg: netWeight,
          totalWeightMan: Math.round((netWeight / 20) * 10) / 10,
          grossAmount: weighment.calculatedAmount,
          discountLess: 0,
          finalTotal: weighment.calculatedAmount,
          createdAt: weighment.createdAt,
          weighmentSlip: slipData,
        };
      } else {
        matchingBill = {
          ...matchingBill,
          weighmentSlip: slipData,
        };
      }

      await printCombinedDirectly(matchingBill, slipData, settings, (st) => {
        setPrintStatus(st);
      });
    } catch (err: any) {
      console.warn('Print combined error:', err);
    } finally {
      setIsPrinting(false);
      setPrintStatus(null);
    }
  };

  const isPending = weighment.status === 'pending';

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 to-teal-800 text-white px-4 py-3 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <Scale className="w-5 h-5 text-emerald-300" />
            <div>
              <h3 className="font-black text-base leading-tight">
                કાંટા પર લખેલા વજન વિગત
              </h3>
              <p className="text-xs text-emerald-100 flex items-center gap-2 mt-0.5">
                <span>{weighment.customerName}</span>
                <span>•</span>
                <span className="bg-emerald-700/80 px-1.5 py-0.2 rounded font-bold">
                  {weighment.productName}
                </span>
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white transition cursor-pointer"
            title="બંધ કરો"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Subheader info: Time, Date, Status */}
        <div className="bg-slate-50 border-b border-slate-200 px-4 py-2 flex items-center justify-between text-xs shrink-0">
          <div className="flex items-center gap-3 text-slate-600 font-medium">
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              {weighment.date} • {weighment.time}
            </span>
            {weighment.tokenNo ? (
              <span className="font-bold text-slate-800">ટોકન: #{weighment.tokenNo}</span>
            ) : null}
          </div>
          <span
            className={`px-2 py-0.5 rounded-full font-bold text-[11px] ${
              isPending
                ? 'bg-amber-100 text-amber-900 border border-amber-300'
                : 'bg-emerald-100 text-emerald-900 border border-emerald-300'
            }`}
          >
            {isPending ? 'ઓફિસમાં બિલ બાકી' : 'બિલ બની ગયું ✓'}
          </span>
        </div>

        {/* Bag List in 2 Clean Columns with Column Subtotals */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-3">
          {bags.length === 0 ? (
            <div className="text-center py-8 text-slate-400 text-sm">
              આ એન્ટ્રીમાં થેલીવાર વજન દાખલ થયેલ નથી.
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2.5">
              {/* Column 1: Bags 1 to halfCount */}
              <div className="border border-slate-200 rounded-xl bg-slate-50/70 p-2 flex flex-col justify-between">
                <div className="space-y-1">
                  {Array.from({ length: halfCount }).map((_, idx) => {
                    const bagNum = idx + 1;
                    const w = bags[idx];
                    const hasVal = w !== undefined && !isNaN(w) && w > 0;
                    return (
                      <div
                        key={idx}
                        className={`flex items-center justify-between px-2 py-1 rounded-lg text-xs sm:text-sm font-mono ${
                          hasVal
                            ? 'bg-white border border-slate-200 text-slate-900'
                            : 'text-slate-300'
                        }`}
                      >
                        <span className="font-bold text-slate-500">{bagNum})</span>
                        <span className="font-black text-right">
                          {hasVal ? `${Number(w).toFixed(1)} kg` : '-'}
                        </span>
                      </div>
                    );
                  })}
                </div>
                {/* Column 1 Total (મોટા અક્ષરોમાં) */}
                <div className="mt-2 pt-2 border-t border-slate-300 flex items-center justify-between px-1 font-mono">
                  <span className="text-xs text-slate-600 font-bold">ટોટલ:</span>
                  <span className="font-black text-sm sm:text-base text-slate-900">
                    {leftTotal.toFixed(1)} kg
                  </span>
                </div>
              </div>

              {/* Column 2: Bags halfCount + 1 to End */}
              <div className="border border-slate-200 rounded-xl bg-slate-50/70 p-2 flex flex-col justify-between">
                <div className="space-y-1">
                  {Array.from({ length: halfCount }).map((_, idx) => {
                    const bagIdx = halfCount + idx;
                    const bagNum = bagIdx + 1;
                    const w = bags[bagIdx];
                    const hasVal = w !== undefined && !isNaN(w) && w > 0;
                    return (
                      <div
                        key={bagIdx}
                        className={`flex items-center justify-between px-2 py-1 rounded-lg text-xs sm:text-sm font-mono ${
                          hasVal
                            ? 'bg-white border border-slate-200 text-slate-900'
                            : 'text-slate-300'
                        }`}
                      >
                        <span className="font-bold text-slate-500">{bagNum})</span>
                        <span className="font-black text-right">
                          {hasVal ? `${Number(w).toFixed(1)} kg` : '-'}
                        </span>
                      </div>
                    );
                  })}
                </div>
                {/* Column 2 Total (મોટા અક્ષરોમાં) */}
                <div className="mt-2 pt-2 border-t border-slate-300 flex items-center justify-between px-1 font-mono">
                  <span className="text-xs text-slate-600 font-bold">ટોટલ:</span>
                  <span className="font-black text-sm sm:text-base text-slate-900">
                    {rightTotal > 0 ? `${rightTotal.toFixed(1)} kg` : '0 kg'}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Clean Summary Card matching receipt */}
          <div className="bg-emerald-50/80 border border-emerald-200 rounded-xl p-3 space-y-1.5 font-sans">
            {tare > 0 ? (
              <>
                <div className="flex items-center justify-between text-xs sm:text-sm font-bold text-slate-700">
                  <span>કુલ વજન:</span>
                  <span className="font-mono text-slate-950 font-black text-sm sm:text-base">
                    {grossWeight.toFixed(1)} kg
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs sm:text-sm font-bold text-slate-700">
                  <span>કુલ થેલી: {weighment.totalBagsCount}</span>
                  <span className="font-mono text-rose-700 font-black text-sm sm:text-base">
                    -{tare.toFixed(1)} kg
                  </span>
                </div>
                <div className="border-t border-emerald-300 my-1 pt-1.5 flex items-center justify-between">
                  <span className="text-sm font-black text-emerald-950">નેટ વજન:</span>
                  <span className="font-mono text-base sm:text-lg font-black text-emerald-950">
                    {netWeight.toFixed(1)} kg
                  </span>
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center justify-between text-xs sm:text-sm font-bold text-slate-700">
                  <span>કુલ થેલી:</span>
                  <span className="font-mono text-slate-950 font-black">
                    {weighment.totalBagsCount} થેલી
                  </span>
                </div>
                <div className="border-t border-emerald-300 my-1 pt-1.5 flex items-center justify-between">
                  <span className="text-sm font-black text-emerald-950">કુલ / નેટ વજન:</span>
                  <span className="font-mono text-base sm:text-lg font-black text-emerald-950">
                    {netWeight.toFixed(1)} kg
                  </span>
                </div>
              </>
            )}

            <div className="pt-1.5 border-t border-emerald-200 flex items-center justify-between text-xs text-slate-600">
              <span>
                ભાવ: <strong className="font-mono text-slate-800">₹{weighment.ratePer20Kg}</strong> / ૨૦ kg
              </span>
              <span>
                અંદાજિત રકમ: <strong className="font-mono text-emerald-800 text-sm font-black">{formatINR(weighment.calculatedAmount)}</strong>
              </span>
            </div>
          </div>
        </div>

        {/* Action Buttons Footer */}
        <div className="bg-slate-100 border-t border-slate-200 p-3 flex items-center justify-between gap-2 shrink-0 flex-wrap">
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              disabled={isPrinting}
              onClick={handlePrint}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-900 active:scale-95 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 shadow-xs transition cursor-pointer"
            >
              <Printer className="w-4 h-4 text-emerald-400" />
              <span>{isPrinting ? (printStatus || 'પ્રિન્ટિંગ...') : 'કાંટા પાવતી પ્રિન્ટ'}</span>
            </button>

            <button
              type="button"
              disabled={isPrinting}
              onClick={handlePrintCombined}
              className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white rounded-xl text-xs sm:text-sm font-black flex items-center gap-1.5 shadow-xs transition cursor-pointer"
              title="પહેલા વજનની વિગત અને નીચે બિલ બંને એકસાથે પ્રિન્ટ કરો"
            >
              <Layers className="w-4 h-4 text-emerald-200" />
              <span>વજન + બિલ પ્રિન્ટ</span>
            </button>

            {onLoadIntoSheet && (
              <button
                type="button"
                onClick={() => {
                  onLoadIntoSheet(weighment);
                  onClose();
                }}
                className="px-3 py-2 bg-white hover:bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 shadow-2xs transition cursor-pointer"
                title="આ વજનને ફરી શીટમાં લાવો જેથી એડિટ કરી શકાય"
              >
                <Edit3 className="w-4 h-4 text-emerald-700" />
                <span>શીટમાં એડિટ કરો</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 ml-auto">
            {onOpenBill && isPending && (
              <button
                type="button"
                onClick={() => {
                  onOpenBill(weighment);
                  onClose();
                }}
                className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1 shadow-xs transition cursor-pointer"
              >
                <span>બિલ બનાવો</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
            >
              બંધ કરો
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
