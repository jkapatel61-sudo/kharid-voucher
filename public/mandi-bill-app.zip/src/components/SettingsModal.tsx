import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Plus,
  Save,
  Store,
  Package,
  Check,
  Bluetooth,
  Printer,
  Clock,
  PowerOff,
  Radio,
  Loader2,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  FileCheck2,
  ArrowUp,
  ArrowDown,
  Trash2,
  Layers,
  GripVertical,
} from 'lucide-react';
import { FirmSettings, Product } from '../types';
import {
  disconnectBluetoothPrinter,
  isBluetoothConnected,
  isWebBluetoothSupported,
  pairOrConnectPrinter,
  printTestSlipViaBluetooth,
  getActiveBluetoothDeviceName,
  getSavedPairedPrinterName,
  setSavedPairedPrinterName,
  subscribeBluetoothStatus,
} from '../utils/bluetoothPrinter';

interface SettingsModalProps {
  products: Product[];
  settings: FirmSettings;
  onSaveProducts: (products: Product[]) => void;
  onSaveSettings: (settings: FirmSettings) => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  products,
  settings,
  onSaveProducts,
  onSaveSettings,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'products' | 'firm' | 'printer'>('printer');

  // Products state
  const [localProducts, setLocalProducts] = useState<Product[]>(products);
  const [newName, setNewName] = useState('');
  const [newRate, setNewRate] = useState('');
  const [draggedIdx, setDraggedIdx] = useState<number | null>(null);
  const [dragOverIdx, setDragOverIdx] = useState<number | null>(null);
  const itemRefs = useRef<(HTMLDivElement | null)[]>([]);
  const touchActiveIdx = useRef<number | null>(null);

  useEffect(() => {
    setLocalProducts(products);
  }, [products]);

  // Firm state
  const [firmForm, setFirmForm] = useState<FirmSettings>({
    ...settings,
    pairedPrinterName: settings.pairedPrinterName || getSavedPairedPrinterName() || 'PSF588',
    keepBluetoothConnected: settings.keepBluetoothConnected !== false,
  });
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Bluetooth Pairing State
  const [printerStatusMsg, setPrinterStatusMsg] = useState<string | null>(null);
  const [isPairing, setIsPairing] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [btConnected, setBtConnected] = useState<boolean>(() => isBluetoothConnected());

  useEffect(() => {
    const unsub = subscribeBluetoothStatus((connected) => {
      setBtConnected(connected);
    });
    return unsub;
  }, []);

  const handlePairPrinter = async () => {
    setIsPairing(true);
    setPrinterStatusMsg('PSF588 પ્રિન્ટર શોધી રહ્યું છે...');
    try {
      const targetName = (firmForm.pairedPrinterName || 'PSF588').trim();
      const res = await pairOrConnectPrinter(targetName, true, (msg) => {
        setPrinterStatusMsg(msg);
      });
      setBtConnected(true);
      setSavedPairedPrinterName(res.deviceName);
      const updated: FirmSettings = {
        ...firmForm,
        pairedPrinterName: res.deviceName,
        keepBluetoothConnected: true,
        autoDisconnectBluetooth: false,
      };
      setFirmForm(updated);
      onSaveSettings(updated);
      setPrinterStatusMsg(
        `✅ ${res.deviceName} સફળતાપૂર્વક પેર અને કનેક્ટ થઈ ગયું! હવે દર વખતે આપોઆપ સીધી પ્રિન્ટ નીકળશે.`
      );
    } catch (err: any) {
      if (err?.message === 'IFRAME_PERMISSION_ERROR') {
        setPrinterStatusMsg('IFRAME_PERMISSION_ERROR');
      } else {
        setPrinterStatusMsg(err?.message || 'પેરિંગ થઈ શક્યું નથી.');
      }
    } finally {
      setIsPairing(false);
    }
  };

  const handleTestPrint = async () => {
    setIsTesting(true);
    setPrinterStatusMsg('ટેસ્ટ સ્લિપ મોકલાઈ રહી છે...');
    try {
      await printTestSlipViaBluetooth(firmForm, (msg) => {
        setPrinterStatusMsg(msg);
      });
      setBtConnected(true);
      setPrinterStatusMsg('✅ ટેસ્ટ સ્લિપ પ્રિન્ટ થઈ ગઈ! PSF588 તૈયાર છે.');
    } catch (err: any) {
      if (err?.message === 'IFRAME_PERMISSION_ERROR') {
        setPrinterStatusMsg('IFRAME_PERMISSION_ERROR');
      } else {
        setPrinterStatusMsg(err?.message || 'ટેસ્ટ પ્રિન્ટ નિષ્ફળ. પ્રિન્ટર ચાલુ છે કે નહીં તે તપાસો.');
      }
    } finally {
      setIsTesting(false);
    }
  };

  const handleDisconnect = () => {
    disconnectBluetoothPrinter();
    setBtConnected(false);
    setPrinterStatusMsg('પ્રિન્ટર ડિસ્કનેક્ટ કરવામાં આવ્યું છે.');
    setTimeout(() => setPrinterStatusMsg(null), 3500);
  };

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    // Generate unique shortcut behind the scenes to keep data structure valid
    const existingShortcuts = new Set(localProducts.map((p) => (p.shortcut || '').toLowerCase()));
    let autoShortcut = newName.trim().charAt(0).toLowerCase();
    if (existingShortcuts.has(autoShortcut)) {
      autoShortcut = String.fromCharCode(97 + (localProducts.length % 26));
    }

    const newProd: Product = {
      id: `p_${Date.now()}`,
      name: newName.trim(),
      shortcut: autoShortcut,
      lastRatePer20Kg: parseFloat(newRate) || 500,
    };

    const updated = [...localProducts, newProd];
    setLocalProducts(updated);
    onSaveProducts(updated);

    setNewName('');
    setNewRate('');
    triggerSaveToast();
  };

  const handleUpdateRate = (id: string, rate: number) => {
    const updated = localProducts.map((p) =>
      p.id === id ? { ...p, lastRatePer20Kg: rate } : p
    );
    setLocalProducts(updated);
    onSaveProducts(updated);
  };

  const reorderItem = (fromIndex: number, toIndex: number) => {
    if (fromIndex === toIndex || fromIndex < 0 || toIndex < 0) return;
    const next = [...localProducts];
    const [moved] = next.splice(fromIndex, 1);
    next.splice(toIndex, 0, moved);
    setLocalProducts(next);
    onSaveProducts(next);
    triggerSaveToast();
  };

  const handleDragStart = (e: React.DragEvent, index: number) => {
    setDraggedIdx(index);
    e.dataTransfer.effectAllowed = 'move';
    try {
      e.dataTransfer.setData('text/plain', String(index));
    } catch {}
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (dragOverIdx !== index) {
      setDragOverIdx(index);
    }
  };

  const handleDrop = (e: React.DragEvent, targetIndex: number) => {
    e.preventDefault();
    if (draggedIdx !== null && draggedIdx !== targetIndex) {
      reorderItem(draggedIdx, targetIndex);
    }
    setDraggedIdx(null);
    setDragOverIdx(null);
  };

  const handleDragEnd = () => {
    setDraggedIdx(null);
    setDragOverIdx(null);
  };

  // Touch drag for mobile touchscreens
  const handleTouchStart = (index: number) => {
    touchActiveIdx.current = index;
    setDraggedIdx(index);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (touchActiveIdx.current === null) return;
    const clientY = e.touches[0].clientY;
    for (let i = 0; i < itemRefs.current.length; i++) {
      const el = itemRefs.current[i];
      if (el) {
        const rect = el.getBoundingClientRect();
        if (clientY >= rect.top && clientY <= rect.bottom) {
          setDragOverIdx(i);
          break;
        }
      }
    }
  };

  const handleTouchEnd = () => {
    const from = touchActiveIdx.current;
    const to = dragOverIdx;
    if (from !== null && to !== null && from !== to) {
      reorderItem(from, to);
    }
    touchActiveIdx.current = null;
    setDraggedIdx(null);
    setDragOverIdx(null);
  };

  const handleMoveUp = (index: number) => {
    if (index <= 0) return;
    reorderItem(index, index - 1);
  };

  const handleMoveDown = (index: number) => {
    if (index >= localProducts.length - 1) return;
    reorderItem(index, index + 1);
  };

  const handleDeleteProduct = (id: string, name: string) => {
    if (localProducts.length <= 1) {
      alert('ઓછામાં ઓછી એક પ્રોડક્ટ રાખવી જરૂરી છે.');
      return;
    }
    if (!window.confirm(`શું તમે "${name}" ને પ્રોડક્ટ લિસ્ટમાંથી કાઢી નાખવા માંગો છો?`)) {
      return;
    }
    const updated = localProducts.filter((p) => p.id !== id);
    setLocalProducts(updated);
    onSaveProducts(updated);
    triggerSaveToast();
  };

  const handleSaveFirm = (e: React.FormEvent) => {
    e.preventDefault();
    if (firmForm.pairedPrinterName) {
      setSavedPairedPrinterName(firmForm.pairedPrinterName);
    }
    onSaveSettings(firmForm);
    triggerSaveToast();
  };

  const triggerSaveToast = () => {
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <h2 className="font-bold text-slate-800 text-base">સેટિંગ્સ (વ્યવસ્થા)</h2>
          </div>
          <button
            id="close-settings-modal-btn"
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-200 bg-slate-100/70 p-1">
          <button
            id="tab-printer-btn"
            onClick={() => setActiveTab('printer')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition ${
              activeTab === 'printer'
                ? 'bg-white text-emerald-800 shadow-sm border border-emerald-600/20 ring-1 ring-emerald-600/30'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Bluetooth className="w-4 h-4 text-blue-600" />
            <span>PSF588 ઑટો-પેર</span>
            {isBluetoothConnected() && (
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            )}
          </button>

          <button
            id="tab-products-btn"
            onClick={() => setActiveTab('products')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition ${
              activeTab === 'products'
                ? 'bg-white text-emerald-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>પ્રોડક્ટ્સ ({localProducts.length})</span>
          </button>

          <button
            id="tab-firm-btn"
            onClick={() => setActiveTab('firm')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition ${
              activeTab === 'firm'
                ? 'bg-white text-emerald-700 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Store className="w-4 h-4" />
            <span>પેઢીની વિગત</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4">
          {savedSuccess && (
            <div className="p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-semibold flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>વિગતો સફળતાપૂર્વક સાચવાઈ ગઈ છે!</span>
            </div>
          )}

          {activeTab === 'products' && (
            <div className="space-y-4">
              {/* Instructions Banner */}
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs space-y-1 text-emerald-950">
                <div className="font-bold flex items-center gap-1.5 text-emerald-900">
                  <Layers className="w-4 h-4 text-emerald-700" />
                  <span>પ્રોડક્ટ્સ ક્રમ (પકડીને ઉપર-નીચે ગોઠવો)</span>
                </div>
                <p className="text-[11px] text-emerald-800 leading-relaxed">
                  કોઈપણ આઇટમને <strong>પકડીને (ડ્રેગ કરીને)</strong> અથવા બાજુના <strong>▲ ▼</strong> બટનથી ઉપર-નીચે ખસેડો.
                  પહેલી ૪ આઇટમ <strong>મુખ્ય સ્ક્રીન (સ્લાઇડ ૧)</strong> પર રહેશે, અને બાકીની આઇટમ <strong>બીજી સ્લાઇડ</strong>માં રહેશે.
                </p>
              </div>

              {/* Unified Product List */}
              <div className="space-y-2">
                <div className="flex items-center justify-between px-1">
                  <label className="text-xs font-black text-slate-800 uppercase tracking-wide">
                    કુલ પ્રોડક્ટ્સ ({localProducts.length})
                  </label>
                  <span className="text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full border border-emerald-200">
                    મુખ્ય સ્ક્રીન પર: પ્રથમ ૪ આઇટમ
                  </span>
                </div>

                <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden bg-white shadow-2xs">
                  {localProducts.map((p, idx) => {
                    const isSlide1 = idx < 4;
                    const isDragging = draggedIdx === idx;
                    const isDragOver = dragOverIdx === idx;

                    return (
                      <React.Fragment key={p.id}>
                        {/* Slide 2 Divider after item 4 */}
                        {idx === 4 && (
                          <div className="py-2 px-3 bg-amber-50 border-y border-dashed border-amber-300 text-center flex items-center justify-center gap-1.5 text-amber-900">
                            <span className="text-[11px] font-extrabold">
                              ⬇️ આ લીટીની નીચેની આઇટમ્સ બીજી સ્લાઇડમાં દેખાશે ({localProducts.length - 4} આઇટમ) ⬇️
                            </span>
                          </div>
                        )}

                        <div
                          ref={(el) => {
                            itemRefs.current[idx] = el;
                          }}
                          draggable
                          onDragStart={(e) => handleDragStart(e, idx)}
                          onDragOver={(e) => handleDragOver(e, idx)}
                          onDrop={(e) => handleDrop(e, idx)}
                          onDragEnd={handleDragEnd}
                          className={`p-2.5 sm:p-3 flex items-center justify-between gap-2 sm:gap-3 transition select-none ${
                            isDragging
                              ? 'bg-emerald-100/70 opacity-60 scale-[0.99]'
                              : isDragOver
                              ? 'bg-emerald-50 border-t-2 border-emerald-500'
                              : isSlide1
                              ? 'hover:bg-emerald-50/20'
                              : 'hover:bg-slate-50'
                          }`}
                        >
                          {/* Left: Drag Handle + Number + Clear Product Name */}
                          <div className="flex items-center gap-2 min-w-0 flex-1">
                            {/* Drag Handle */}
                            <div
                              className="touch-none cursor-grab active:cursor-grabbing p-1.5 -ml-1 text-slate-400 hover:text-emerald-700 active:text-emerald-800 rounded shrink-0 flex items-center justify-center"
                              title="પકડીને ઉપર-નીચે ખસેડો"
                              onTouchStart={() => handleTouchStart(idx)}
                              onTouchMove={handleTouchMove}
                              onTouchEnd={handleTouchEnd}
                              onTouchCancel={() => {
                                touchActiveIdx.current = null;
                                setDraggedIdx(null);
                                setDragOverIdx(null);
                              }}
                            >
                              <GripVertical className="w-5 h-5" />
                            </div>

                            {/* Number Badge */}
                            <span
                              className={`w-6 h-6 rounded-full font-black text-xs flex items-center justify-center shrink-0 ${
                                isSlide1
                                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                                  : 'bg-slate-100 text-slate-700 border border-slate-200'
                              }`}
                            >
                              {idx + 1}
                            </span>

                            {/* Clear Product Name (Spacious, bold, visible) */}
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="font-black text-slate-900 text-base sm:text-lg leading-tight">
                                  {p.name}
                                </span>
                                <span
                                  className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                                    isSlide1
                                      ? 'bg-emerald-100 text-emerald-800'
                                      : 'bg-blue-50 text-blue-700 border border-blue-200/50'
                                  }`}
                                >
                                  {isSlide1 ? '૧લી સ્લાઇડ' : '૨જી સ્લાઇડ'}
                                </span>
                              </div>
                            </div>
                          </div>

                          {/* Right: Rate Input + Simple Up/Down + Delete */}
                          <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
                            {/* Rate Input */}
                            <div className="flex items-center gap-0.5 sm:gap-1 bg-slate-100 px-2 py-1 rounded-lg border border-slate-200">
                              <span className="text-[11px] font-bold text-slate-500">₹</span>
                              <input
                                type="number"
                                value={p.lastRatePer20Kg}
                                onChange={(e) =>
                                  handleUpdateRate(p.id, parseFloat(e.target.value) || 0)
                                }
                                className="w-14 sm:w-16 bg-white font-bold text-slate-900 text-xs sm:text-sm px-1 py-0.5 rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-emerald-500 text-center"
                                title="ભાવ/૨૦kg"
                              />
                            </div>

                            {/* Move Up Button */}
                            <button
                              type="button"
                              disabled={idx === 0}
                              onClick={() => handleMoveUp(idx)}
                              className={`p-1.5 rounded-lg border transition ${
                                idx === 0
                                  ? 'text-slate-300 border-slate-100 cursor-not-allowed'
                                  : 'text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 border-slate-200 cursor-pointer active:scale-95'
                              }`}
                              title="ઉપર ખસેડો"
                            >
                              <ArrowUp className="w-3.5 h-3.5" />
                            </button>

                            {/* Move Down Button */}
                            <button
                              type="button"
                              disabled={idx === localProducts.length - 1}
                              onClick={() => handleMoveDown(idx)}
                              className={`p-1.5 rounded-lg border transition ${
                                idx === localProducts.length - 1
                                  ? 'text-slate-300 border-slate-100 cursor-not-allowed'
                                  : 'text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 border-slate-200 cursor-pointer active:scale-95'
                              }`}
                              title="નીચે ખસેડો"
                            >
                              <ArrowDown className="w-3.5 h-3.5" />
                            </button>

                            {/* Delete Button */}
                            <button
                              type="button"
                              onClick={() => handleDeleteProduct(p.id, p.name)}
                              className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition cursor-pointer"
                              title="કાઢી નાખો"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </React.Fragment>
                    );
                  })}
                </div>
              </div>

              {/* Add New Product Form */}
              <form
                onSubmit={handleAddProduct}
                className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-3"
              >
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
                  <Plus className="w-4 h-4 text-emerald-600" />
                  <span>નવી પ્રોડક્ટ ઉમેરો (દા.ત. મકાઈ, કપાસ, જીરૂ)</span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-600">માલનું નામ</label>
                    <input
                      type="text"
                      placeholder="દા.ત. મકાઈ"
                      value={newName}
                      onChange={(e) => setNewName(e.target.value)}
                      required
                      className="w-full text-xs font-medium px-2.5 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-600">
                      ભાવ (૨૦kg)
                    </label>
                    <input
                      type="number"
                      placeholder="દા.ત. 450"
                      value={newRate}
                      onChange={(e) => setNewRate(e.target.value)}
                      required
                      className="w-full text-xs font-medium px-2.5 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  id="add-new-product-submit"
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-2 rounded-lg transition shadow-sm cursor-pointer"
                >
                  પ્રોડક્ટ ઉમેરો
                </button>
              </form>
            </div>
          )}

          {activeTab === 'firm' && (
            <form onSubmit={handleSaveFirm} className="space-y-3">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">પેઢી / દુકાનનું નામ</label>
                <input
                  type="text"
                  value={firmForm.firmName}
                  onChange={(e) => setFirmForm({ ...firmForm, firmName: e.target.value })}
                  required
                  className="w-full text-sm font-semibold px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">
                  વિગત / ટેગલાઇન (અનાજ, કઠોળ...)
                </label>
                <input
                  type="text"
                  placeholder="અનાજ, કઠોળ, તેલીબીયા તથા કેટલફીડના વહેપારી"
                  value={firmForm.tagline || ''}
                  onChange={(e) => setFirmForm({ ...firmForm, tagline: e.target.value })}
                  className="w-full text-xs font-medium px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">GSTIN નંબર</label>
                  <input
                    type="text"
                    placeholder="24ADDPP1757F1ZP"
                    value={firmForm.gstNo || ''}
                    onChange={(e) => setFirmForm({ ...firmForm, gstNo: e.target.value })}
                    className="w-full text-xs font-mono font-semibold px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none uppercase"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">હોલસેલ લાઇસન્સ નં.</label>
                  <input
                    type="text"
                    placeholder="01/1998 Dt.25-08-1998"
                    value={firmForm.licenseNo || ''}
                    onChange={(e) => setFirmForm({ ...firmForm, licenseNo: e.target.value })}
                    className="w-full text-xs font-medium px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">મોબાઇલ નંબર(ઓ)</label>
                <input
                  type="text"
                  placeholder="9427077011, 9313172801"
                  value={firmForm.phone}
                  onChange={(e) => setFirmForm({ ...firmForm, phone: e.target.value })}
                  className="w-full text-xs font-medium px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">સરનામું ૧ (મંદિર પાસે)</label>
                  <input
                    type="text"
                    placeholder="હરસિદ્ધિ માતાના મંદિર પાસે"
                    value={firmForm.address}
                    onChange={(e) => setFirmForm({ ...firmForm, address: e.target.value })}
                    className="w-full text-xs font-medium px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700">સરનામું ૨ (ગામ / તાલુકો)</label>
                  <input
                    type="text"
                    placeholder="મુ. વાસણા, પો. મહિસા, તા. મહુધા, જી. ખેડા"
                    value={firmForm.addressLine2 || ''}
                    onChange={(e) => setFirmForm({ ...firmForm, addressLine2: e.target.value })}
                    className="w-full text-xs font-medium px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700">
                  સ્લિપ નીચે નોંધ (Footer Note)
                </label>
                <input
                  type="text"
                  value={firmForm.footerNote}
                  onChange={(e) => setFirmForm({ ...firmForm, footerNote: e.target.value })}
                  className="w-full text-xs font-medium px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              {/* Paper & Printer Configuration Link in Firm Tab */}
              <div className="p-3.5 bg-emerald-50/80 rounded-xl border border-emerald-200 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Bluetooth className="w-4 h-4 text-emerald-700" />
                    <span className="text-xs font-bold text-emerald-950">
                      PSF588 થર્મલ પ્રિન્ટર વ્યવસ્થા
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveTab('printer')}
                    className="px-2.5 py-1 text-xs font-bold bg-emerald-700 text-white rounded-lg hover:bg-emerald-800 transition cursor-pointer"
                  >
                    ઑટો-પેર સેટિંગ્સ ખોલો
                  </button>
                </div>
                <p className="text-[11px] text-emerald-800">
                  ડિફોલ્ટ પ્રિન્ટર: <strong>{firmForm.pairedPrinterName || 'PSF588'}</strong> • સ્થિતિ:{' '}
                  {isBluetoothConnected() ? '🟢 કનેક્ટેડ' : '⚪ ડિસ્કનેક્ટેડ'}
                </p>
              </div>

              <div className="flex items-center justify-between pt-1">
                <div>
                  <p className="text-xs font-bold text-slate-800">સેવ સાથે આપોઆપ પ્રિન્ટ ખોલો</p>
                  <p className="text-[11px] text-slate-500">
                    બિલ સેવ થતાની સાથે જ થર્મલ સ્લિપ પ્રિન્ટ થશે
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={firmForm.autoPrintOnSave}
                  onChange={(e) =>
                    setFirmForm({ ...firmForm, autoPrintOnSave: e.target.checked })
                  }
                  className="w-5 h-5 accent-emerald-600 rounded cursor-pointer"
                />
              </div>

              <button
                type="submit"
                id="save-firm-settings-btn"
                className="w-full bg-slate-900 hover:bg-black text-white text-xs font-bold py-2.5 rounded-xl transition flex items-center justify-center gap-2 shadow-sm"
              >
                <Save className="w-4 h-4" />
                <span>સેટિંગ્સ સાચવો (Save Settings)</span>
              </button>
            </form>
          )}

          {/* 🖨️ TAB 3: BLUETOOTH PRINTER & AUTO-PAIR SETTINGS (PSF588) */}
          {activeTab === 'printer' && (
            <div className="space-y-4 animate-fade-in">
              {/* Status Header Card */}
              <div
                className={`p-4 rounded-2xl border transition ${
                  btConnected || isBluetoothConnected()
                    ? 'bg-emerald-50/90 border-emerald-300 text-emerald-950'
                    : 'bg-slate-50 border-slate-200 text-slate-800'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                        btConnected || isBluetoothConnected()
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      <Bluetooth className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-sm">
                          {firmForm.pairedPrinterName || 'PSF588'}
                        </h3>
                        {btConnected || isBluetoothConnected() ? (
                          <span className="inline-flex items-center gap-1 bg-emerald-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full">
                            <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping"></span>
                            કનેક્ટેડ (ઑટો-પેર સક્રિય)
                          </span>
                        ) : (
                          <span className="bg-slate-200 text-slate-700 text-[10px] font-bold px-2 py-0.5 rounded-full">
                            ડિસ્કનેક્ટેડ
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        {btConnected || isBluetoothConnected()
                          ? 'પ્રિન્ટર કનેક્ટેડ છે. સેવ એન્ડ પ્રિન્ટ પર વારંવાર પેરિંગ ડાયલોગ નહીં આવે.'
                          : 'પ્રિન્ટર સાથે ૧ વાર પેરિંગ કરી લો જેથી Chrome તેને કાયમ યાદ રાખશે.'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Status Message / Alerts */}
                {printerStatusMsg && (
                  <div className="mt-3">
                    {printerStatusMsg === 'IFRAME_PERMISSION_ERROR' ? (
                      <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl text-xs space-y-2 text-left">
                        <div className="flex items-start gap-2 text-amber-950 font-semibold">
                          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                          <span>
                            બ્લૂટૂથ પ્રિન્ટર પેર કરવા માટે એપને Chrome ની નવી ટેબમાં ખોલવી જરૂરી છે.
                          </span>
                        </div>
                        <a
                          href={window.location.href}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center justify-center gap-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2 px-3 rounded-lg text-xs transition shadow-sm w-full text-center"
                        >
                          <ExternalLink className="w-4 h-4" />
                          <span>નવી ટેબમાં એપ ખોલો (Open in New Tab)</span>
                        </a>
                      </div>
                    ) : (
                      <div
                        className={`p-2.5 rounded-xl text-xs font-semibold flex items-center gap-2 ${
                          printerStatusMsg.includes('✅')
                            ? 'bg-emerald-100/90 text-emerald-900 border border-emerald-300'
                            : 'bg-blue-50 text-blue-900 border border-blue-200'
                        }`}
                      >
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span className="flex-1">{printerStatusMsg}</span>
                      </div>
                    )}
                  </div>
                )}

                {/* Primary Action Buttons */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-200/60">
                  {/* Pair Button */}
                  <button
                    type="button"
                    id="pair-psf588-btn"
                    onClick={handlePairPrinter}
                    disabled={isPairing}
                    className="flex items-center justify-center gap-2 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white py-2.5 px-3 rounded-xl font-bold text-xs shadow-sm transition disabled:opacity-50 cursor-pointer"
                  >
                    {isPairing ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>પેરિંગ થઈ રહ્યું છે...</span>
                      </>
                    ) : (
                      <>
                        <Bluetooth className="w-4 h-4" />
                        <span>{firmForm.pairedPrinterName || 'PSF588'} સાથે પેર કરો</span>
                      </>
                    )}
                  </button>

                  {/* Test Slip Button */}
                  <button
                    type="button"
                    id="test-slip-btn"
                    onClick={handleTestPrint}
                    disabled={isTesting}
                    className="flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-800 py-2.5 px-3 rounded-xl font-bold text-xs border border-slate-300 transition disabled:opacity-50 cursor-pointer"
                  >
                    {isTesting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>ટેસ્ટ પ્રિન્ટ થાય છે...</span>
                      </>
                    ) : (
                      <>
                        <FileCheck2 className="w-4 h-4 text-slate-600" />
                        <span>ટેસ્ટ સ્લિપ પ્રિન્ટ કરો</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Manual Disconnect */}
                {(btConnected || isBluetoothConnected()) && (
                  <div className="flex justify-end mt-2">
                    <button
                      type="button"
                      onClick={handleDisconnect}
                      className="text-[11px] text-slate-500 hover:text-red-600 font-semibold flex items-center gap-1 transition"
                    >
                      <PowerOff className="w-3 h-3 text-red-500" />
                      <span>પ્રિન્ટર ડિસ્કનેક્ટ / મુક્ત કરો</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Auto-Pair & Printer Preferences Form */}
              <form onSubmit={handleSaveFirm} className="space-y-3.5 bg-slate-50/80 p-4 rounded-2xl border border-slate-200">
                <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                  <Printer className="w-4 h-4 text-emerald-700" />
                  <h4 className="text-xs font-bold text-slate-800">ઑટો-પેરિંગ સેટિંગ્સ</h4>
                </div>

                {/* 1. Printer Name */}
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-700 block">
                    ડિફોલ્ટ પ્રિન્ટરનું નામ (Printer Name)
                  </label>
                  <input
                    type="text"
                    value={firmForm.pairedPrinterName || 'PSF588'}
                    onChange={(e) =>
                      setFirmForm({ ...firmForm, pairedPrinterName: e.target.value })
                    }
                    placeholder="દા.ત. PSF588"
                    className="w-full text-xs font-bold px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-mono"
                  />
                  <p className="text-[10.5px] text-slate-500">
                    આ નામ ધરાવતા બ્લૂટૂથ પ્રિન્ટર સાથે એપ આપોઆપ કનેક્ટ થઈ જશે.
                  </p>
                </div>

                {/* 2. Keep Bluetooth Connected (Zero Prompts) */}
                <div className="p-3 bg-white rounded-xl border border-slate-200 flex items-start justify-between gap-3">
                  <div>
                    <p className="text-xs font-bold text-slate-900">
                      કાયમી કનેક્શન ચાલુ રાખો (વારંવાર પેરિંગ ડાયલોગ રોકવા માટે)
                    </p>
                    <p className="text-[11px] text-emerald-800 mt-0.5">
                      ⚡ <strong>રેકમેન્ડેડ:</strong> પ્રિન્ટ પૂરી થયા પછી કનેક્શન ચાલુ રહેશે, જેથી દરેક બિલ ૧ સેકન્ડમાં સીધું નીકળશે અને Chrome નું "Wants to pair" ડાયલોગ વારંવાર નહીં આવે.
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={firmForm.keepBluetoothConnected !== false}
                    onChange={(e) =>
                      setFirmForm({
                        ...firmForm,
                        keepBluetoothConnected: e.target.checked,
                        autoDisconnectBluetooth: !e.target.checked,
                      })
                    }
                    className="w-5 h-5 accent-emerald-600 rounded cursor-pointer mt-0.5 shrink-0"
                  />
                </div>

                {/* 2.5. ઓફિસ ઑટો-પ્રિન્ટ સ્ટેશન (Cloud Remote Printing Relay) */}
                <div className="p-3.5 bg-emerald-50/70 rounded-xl border border-emerald-300 space-y-3">
                  <div className="flex items-center gap-2">
                    <Printer className="w-4 h-4 text-emerald-700 shrink-0" />
                    <span className="text-xs font-black text-emerald-950 uppercase tracking-wide">
                      ઓફિસ ઑટો-પ્રિન્ટ સ્ટેશન (ક્લાઉડ પ્રિન્ટિંગ)
                    </span>
                  </div>

                  <div className="space-y-2">
                    {/* Toggle: Is this device the Office Printer Station? */}
                    <div className="flex items-start justify-between gap-3 bg-white p-2.5 rounded-lg border border-emerald-200">
                      <div>
                        <p className="text-xs font-bold text-slate-900">
                          આ ફોન પર "ઑટો-પ્રિન્ટ સ્ટેશન" ચાલુ કરો
                        </p>
                        <p className="text-[11px] text-slate-600 mt-0.5">
                          જો આ ફોન ઓફિસમાં બ્લૂટૂથ પ્રિન્ટર સાથે જોડાયેલ હોય, તો અન્ય કોઈ પણ ફોનમાંથી બનતા બિલ અહીં આપોઆપ છપાઈ જશે.
                        </p>
                      </div>
                      <input
                        type="checkbox"
                        checked={Boolean(firmForm.isAutoPrintStation)}
                        onChange={(e) =>
                          setFirmForm({
                            ...firmForm,
                            isAutoPrintStation: e.target.checked,
                          })
                        }
                        className="w-5 h-5 accent-emerald-600 rounded cursor-pointer mt-0.5 shrink-0"
                      />
                    </div>

                    {/* Toggle: Send bills to office station when created on this phone */}
                    <div className="flex items-start justify-between gap-3 bg-white p-2.5 rounded-lg border border-emerald-200">
                      <div>
                        <p className="text-xs font-bold text-slate-900">
                          આ ફોનમાંથી બિલ બને ત્યારે ઓફિસ પ્રિન્ટર પર મોકલો
                        </p>
                        <p className="text-[11px] text-slate-600 mt-0.5">
                          બહાર યાર્ડ કે અન્ય જગ્યાએથી બિલ સેવ થતાં જ ઓફિસના પ્રિન્ટર પર ઓર્ડર જશે.
                        </p>
                      </div>
                      <input
                        type="checkbox"
                        checked={firmForm.cloudRemotePrintEnabled !== false}
                        onChange={(e) =>
                          setFirmForm({
                            ...firmForm,
                            cloudRemotePrintEnabled: e.target.checked,
                          })
                        }
                        className="w-5 h-5 accent-emerald-600 rounded cursor-pointer mt-0.5 shrink-0"
                      />
                    </div>

                    {/* Toggle: Sound chime */}
                    <div className="flex items-start justify-between gap-3 bg-white p-2.5 rounded-lg border border-emerald-200">
                      <div>
                        <p className="text-xs font-bold text-slate-900">
                          પ્રિન્ટ વખતે ડીંગ-ડોંગ અવાજ (Chime Alert)
                        </p>
                        <p className="text-[11px] text-slate-600 mt-0.5">
                          રિમોટ બિલ પ્રિન્ટ થાય ત્યારે અવાજ સંભળાશે જેથી સ્ટાફને તરત ખબર પડે.
                        </p>
                      </div>
                      <input
                        type="checkbox"
                        checked={firmForm.playChimeOnAutoPrint !== false}
                        onChange={(e) =>
                          setFirmForm({
                            ...firmForm,
                            playChimeOnAutoPrint: e.target.checked,
                          })
                        }
                        className="w-5 h-5 accent-emerald-600 rounded cursor-pointer mt-0.5 shrink-0"
                      />
                    </div>
                  </div>
                </div>

                {/* 3. Paper Size */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">
                    કાગળની પહોળાઈ (Thermal Paper Width)
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setFirmForm({ ...firmForm, paperWidth: '58mm' })}
                      className={`p-2.5 rounded-xl border text-center transition cursor-pointer ${
                        (firmForm.paperWidth || '58mm') === '58mm'
                          ? 'bg-emerald-700 text-white border-emerald-800 font-bold shadow-2xs'
                          : 'bg-white text-slate-700 border-slate-300 font-medium'
                      }`}
                    >
                      <span className="text-xs block font-bold">58mm (૨ ઇંચ)</span>
                      <span className={`text-[10px] block ${firmForm.paperWidth === '58mm' ? 'text-emerald-100' : 'text-slate-500'}`}>
                        PSF588 માટે ડિફોલ્ટ
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setFirmForm({ ...firmForm, paperWidth: '80mm' })}
                      className={`p-2.5 rounded-xl border text-center transition cursor-pointer ${
                        firmForm.paperWidth === '80mm'
                          ? 'bg-emerald-700 text-white border-emerald-800 font-bold shadow-2xs'
                          : 'bg-white text-slate-700 border-slate-300 font-medium'
                      }`}
                    >
                      <span className="text-xs block font-bold">80mm (૩ ઇંચ)</span>
                      <span className={`text-[10px] block ${firmForm.paperWidth === '80mm' ? 'text-emerald-100' : 'text-slate-500'}`}>
                        મોટા થર્મલ રોલ માટે
                      </span>
                    </button>
                  </div>
                </div>

                {/* 4. Print Method */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 block">
                    પ્રિન્ટ પદ્ધતિ (Print Method)
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setFirmForm({ ...firmForm, printMethod: 'bluetooth' })}
                      className={`p-2 rounded-xl border text-left flex items-start gap-2 transition cursor-pointer ${
                        (firmForm.printMethod || 'bluetooth') === 'bluetooth'
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-950 font-bold ring-1 ring-emerald-500/30'
                          : 'border-slate-200 bg-white text-slate-600 font-medium'
                      }`}
                    >
                      <Bluetooth className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                      <div>
                        <p className="text-xs">બ્લૂટૂથ ડાયરેક્ટ</p>
                        <p className="text-[10px] text-slate-500">PSF588 પર સીધી પ્રિન્ટ</p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setFirmForm({ ...firmForm, printMethod: 'system' })}
                      className={`p-2 rounded-xl border text-left flex items-start gap-2 transition cursor-pointer ${
                        firmForm.printMethod === 'system'
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-950 font-bold ring-1 ring-emerald-500/30'
                          : 'border-slate-200 bg-white text-slate-600 font-medium'
                      }`}
                    >
                      <Printer className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
                      <div>
                        <p className="text-xs">સિસ્ટમ પ્રિન્ટ</p>
                        <p className="text-[10px] text-slate-500">બ્રાઉઝર ડાયલોગ દ્વારા</p>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Connection Health & Tips Box */}
                <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl text-xs space-y-1.5 text-slate-700">
                  <div className="font-bold text-blue-950 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                    <span>પ્રિન્ટર કનેક્શન સતત ચાલુ રાખવાના ઉપાયો:</span>
                  </div>
                  <ul className="list-disc pl-5 space-y-1 text-[11px] text-slate-600">
                    <li>
                      <strong>ઑટો કીપ-અલાઇવ:</strong> એપ દર ૧૫ સેકન્ડે પ્રિન્ટરને સાયલન્ટ સિગ્નલ મોકલે છે જેથી પ્રિન્ટર સ્લીપ (Sleep) મોડમાં ન જાય.
                    </li>
                    <li>
                      <strong>સ્ક્રીન વેક-લૉક:</strong> બિલિંગ પેજ ખુલ્લું હોય ત્યારે મોબાઇલની સ્ક્રીન આપોઆપ ચાલુ રહે છે જેથી બ્લૂટૂથ કનેક્શન કટ ન થાય.
                    </li>
                    <li>
                      <strong>હોમ સ્ક્રીન પર સેવ કરો:</strong> Chrome બ્રાઉઝરમાં ઉપરના ૩ ટપકાં (⋮) પર ક્લિક કરી <em>"Add to Home Screen"</em> (હોમ સ્ક્રીન પર ઉમેરો) કરી લેશો તો કાયમી એપની જેમ ચાલશે.
                    </li>
                  </ul>
                </div>

                {/* Save Button */}
                <button
                  type="submit"
                  id="save-printer-settings-btn"
                  className="w-full bg-slate-900 hover:bg-black text-white text-xs font-bold py-3 rounded-xl transition flex items-center justify-center gap-2 shadow-sm cursor-pointer active:scale-98"
                >
                  <Save className="w-4 h-4" />
                  <span>પ્રિન્ટર સેટિંગ્સ સાચવો (Save Settings)</span>
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
