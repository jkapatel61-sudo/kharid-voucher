import React, { useState, useEffect, useRef } from 'react';
import {
  CheckCircle,
  Save,
  ChevronRight,
  X,
  FileSpreadsheet,
  Plus,
  ArrowLeft,
} from 'lucide-react';
import { Product } from '../types';
import {
  KantaWeighment,
  saveKantaWeighmentToCloud,
  subscribeToWeighments,
} from '../utils/firebaseSync';
import { formatINR, getActiveBusinessDate } from '../utils/storage';

const KANTA_DRAFT_KEY = 'mandi_kanta_active_draft_v1';

interface KantaDraftData {
  customerName: string;
  selectedProductId: string;
  rate: string;
  totalSlots: number;
  bagList: string[];
  tareDeduction: string;
  isSheetOpen: boolean;
  timestamp: number;
}

const getStoredKantaDraft = (): KantaDraftData | null => {
  try {
    const raw = localStorage.getItem(KANTA_DRAFT_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed && Array.isArray(parsed.bagList)) {
      return parsed;
    }
  } catch (e) {
    console.error('Failed to load kanta draft:', e);
  }
  return null;
};

const saveKantaDraft = (data: Partial<KantaDraftData>) => {
  try {
    const prev = getStoredKantaDraft() || {
      customerName: '',
      selectedProductId: '',
      rate: '',
      totalSlots: 10,
      bagList: Array(10).fill(''),
      tareDeduction: '',
      isSheetOpen: false,
      timestamp: Date.now(),
    };
    const updated = {
      ...prev,
      ...data,
      timestamp: Date.now(),
    };
    localStorage.setItem(KANTA_DRAFT_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error('Failed to save kanta draft:', e);
  }
};

const clearKantaDraft = () => {
  try {
    localStorage.removeItem(KANTA_DRAFT_KEY);
  } catch (e) {}
};

interface KantaEntryViewProps {
  products: Product[];
  onOpenBillForWeighment?: (weighment: KantaWeighment) => void;
  onViewAllRecords?: () => void;
  initialWeighmentToEdit?: KantaWeighment | null;
  onClearInitialWeighmentToEdit?: () => void;
}

export const KantaEntryView: React.FC<KantaEntryViewProps> = ({
  products,
  onOpenBillForWeighment,
  onViewAllRecords,
  initialWeighmentToEdit,
  onClearInitialWeighmentToEdit,
}) => {
  // Read saved draft so mobile screen-off or browser reload never loses entered weights
  const initialDraft = useRef(getStoredKantaDraft()).current;

  // 1. Farmer Name
  const [customerName, setCustomerName] = useState(() => initialDraft?.customerName || '');

  // 2. Product & Rate
  const [selectedProductId, setSelectedProductId] = useState<string>(
    () => initialDraft?.selectedProductId || products[0]?.id || 'p_bajri'
  );
  const [rate, setRate] = useState<string>(
    () => initialDraft?.rate || products[0]?.lastRatePer20Kg?.toString() || '475'
  );

  // 3. Weight Sheet State - Start with 1 to 20 (2 columns of 10) filling the screen width
  const [isSheetOpen, setIsSheetOpen] = useState(() => Boolean(initialDraft?.isSheetOpen));
  const [totalSlots, setTotalSlots] = useState<number>(() => {
    if (initialDraft?.totalSlots) return Math.max(20, initialDraft.totalSlots);
    if (initialDraft?.bagList?.length) return Math.max(20, Math.ceil(initialDraft.bagList.length / 20) * 20);
    return 20;
  });
  const [bagList, setBagList] = useState<string[]>(() => {
    if (initialDraft?.bagList && initialDraft.bagList.length > 0) {
      if (initialDraft.bagList.length < 20) {
        return [...initialDraft.bagList, ...Array(20 - initialDraft.bagList.length).fill('')];
      }
      return initialDraft.bagList;
    }
    return Array(20).fill('');
  });

  // 4. Tare Deduction (કપાત વજન)
  const [tareDeduction, setTareDeduction] = useState<string>(() => initialDraft?.tareDeduction || '');

  // Cloud Weighments & Saving State
  const [cloudWeighments, setCloudWeighments] = useState<KantaWeighment[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  const [saveToast, setSaveToast] = useState<string | null>(null);

  const customerInputRef = useRef<HTMLInputElement>(null);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Load a saved weighment back into the active weighing sheet for viewing or editing
  const handleLoadIntoSheet = (entry: KantaWeighment) => {
    setCustomerName(entry.customerName || '');
    if (entry.productId) setSelectedProductId(entry.productId);
    if (entry.ratePer20Kg) setRate(entry.ratePer20Kg.toString());
    setTareDeduction(entry.tareWeightKg ? entry.tareWeightKg.toString() : '');

    const newBags = (entry.bags || []).map((b) =>
      b !== undefined && b !== null ? b.toString() : ''
    );
    const neededSlots = Math.max(20, Math.ceil(newBags.length / 20) * 20);
    const paddedBags = [
      ...newBags,
      ...Array(Math.max(0, neededSlots - newBags.length)).fill(''),
    ];
    setTotalSlots(neededSlots);
    setBagList(paddedBags);
    setIsSheetOpen(true);
    setSaveToast(`ખેડૂત ${entry.customerName} ના વજન શીટમાં ખુલ્યા છે.`);
    setTimeout(() => setSaveToast(null), 3000);
  };

  // Handle incoming weighment to edit
  useEffect(() => {
    if (initialWeighmentToEdit) {
      handleLoadIntoSheet(initialWeighmentToEdit);
      onClearInitialWeighmentToEdit?.();
    }
  }, [initialWeighmentToEdit]);

  // Keep mobile screen awake while weighing scale is open
  useEffect(() => {
    let sentinel: any = null;

    const requestWakeLock = async () => {
      try {
        if ('wakeLock' in navigator && (navigator as any).wakeLock) {
          sentinel = await (navigator as any).wakeLock.request('screen');
        }
      } catch (e) {
        // gracefully ignore if wake lock is unavailable or blocked
      }
    };

    requestWakeLock();

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        requestWakeLock();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      if (sentinel) {
        try {
          sentinel.release();
        } catch (e) {}
      }
    };
  }, []);

  // Continuous auto-save draft to localStorage whenever any value changes
  useEffect(() => {
    saveKantaDraft({
      customerName,
      selectedProductId,
      rate,
      totalSlots,
      bagList,
      tareDeduction,
      isSheetOpen,
    });
  }, [customerName, selectedProductId, rate, totalSlots, bagList, tareDeduction, isSheetOpen]);

  // Subscribe to live cloud weighments
  useEffect(() => {
    const unsub = subscribeToWeighments((list) => {
      setCloudWeighments(list);
    });
    return () => unsub();
  }, []);

  // When selected product changes
  const handleProductSelect = (prod: Product) => {
    setSelectedProductId(prod.id);
    const newRate = prod.lastRatePer20Kg.toString();
    setRate(newRate);
    saveKantaDraft({ selectedProductId: prod.id, rate: newRate });
  };

  const selectedProduct =
    products.find((p) => p.id === selectedProductId) || products[0] || {
      id: 'p_bajri',
      name: 'બાજરી',
      lastRatePer20Kg: 475,
    };

  // Calculations: Bags, Gross Weight, Deduction, Net Weight
  const validBags = bagList
    .map((b) => parseFloat(b))
    .filter((n) => !isNaN(n) && n > 0);

  const totalBagsCount = validBags.length;
  const grossWeightKg =
    Math.round(validBags.reduce((acc, v) => acc + v, 0) * 100) / 100;

  const deductionNum = parseFloat(tareDeduction) || 0;
  const netWeightKg = Math.max(
    0,
    Math.round((grossWeightKg - deductionNum) * 100) / 100
  );

  const rateNum = parseFloat(rate) || 0;
  const calculatedAmount = Math.round((netWeightKg / 20) * rateNum);

  // Calculate 10-line block subtotal (e.g. 1-10, 11-20, 21-30)
  const getBlockTotal = (startIdx: number) => {
    let sum = 0;
    for (let i = startIdx; i < startIdx + 10; i++) {
      const v = parseFloat(bagList[i]);
      if (!isNaN(v) && v > 0) sum += v;
    }
    return Math.round(sum * 100) / 100;
  };

  // Move down to next row smoothly when weight ends with .0 or .5
  const handleBagChange = (index: number, val: string) => {
    const updated = [...bagList];
    updated[index] = val;
    setBagList(updated);
    saveKantaDraft({ bagList: updated });

    const trimmed = val.trim();

    // When ending with .0 or .5 (e.g. 45.5 or 40.0), move focus to the line below
    if (/^\d{1,3}\.(0|5)$/.test(trimmed)) {
      const nextIndex = index + 1;
      if (nextIndex < totalSlots) {
        setTimeout(() => {
          inputRefs.current[nextIndex]?.focus();
        }, 50);
      }
    }
  };

  // Handle key navigation (Enter goes to next line, Backspace goes to previous)
  const handleKeyDown = (
    index: number,
    e: React.KeyboardEvent<HTMLInputElement>
  ) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const nextIndex = index + 1;
      if (nextIndex < totalSlots) {
        inputRefs.current[nextIndex]?.focus();
      }
    } else if (e.key === 'Backspace' && !bagList[index] && index > 0) {
      e.preventDefault();
      inputRefs.current[index - 1]?.focus();
    }
  };

  // Check if current 20-slot set is completely filled (જ્યાં સુધી ૨૦ પૂરી ના થાય ત્યાં સુધી +૨૦ ના થવું જોઈએ)
  // All slots up to totalSlots must have a valid number > 0 entered
  const isCurrentSheetFull =
    totalSlots > 0 &&
    bagList.slice(0, totalSlots).every((b) => {
      const n = parseFloat(b);
      return !isNaN(n) && n > 0;
    });

  // Remaining bags to fill before +20 can be unlocked
  const filledSlotsCount = bagList
    .slice(0, totalSlots)
    .filter((b) => !isNaN(parseFloat(b)) && parseFloat(b) > 0).length;
  const remainingToFill = totalSlots - filledSlotsCount;

  // Add more slots (+20 bags: 21-40, 41-60, etc.) - Only if all 20 lines are filled
  const handleAddMoreSlots = () => {
    if (!isCurrentSheetFull) {
      alert(`પહેલા ચાલુ ૨૦ લાઇનનું વજન પૂરેપૂરું ભરો (${remainingToFill} થેલી ભરવાની બાકી છે). ૨૦ લાઈન ભરાય પછી જ +૨૦ થશે.`);
      return;
    }
    const newTotal = totalSlots + 20;
    const newBagList = [...bagList, ...Array(20).fill('')];
    setTotalSlots(newTotal);
    setBagList(newBagList);
    saveKantaDraft({ totalSlots: newTotal, bagList: newBagList });
    setTimeout(() => {
      inputRefs.current[totalSlots]?.focus();
    }, 100);
  };

  // Reset current form for next farmer
  const handleResetForm = () => {
    clearKantaDraft();
    setCustomerName('');
    setTotalSlots(20);
    setBagList(Array(20).fill(''));
    setTareDeduction('');
    customerInputRef.current?.focus();
  };

  // Save to Firebase Cloud from the main page
  const handleSaveWeighment = async () => {
    if (validBags.length === 0) {
      alert('કૃપા કરીને ઓછામાં ઓછી ૧ થેલીનું વજન દાખલ કરો.');
      setIsSheetOpen(true);
      return;
    }

    setIsSaving(true);
    try {
      const now = new Date();
      const timeStr = now.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
      });

      const newEntry: KantaWeighment = {
        id: `kanta_${Date.now()}`,
        date: getActiveBusinessDate(),
        time: timeStr,
        customerName: customerName.trim() || 'સામાન્ય ખેડૂત',
        productId: selectedProduct.id,
        productName: selectedProduct.name,
        ratePer20Kg: rateNum,
        bags: validBags,
        totalBagsCount,
        totalWeightKg: netWeightKg, // Final net weight after tare deduction
        ...(deductionNum > 0 ? { tareWeightKg: deductionNum } : {}),
        calculatedAmount,
        status: 'pending',
        createdAt: Date.now(),
      };

      await saveKantaWeighmentToCloud(newEntry);

      clearKantaDraft();
      setIsSheetOpen(false);
      setSaveToast(
        `✅ ${newEntry.customerName} - ${totalBagsCount} થેલી (${netWeightKg} kg) સેવ થઈ ગયું!`
      );
      setTimeout(() => setSaveToast(null), 4000);

      // Reset for next farmer
      handleResetForm();
    } catch (err: any) {
      alert(`સેવ કરવામાં એરર: ${err.message || 'ઇન્ટરનેટ કનેક્શન તપાસો'}`);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-4 pb-12">
      {saveToast && (
        <div className="p-3.5 bg-emerald-100 border border-emerald-300 text-emerald-950 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle className="w-5 h-5 text-emerald-700 shrink-0" />
          <span>{saveToast}</span>
        </div>
      )}

      {/* Main Entry Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-2xs space-y-4">
        {/* Step 1: Customer Name */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1">
            ૧. ખેડૂત / ગ્રાહકનું નામ
          </label>
          <div className="relative">
            <input
              ref={customerInputRef}
              type="text"
              placeholder="ખેડૂતનું નામ લખો..."
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  setIsSheetOpen(true);
                }
              }}
              className="w-full px-3.5 py-2.5 text-base font-bold text-slate-900 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
            {customerName && (
              <button
                type="button"
                onClick={() => {
                  setCustomerName('');
                  customerInputRef.current?.focus();
                }}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 font-bold cursor-pointer"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Step 2: Product Selection - Exactly 3 items visible, remaining horizontally slideable without extra text */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="block text-xs font-bold text-slate-700">
              ૨. માલ પસંદ કરો અને ભાવ
            </label>
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1">
              <span className="text-xs font-bold text-slate-600">ભાવ ₹</span>
              <input
                type="number"
                value={rate}
                onChange={(e) => {
                  setRate(e.target.value);
                  saveKantaDraft({ rate: e.target.value });
                }}
                className="w-16 font-mono font-black text-sm text-slate-900 focus:outline-none text-right"
              />
              <span className="text-[11px] text-slate-500">/૨૦kg</span>
            </div>
          </div>

          {/* Horizontal Slide Row: Exactly 3 items visible on screen, smooth swipe */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1.5 pt-0.5 no-scrollbar snap-x -mx-1 px-1">
            {products.map((prod) => {
              const isSelected = prod.id === selectedProductId;
              const displayRate = isSelected && rate !== '' ? rate : prod.lastRatePer20Kg;
              return (
                <button
                  key={prod.id}
                  type="button"
                  onClick={() => handleProductSelect(prod)}
                  className={`w-[31.5%] min-w-[102px] shrink-0 p-2.5 rounded-xl text-center border font-bold text-xs sm:text-sm transition cursor-pointer active:scale-95 snap-start ${
                    isSelected
                      ? 'bg-emerald-700 text-white border-emerald-800 shadow-xs'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <div className="truncate">{prod.name}</div>
                  <div
                    className={`text-[11px] font-mono mt-0.5 ${
                      isSelected ? 'text-emerald-100 font-bold' : 'text-slate-500'
                    }`}
                  >
                    ₹{displayRate}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Step 3: Weight Entry Box - Just 'વજન નોંધો' */}
        <div className="pt-2 border-t border-slate-100">
          <button
            type="button"
            onClick={() => setIsSheetOpen(true)}
            className="w-full py-4 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-black text-base sm:text-lg flex items-center justify-center gap-2.5 shadow-md transition cursor-pointer active:scale-98"
          >
            <FileSpreadsheet className="w-5 h-5 shrink-0" />
            <span>વજન નોંધો</span>
          </button>
        </div>

        {/* Live Calculation Summary Banner: Only Bags & Net Weight in kg */}
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 grid grid-cols-2 gap-2 text-center">
          <div>
            <div className="text-[11px] font-bold text-emerald-800">કુલ થેલીઓ</div>
            <div className="text-base sm:text-lg font-black text-emerald-950">
              {totalBagsCount} થેલી
            </div>
          </div>
          <div>
            <div className="text-[11px] font-bold text-emerald-800">
              કુલ વજન (નેટ)
            </div>
            <div className="text-base sm:text-lg font-black text-emerald-950 font-mono">
              {netWeightKg}{' '}
              <span className="text-xs text-emerald-700">kg</span>
              {deductionNum > 0 && (
                <div className="text-[11px] text-rose-700 font-bold">
                  (કપાત: -{deductionNum} kg)
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Action Button: Save Weight */}
        <div className="pt-1">
          <button
            type="button"
            disabled={isSaving || validBags.length === 0}
            onClick={handleSaveWeighment}
            className="w-full py-3.5 px-4 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 disabled:opacity-50 text-white rounded-xl font-black text-sm sm:text-base flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
          >
            <Save className="w-5 h-5" />
            <span>
              {isSaving ? 'સેવ થાય છે...' : 'સેવ કરો'}
            </span>
          </button>
        </div>
      </div>

      {/* Button to navigate to Dedicated Records Page */}
      {onViewAllRecords && (
        <button
          type="button"
          onClick={onViewAllRecords}
          className="w-full py-3.5 px-4 bg-white hover:bg-emerald-50 active:bg-emerald-100 text-slate-800 hover:text-emerald-950 border border-slate-200 hover:border-emerald-300 rounded-2xl font-black text-sm sm:text-base flex items-center justify-between shadow-2xs transition cursor-pointer active:scale-98"
        >
          <div className="flex items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>આજના કાંટા વજન જુઓ</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-bold">
            <span className="bg-emerald-100 text-emerald-900 px-2.5 py-0.5 rounded-full font-mono font-bold">
              {cloudWeighments.length} એન્ટ્રી
            </span>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </div>
        </button>
      )}

      {/* ========================================================================= */}
      {/* DEDICATED FULL SCREEN WEIGHT SHEET PAGE (આખું પેજ) */}
      {/* ========================================================================= */}
      {isSheetOpen && (
        <div className="fixed inset-0 z-50 bg-slate-50 flex flex-col w-full h-full">
          {/* Full Page Top Header */}
          <div className="bg-gradient-to-r from-teal-900 via-emerald-800 to-teal-900 text-white px-4 py-3 shrink-0 flex items-center justify-between shadow-xs">
            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={() => setIsSheetOpen(false)}
                className="p-1.5 hover:bg-white/10 rounded-lg text-white/80 hover:text-white transition cursor-pointer"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <h3 className="font-black text-base leading-tight">
                  વજન પત્રક (થેલી ૧ થી {totalSlots})
                </h3>
                <p className="text-[11px] text-emerald-100">
                  {customerName.trim() || 'સામાન્ય ખેડૂત'} • {selectedProduct.name}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsSheetOpen(false)}
              className="p-1.5 bg-white/10 hover:bg-white/20 rounded-full text-white transition cursor-pointer"
              title="બંધ કરો"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Live Sticky Summary Bar: Bags, Net Weight in kg, and +10 Button */}
          <div className="bg-emerald-50 border-b border-emerald-200 px-4 py-2 shrink-0 flex items-center justify-between text-xs shadow-2xs">
            <div className="flex items-center gap-1.5 font-bold text-emerald-900">
              <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
              <span>કુલ થેલીઓ:</span>
              <span className="text-sm font-black text-emerald-950 font-mono">
                {totalBagsCount}
              </span>
            </div>

            <div className="flex items-center gap-1.5 font-bold text-emerald-900">
              <span>નેટ વજન:</span>
              <span className="text-sm sm:text-base font-black text-emerald-950 font-mono">
                {netWeightKg}
              </span>
            </div>

            {/* +20 Button in Header to add 20 more slots (Only unlocked when all 20 lines are filled) */}
            <button
              type="button"
              disabled={!isCurrentSheetFull}
              onClick={handleAddMoreSlots}
              className={`px-3.5 py-1.5 font-black text-xs sm:text-sm rounded-xl shadow-xs flex items-center gap-1 transition shrink-0 ${
                isCurrentSheetFull
                  ? 'bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white cursor-pointer ring-2 ring-emerald-400'
                  : 'bg-slate-200 text-slate-400 border border-slate-300 cursor-not-allowed opacity-60'
              }`}
              title={
                isCurrentSheetFull
                  ? 'આગળની ૨૦ થેલીનું નવું પત્રક ઉમેરો (+20)'
                  : `પહેલા ૨૦ લાઇન પૂરેપૂરી ભરો (${remainingToFill} બાકી છે)`
              }
            >
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
              <span>+20</span>
            </button>
          </div>

          {/* Main Weight Sheet Grid: 2 columns of 10 = 20 lines, fully utilizing screen width without side voids */}
          <div className="flex-1 overflow-x-auto overflow-y-auto px-2 sm:px-3 pt-2 pb-1 no-scrollbar flex flex-col">
            <div className="flex flex-nowrap gap-2 items-stretch h-full flex-1 w-full max-w-xl mx-auto min-h-[380px]">
              {Array.from({ length: Math.ceil(totalSlots / 10) }).map(
                (_, colIdx) => {
                  const start = colIdx * 10;

                  return (
                    <div
                      key={colIdx}
                      className="flex-1 min-w-[140px] max-w-[220px] shrink-0 h-full flex flex-col justify-between bg-white border border-slate-200 rounded-xl p-1.5 shadow-2xs"
                    >
                      {/* 10 Bag Inputs distributed evenly so rows fill the card vertically */}
                      <div className="flex-1 flex flex-col justify-between gap-1 py-0.5">
                        {Array.from({ length: 10 }).map((_, rIdx) => {
                          const bagIdx = start + rIdx;
                          if (bagIdx >= totalSlots) return null;
                          const hasVal = Boolean(bagList[bagIdx]);
                          return (
                            <div
                              key={bagIdx}
                              className={`flex-1 min-h-[32px] max-h-[44px] flex items-center gap-1 border rounded-lg px-1.5 transition ${
                                hasVal
                                  ? 'bg-emerald-50/40 border-emerald-300 shadow-2xs'
                                  : 'bg-white border-slate-200 focus-within:border-emerald-500 focus-within:ring-1 focus-within:ring-emerald-400/40'
                              }`}
                            >
                              <span className="text-xs font-black text-slate-500 w-5 shrink-0 text-right">
                                {bagIdx + 1})
                              </span>
                              <input
                                ref={(el) => (inputRefs.current[bagIdx] = el)}
                                type="text"
                                inputMode="decimal"
                                value={bagList[bagIdx] || ''}
                                onChange={(e) =>
                                  handleBagChange(bagIdx, e.target.value)
                                }
                                onKeyDown={(e) => handleKeyDown(bagIdx, e)}
                                className="w-full text-center font-mono font-black text-sm sm:text-base text-slate-900 bg-transparent py-0.5 focus:outline-none"
                              />
                            </div>
                          );
                        })}
                      </div>

                      {/* Subtotal directly below bag #10: "ટોટલ: XX kg" */}
                      <div className="pt-1 mt-1 border-t border-slate-200 flex items-center justify-between px-1.5 py-1 bg-slate-100/90 rounded-lg shrink-0">
                        <span className="text-[11px] font-bold text-slate-700">
                          ટોટલ:
                        </span>
                        <span className="font-mono font-black text-emerald-950 text-xs">
                          {getBlockTotal(start)} kg
                        </span>
                      </div>
                    </div>
                  );
                }
              )}
            </div>
          </div>

          {/* Bottom Actions: Always visible */}
          <div className="bg-white border-t border-slate-200 p-2 sm:p-2.5 shrink-0 shadow-lg">
            <div className="max-w-md mx-auto space-y-2">
              {/* Line between Totals and Save Button: કુલ વજન - કપાત = નેટ વજન */}
              <div className="flex items-center justify-between px-3 py-2 bg-emerald-50/90 border border-emerald-200 rounded-xl text-xs sm:text-sm font-black">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-slate-700">કુલ વજન:</span>
                  <span className="font-mono text-slate-950 text-sm sm:text-base">
                    {grossWeightKg}
                  </span>
                  <span className="text-slate-400 font-bold">-</span>
                  <span className="font-mono text-rose-700 text-sm sm:text-base">
                    {deductionNum}
                  </span>
                  <span className="text-slate-400 font-bold">=</span>
                  <span className="font-mono text-emerald-900 text-base sm:text-lg font-black">
                    {netWeightKg}
                  </span>
                </div>

                {/* Tare deduction input box */}
                <div className="flex items-center gap-1.5 shrink-0 bg-white border border-rose-300 rounded-lg px-2.5 py-1 shadow-2xs">
                  <label className="text-xs font-bold text-rose-900 whitespace-nowrap">
                    કપાત:
                  </label>
                  <input
                    type="text"
                    inputMode="decimal"
                    placeholder="0"
                    value={tareDeduction}
                    onChange={(e) => setTareDeduction(e.target.value)}
                    className="w-14 text-center font-mono font-black text-sm text-rose-900 bg-rose-50 border border-rose-300 rounded py-0.5 focus:outline-none focus:ring-2 focus:ring-rose-400"
                  />
                </div>
              </div>

              {/* Full Width "સેવ કરો" Button Line */}
              <button
                type="button"
                onClick={() => setIsSheetOpen(false)}
                className="w-full py-3 px-5 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white rounded-xl font-black text-base flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
              >
                <Save className="w-5 h-5" />
                <span>સેવ કરો</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
