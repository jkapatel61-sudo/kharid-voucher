import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy,
  limit,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { VoucherBill, Product, FirmSettings, PrintJob, WeighmentSlipData } from '../types';

// Initialize Firebase App
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// Initialize Firestore with Database ID from config
export const db = getFirestore(
  app,
  firebaseConfig.firestoreDatabaseId || '(default)'
);

// Collections
export const BILLS_COLLECTION = 'mandi_bills';
export const WEIGHMENTS_COLLECTION = 'kanta_weighments';
export const PRODUCTS_COLLECTION = 'mandi_products';
export const PRINT_JOBS_COLLECTION = 'mandi_print_jobs';
export const SETTINGS_DOC = 'mandi_settings/global';

// Weighment Entry Model for the weighing bridge / kanta outside
export interface KantaWeighment {
  id: string;
  tokenNo?: number; // ટોકન નંબર
  date: string; // YYYY-MM-DD
  time: string; // HH:mm AM/PM
  customerName: string; // ખેડૂતનું નામ
  productId: string; // માલ આઇડી
  productName: string; // માલનું નામ (બાજરી, ઘઉં, વગેરે)
  ratePer20Kg: number; // ૨૦ કિલો દીઠ ભાવ
  bags: number[]; // દરેક થેલીનું વજન [50, 48.5, 52...]
  totalWeightKg: number; // કુલ વજન
  totalBagsCount: number; // કુલ થેલીઓ
  tareWeightKg?: number; // કપાત વજન
  calculatedAmount: number; // (કુલ વજન / 20) * ભાવ
  status: 'pending' | 'billed' | 'cancelled'; // 'pending' = અંદર ઓફિસમાં બિલ બનવાનું બાકી, 'billed' = બિલ બની ગયું
  billId?: string; // જોડાયેલા બિલનો આઈડી
  billNoStr?: string; // જોડાયેલા બિલનો નંબર (દા.ત. #A1, M1)
  createdAt: number;
}

/**
 * Real-time listener for Bills from Firestore
 */
export function subscribeToBills(
  onUpdate: (bills: VoucherBill[]) => void,
  onError?: (err: any) => void
) {
  const q = query(
    collection(db, BILLS_COLLECTION),
    orderBy('createdAt', 'desc'),
    limit(300)
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const items: VoucherBill[] = [];
      snapshot.forEach((d) => {
        items.push(d.data() as VoucherBill);
      });
      onUpdate(items);
    },
    (err) => {
      console.error('Firestore bills subscription error:', err);
      if (onError) onError(err);
    }
  );
}

let latestWeighmentsCache: KantaWeighment[] = [];

export function getLatestWeighmentsCache(): KantaWeighment[] {
  return latestWeighmentsCache;
}

/**
 * Real-time listener for Kanta Weighments
 */
export function subscribeToWeighments(
  onUpdate: (weighments: KantaWeighment[]) => void,
  onError?: (err: any) => void
) {
  const q = query(
    collection(db, WEIGHMENTS_COLLECTION),
    orderBy('createdAt', 'desc'),
    limit(150)
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const items: KantaWeighment[] = [];
      snapshot.forEach((d) => {
        items.push(d.data() as KantaWeighment);
      });
      latestWeighmentsCache = items;
      onUpdate(items);
    },
    (err) => {
      console.error('Firestore weighments subscription error:', err);
      if (onError) onError(err);
    }
  );
}

/**
 * Recursively removes any undefined values from objects or arrays
 * to prevent Firestore "Function setDoc() called with invalid data. Unsupported field value: undefined" errors.
 */
function cleanFirestoreData<T>(obj: T): T {
  if (obj === null || obj === undefined) {
    return obj;
  }
  if (Array.isArray(obj)) {
    return obj.map((item) => cleanFirestoreData(item)) as unknown as T;
  }
  if (typeof obj === 'object' && !(obj instanceof Date)) {
    const cleaned: Record<string, any> = {};
    for (const [key, value] of Object.entries(obj)) {
      if (value !== undefined) {
        cleaned[key] = cleanFirestoreData(value);
      }
    }
    return cleaned as T;
  }
  return obj;
}

/**
 * Save / Update a Bill to Firestore
 */
export async function syncBillToCloud(bill: VoucherBill) {
  try {
    const billRef = doc(db, BILLS_COLLECTION, bill.id);
    const cleaned = cleanFirestoreData(bill);
    await setDoc(billRef, cleaned, { merge: true });
  } catch (err) {
    console.warn('Cloud bill sync error:', err);
  }
}

/**
 * Delete a Bill from Firestore
 */
export async function deleteBillFromCloud(billId: string) {
  try {
    const billRef = doc(db, BILLS_COLLECTION, billId);
    await deleteDoc(billRef);
  } catch (err) {
    console.warn('Cloud bill delete error:', err);
  }
}

/**
 * Save / Update a Kanta Weighment
 */
export async function saveKantaWeighmentToCloud(weighment: KantaWeighment) {
  try {
    const ref = doc(db, WEIGHMENTS_COLLECTION, weighment.id);
    const cleaned = cleanFirestoreData(weighment);
    await setDoc(ref, cleaned, { merge: true });
  } catch (err) {
    console.error('Cloud save weighment error:', err);
    throw err;
  }
}

/**
 * Update Weighment status (e.g. mark as billed)
 */
export async function updateWeighmentStatus(
  weighmentId: string,
  status: 'pending' | 'billed' | 'cancelled',
  billId?: string,
  billNoStr?: string
) {
  try {
    const ref = doc(db, WEIGHMENTS_COLLECTION, weighmentId);
    const payload: Record<string, any> = { status };
    if (billId) {
      payload.billId = billId;
    }
    if (billNoStr) {
      payload.billNoStr = billNoStr;
    }
    await setDoc(ref, payload, { merge: true });
  } catch (err) {
    console.warn('Update weighment status error:', err);
  }
}

/**
 * Delete a Weighment
 */
export async function deleteWeighmentFromCloud(weighmentId: string) {
  try {
    const ref = doc(db, WEIGHMENTS_COLLECTION, weighmentId);
    await deleteDoc(ref);
  } catch (err) {
    console.warn('Delete weighment error:', err);
  }
}

/**
 * Enqueues a new print job to the Cloud print queue (mandi_print_jobs)
 * so that any office mobile connected to Bluetooth printer can print it automatically!
 */
export async function enqueuePrintJob(params: {
  type: 'bill' | 'kanta_weighment' | 'combined';
  billId?: string;
  bill?: VoucherBill;
  slip?: WeighmentSlipData;
  title: string;
  sourceDevice?: string;
}): Promise<string> {
  try {
    const id = `job_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const job: PrintJob = {
      id,
      type: params.type,
      billId: params.billId || params.bill?.id,
      bill: params.bill,
      slip: params.slip,
      title: params.title,
      status: 'pending',
      sourceDevice: params.sourceDevice || 'અન્ય મોબાઈલ (યાર્ડ/ઓનલાઇન)',
      createdAt: Date.now(),
    };

    const ref = doc(db, PRINT_JOBS_COLLECTION, id);
    const cleaned = cleanFirestoreData(job);
    await setDoc(ref, cleaned);
    console.log('Enqueued cloud print job:', id, job.title);
    return id;
  } catch (err) {
    console.error('Failed to enqueue cloud print job:', err);
    throw err;
  }
}

/**
 * Update the status of a Print Job (e.g. 'printing', 'completed', 'failed')
 */
export async function updatePrintJobStatus(
  jobId: string,
  status: 'pending' | 'printing' | 'completed' | 'failed',
  errorMessage?: string
): Promise<void> {
  try {
    const ref = doc(db, PRINT_JOBS_COLLECTION, jobId);
    const payload: Record<string, any> = {
      status,
      ...(status === 'completed' ? { completedAt: Date.now() } : {}),
      ...(errorMessage ? { errorMessage } : {}),
    };
    await setDoc(ref, cleanFirestoreData(payload), { merge: true });
  } catch (err) {
    console.warn('Failed to update print job status:', err);
  }
}

/**
 * Subscribe to recent print jobs (for live activity list and status monitoring)
 */
export function subscribeToPrintJobs(
  onUpdate: (jobs: PrintJob[]) => void,
  onError?: (err: any) => void
) {
  const q = query(
    collection(db, PRINT_JOBS_COLLECTION),
    orderBy('createdAt', 'desc'),
    limit(50)
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const items: PrintJob[] = [];
      snapshot.forEach((d) => {
        items.push(d.data() as PrintJob);
      });
      onUpdate(items);
    },
    (err) => {
      console.error('Firestore print jobs subscription error:', err);
      if (onError) onError(err);
    }
  );
}

/**
 * Delete a print job from cloud
 */
export async function deletePrintJobFromCloud(jobId: string): Promise<void> {
  try {
    const ref = doc(db, PRINT_JOBS_COLLECTION, jobId);
    await deleteDoc(ref);
  } catch (err) {
    console.warn('Failed to delete print job:', err);
  }
}

