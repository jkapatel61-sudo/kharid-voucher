import { FirmSettings, VoucherBill, WeighmentSlipData } from '../types';
import { formatDateDDMM, formatINR } from './storage';
import {
  isWebBluetoothSupported,
  printReceiptViaBluetooth,
  printWeighmentViaBluetooth,
  printCombinedViaBluetooth,
} from './bluetoothPrinter';
import { getLatestWeighmentsCache } from './firebaseSync';

export const isInsideIframe = (): boolean => {
  try {
    return typeof window !== 'undefined' && window.self !== window.top;
  } catch {
    return true;
  }
};

/**
 * Resolves or reconstructs weighment slip data for a bill so that both
 * weight records and bill payment are printed together seamlessly.
 */
export const resolveWeighmentSlip = (bill: VoucherBill): WeighmentSlipData | undefined => {
  if (bill.weighmentSlip) return bill.weighmentSlip;

  const cache = getLatestWeighmentsCache();
  if (!cache || cache.length === 0) return undefined;

  const match = cache.find((w) => {
    if (bill.weighmentId && w.id === bill.weighmentId) return true;
    if (w.billId && w.billId === bill.id) return true;
    if (
      w.date === bill.date &&
      w.customerName &&
      bill.customerName &&
      w.customerName.trim().toLowerCase() === bill.customerName.trim().toLowerCase() &&
      Math.abs(w.totalWeightKg - bill.totalWeightKg) < 1
    ) {
      return true;
    }
    return false;
  });

  if (!match) return undefined;

  const bags = Array.isArray(match.bags) ? match.bags : [];
  const gross =
    bags.length > 0
      ? Math.round(bags.reduce((acc, v) => acc + (Number(v) || 0), 0) * 10) / 10
      : match.totalWeightKg;
  let tare = match.tareWeightKg || 0;
  if (tare <= 0 && gross > match.totalWeightKg) {
    tare = Math.round((gross - match.totalWeightKg) * 10) / 10;
  }
  const net = tare > 0 ? Math.max(0, Math.round((gross - tare) * 10) / 10) : match.totalWeightKg;

  return {
    date: match.date,
    time: match.time,
    customerName: match.customerName,
    billNoStr: bill.billNoStr,
    items: [
      {
        productName: match.productName,
        weightKg: net,
        grossWeightKg: gross,
        tareWeightKg: tare > 0 ? tare : undefined,
        weightMan: Math.round((net / 20) * 10) / 10,
        ratePer20Kg: match.ratePer20Kg,
        amount: match.calculatedAmount,
        bags: bags,
      },
    ],
    totalBagsCount: match.totalBagsCount,
    totalWeightKg: net,
    grossWeightKg: gross,
    tareWeightKg: tare > 0 ? tare : undefined,
    totalWeightMan: Math.round((net / 20) * 10) / 10,
    totalAmount: match.calculatedAmount,
  };
};

/**
 * Triggers a direct system print for thermal receipts using a hidden iframe
 * so that no modal or popup screen appears in the application.
 */
export const directSystemPrint = (bill: VoucherBill, settings: FirmSettings): void => {
  if (typeof window === 'undefined') return;

  // If bill has or matches attached weighment data, print the combined slip (weights first + bill below)
  const resolvedSlip = resolveWeighmentSlip(bill);
  if (resolvedSlip) {
    directSystemPrintCombined(bill, resolvedSlip, settings);
    return;
  }

  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0px';
  iframe.style.height = '0px';
  iframe.style.border = 'none';
  iframe.setAttribute('title', 'Direct Thermal Print');

  let phoneList = (settings.phone || '')
    .split(/[,/\n]+/)
    .map((p) => p.trim())
    .filter(Boolean);
  if (!phoneList.includes('9427077011') || !phoneList.includes('9313172801')) {
    phoneList = ['9427077011', '9313172801'];
  }

  const itemsHtml = (bill.items || [])
    .map(
      (item, idx) => `
      <div style="margin-bottom: 6px;">
        <div style="display: flex; justify-content: space-between; font-weight: bold; font-size: 13px;">
          <span>${idx + 1}. ${item.productName}</span>
          <span>${idx === 0 ? 'ભાવ' : ''}</span>
          <span>${idx === 0 ? 'રકમ' : ''}</span>
        </div>
        <div style="display: flex; justify-content: space-between; font-family: monospace; font-size: 12px; margin-top: 2px;">
          <span>${item.weightKg} kg</span>
          <span>${item.ratePer20Kg}</span>
          <span style="font-weight: bold;">${Math.round(item.amount).toLocaleString('en-IN')}</span>
        </div>
      </div>
    `
    )
    .join('');

  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <title>વાઉચર સ્લિપ - ${bill.billNoStr || bill.billNo}</title>
        <style>
          @page {
            margin: 0;
            size: ${settings.paperWidth === '80mm' ? '80mm' : '58mm'} auto;
          }
          body {
            margin: 0;
            padding: 8px 6px;
            font-family: monospace, sans-serif;
            font-size: 12px;
            color: #000;
            width: ${settings.paperWidth === '80mm' ? '72mm' : '48mm'};
          }
          .text-center { text-align: center; }
          .border-b-dashed { border-bottom: 1px dashed #000; padding-bottom: 6px; margin-bottom: 6px; }
          .border-t-dashed { border-top: 1px dashed #000; padding-top: 6px; margin-top: 6px; }
          .flex-between { display: flex; justify-content: space-between; }
          .bold { font-weight: bold; }
        </style>
      </head>
      <body>
        <div class="text-center border-b-dashed">
          <div style="font-size: 15px; font-weight: bold;">${settings.firmName || 'શ્રી કલેશ્વરી કૃપા ટ્રેડીંગ કાં.'}</div>
          ${(settings.tagline || 'અનાજ, કઠોળ, તેલીબીયા તથા કેટલફીડના વહેપારી') ? `<div style="font-size: 10px; margin-top: 2px;">${settings.tagline || 'અનાજ, કઠોળ, તેલીબીયા તથા કેટલફીડના વહેપારી'}</div>` : ''}
          ${(settings.address || 'હરસિદ્ધિ માતાના મંદિર પાસે') ? `<div style="font-size: 10px;">${settings.address || 'હરસિદ્ધિ માતાના મંદિર પાસે'}</div>` : ''}
          ${(settings.addressLine2 || 'મુ. વાસણા, પો. મહિસા, તા. મહુધા, જી. ખેડા') ? `<div style="font-size: 10px;">${settings.addressLine2 || 'મુ. વાસણા, પો. મહિસા, તા. મહુધા, જી. ખેડા'}</div>` : ''}
          <div style="font-size: 10px; margin-top: 3px;">Mo. ${phoneList.join('  Mo. ')}</div>
          ${(settings.gstNo || '24ADDPP1757F1ZP') ? `<div style="font-size: 9px; margin-top: 3px;">GSTIN: ${settings.gstNo || '24ADDPP1757F1ZP'}</div>` : ''}
          ${(settings.licenseNo || '01/1998 Dt.25-08-1998') ? `<div style="font-size: 9px;">લા.નં: ${settings.licenseNo || '01/1998 Dt.25-08-1998'}</div>` : ''}
        </div>

        <div class="border-b-dashed">
          <div class="flex-between">
            <span>બિલ નં: <b style="font-family: monospace;">${bill.billNoStr || bill.billNo}</b></span>
            <span>તારીખ: ${formatDateDDMM(bill.date)}</span>
          </div>
          <div class="flex-between" style="margin-top: 3px;">
            <span>ગ્રાહક:</span>
            <b>${bill.customerName || 'સામાન્ય ગ્રાહક'}</b>
          </div>
        </div>

        <div class="border-b-dashed">
          ${itemsHtml}
        </div>

        <div class="border-b-dashed">
          <div class="flex-between bold" style="font-size: 14px;">
            <span>ચોખ્ખી રકમ:</span>
            <span>${formatINR(bill.finalTotal)}</span>
          </div>
          <div class="flex-between" style="font-size: 11px; margin-top: 3px;">
            <span>કુલ વજન:</span>
            <span>${bill.totalWeightKg} kg</span>
          </div>
        </div>

        <div class="text-center" style="font-size: 10px; margin-top: 6px;">
          <div>આભાર, ફરી પધારશો!</div>
          <div style="font-size: 9px; margin-top: 2px;">Computerized Cash Voucher</div>
        </div>
      </body>
    </html>
  `;

  document.body.appendChild(iframe);
  const doc = iframe.contentWindow?.document;
  if (!doc) return;

  doc.open();
  doc.write(html);
  doc.close();

  setTimeout(() => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch (e) {
      console.warn('Iframe print error:', e);
    } finally {
      setTimeout(() => {
        if (iframe.parentNode) {
          iframe.parentNode.removeChild(iframe);
        }
      }, 2000);
    }
  }, 250);
};

/**
 * Direct system print for Combined Slip:
 * First the bag weights (કાંટા વજન પત્રક) and below it the Cash Voucher Bill (વાઉચર બિલ)
 */
export const directSystemPrintCombined = (
  bill: VoucherBill,
  slip: WeighmentSlipData,
  settings: FirmSettings
): void => {
  if (typeof window === 'undefined') return;

  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0px';
  iframe.style.height = '0px';
  iframe.style.border = 'none';
  iframe.setAttribute('title', 'Direct Combined Print');

  let phoneList = (settings.phone || '')
    .split(/[,/\n]+/)
    .map((p) => p.trim())
    .filter(Boolean);
  if (!phoneList.includes('9427077011') || !phoneList.includes('9313172801')) {
    phoneList = ['9427077011', '9313172801'];
  }

  // Weight items (bags)
  const weightItemsHtml = slip.items
    .map((item) => {
      let bagsHtml = '';
      if (item.bags && item.bags.length > 0) {
        const half = Math.ceil(item.bags.length / 2);
        let rows = '';
        let leftColTotal = 0;
        let rightColTotal = 0;

        for (let i = 0; i < half; i++) {
          const lNum = i + 1;
          const lWeight = Number(item.bags[i]);
          leftColTotal += lWeight;

          const rIdx = i + half;
          let rHtml = '<span></span>';
          if (rIdx < item.bags.length) {
            const rWeight = Number(item.bags[rIdx]);
            rightColTotal += rWeight;
            rHtml = `<span>${String(rIdx + 1).padStart(2, '0')}) ${rWeight.toFixed(1)} kg</span>`;
          }

          rows += `
            <div style="display: flex; justify-content: space-between; font-family: monospace; font-size: 13px; font-weight: bold; padding: 1.5px 0;">
              <span>${String(lNum).padStart(2, '0')}) ${lWeight.toFixed(1)} kg</span>
              ${rHtml}
            </div>
          `;
        }

        const leftFormatted = parseFloat(leftColTotal.toFixed(1));
        const rightFormatted = parseFloat(rightColTotal.toFixed(1));

        bagsHtml = `
          <div style="margin: 3px 0; padding: 2px 0;">
            ${rows}
            <div style="display: flex; justify-content: space-between; font-family: monospace; font-size: 14.5px; font-weight: 900; border-top: 1px dashed #444; margin-top: 3px; padding-top: 2px;">
              <span>${leftFormatted} kg</span>
              ${rightColTotal > 0 ? `<span>${rightFormatted} kg</span>` : '<span></span>'}
            </div>
          </div>
        `;
      }

      return `
        <div style="margin-bottom: 5px; border-bottom: 1px dashed #ccc; padding-bottom: 4px;">
          <div style="font-weight: bold; font-size: 13.5px;">
            <span>માલ: ${item.productName}</span>
          </div>
          ${bagsHtml}
          ${!item.bags || item.bags.length === 0 ? `
          <div style="display: flex; justify-content: space-between; font-family: monospace; font-size: 13.5px; font-weight: bold; margin-top: 2px;">
            <span>વજન: ${item.weightKg} kg</span>
          </div>` : ''}
        </div>
      `;
    })
    .join('');

  // Weight summary calculation
  const grossW = slip.grossWeightKg ?? slip.items.reduce((acc, it) => {
    const itGross = it.grossWeightKg ?? (it.bags && it.bags.length > 0 ? it.bags.reduce((a, b) => a + Number(b), 0) : it.weightKg);
    return acc + itGross;
  }, 0);
  const roundedGross = Math.round(grossW * 10) / 10;

  let tareW = slip.tareWeightKg ?? slip.items.reduce((acc, it) => {
    const itGross = it.bags && it.bags.length > 0 ? it.bags.reduce((a, b) => a + Number(b), 0) : it.weightKg;
    const diff = Math.round((itGross - it.weightKg) * 10) / 10;
    return acc + (it.tareWeightKg || (diff > 0 ? diff : 0));
  }, 0);
  const roundedTare = Math.round(tareW * 10) / 10;

  const roundedNet = roundedTare > 0 ? Math.round((roundedGross - roundedTare) * 10) / 10 : Math.round(slip.totalWeightKg * 10) / 10;

  const weightSummaryHtml = roundedTare > 0 ? `
    <div style="display: flex; justify-content: space-between; font-size: 13px; font-weight: bold; margin-top: 3px;">
      <span>કુલ વજન:</span>
      <span style="font-family: monospace; font-size: 15px; font-weight: 800;">${parseFloat(roundedGross.toFixed(1))} kg</span>
    </div>
    <div style="display: flex; justify-content: space-between; font-size: 13px; font-weight: bold; margin-top: 2px;">
      <span>કુલ થેલી: ${slip.totalBagsCount || ''}</span>
      <span style="font-family: monospace; font-size: 15px; font-weight: 800;">-${parseFloat(roundedTare.toFixed(1))} kg</span>
    </div>
    <div style="border-top: 1px solid #000; margin: 3px 0;"></div>
    <div style="display: flex; justify-content: space-between; font-size: 15px; font-weight: 900; margin-top: 2px;">
      <span>નેટ વજન:</span>
      <span style="font-family: monospace; font-size: 18px; font-weight: 900;">${parseFloat(roundedNet.toFixed(1))} kg</span>
    </div>
  ` : `
    ${slip.totalBagsCount ? `
    <div style="display: flex; justify-content: space-between; font-size: 13px; font-weight: bold; margin-top: 2px;">
      <span>કુલ થેલી: ${slip.totalBagsCount}</span>
    </div>` : ''}
    <div style="display: flex; justify-content: space-between; font-size: 15px; font-weight: 900; margin-top: 2px;">
      <span>કુલ વજન:</span>
      <span style="font-family: monospace; font-size: 18px; font-weight: 900;">${parseFloat(roundedNet.toFixed(1))} kg</span>
    </div>
  `;

  // Bill items
  const billItems = bill.items && bill.items.length > 0 ? bill.items : [
    {
      id: 'item_1',
      productId: 'p_1',
      productName: slip.items[0]?.productName || 'માલ',
      productShortcut: '',
      weightKg: roundedNet,
      ratePer20Kg: slip.items[0]?.ratePer20Kg || 0,
      amount: slip.totalAmount || bill.finalTotal || 0,
    },
  ];

  const billItemsHtml = billItems
    .map(
      (item, idx) => `
      <div style="margin-bottom: 5px;">
        <div style="display: flex; justify-content: space-between; font-weight: bold; font-size: 13px;">
          <span>${idx + 1}. ${item.productName}</span>
          <span>${idx === 0 ? 'ભાવ' : ''}</span>
          <span>${idx === 0 ? 'રકમ' : ''}</span>
        </div>
        <div style="display: flex; justify-content: space-between; font-family: monospace; font-size: 12.5px; margin-top: 2px;">
          <span>${item.weightKg} kg</span>
          <span>${item.ratePer20Kg}</span>
          <span style="font-weight: bold;">${Math.round(item.amount).toLocaleString('en-IN')}</span>
        </div>
      </div>
    `
    )
    .join('');

  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <title>વજન અને બિલ પાવતી - ${bill.customerName || slip.customerName}</title>
        <style>
          @page {
            margin: 0;
            size: ${settings.paperWidth === '80mm' ? '80mm' : '58mm'} auto;
          }
          body {
            margin: 0;
            padding: 8px 6px;
            font-family: monospace, sans-serif;
            font-size: 12px;
            color: #000;
            width: ${settings.paperWidth === '80mm' ? '72mm' : '48mm'};
          }
          .text-center { text-align: center; }
          .bold { font-weight: bold; }
          .border-b-dashed { border-bottom: 1px dashed #000; padding-bottom: 6px; margin-bottom: 6px; }
          .divider { border-top: 1px solid #000; margin: 4px 0; }
          .strong-divider { border-top: 2px dashed #000; margin: 6px 0; }
          .flex-between { display: flex; justify-content: space-between; }
        </style>
      </head>
      <body>
        <div class="text-center border-b-dashed">
          <div style="font-size: 15px; font-weight: bold;">${settings.firmName || 'શ્રી કલેશ્વરી કૃપા ટ્રેડીંગ કાં.'}</div>
          ${(settings.tagline || 'અનાજ, કઠોળ, તેલીબીયા તથા કેટલફીડના વહેપારી') ? `<div style="font-size: 10px; margin-top: 2px;">${settings.tagline || 'અનાજ, કઠોળ, તેલીબીયા તથા કેટલફીડના વહેપારી'}</div>` : ''}
          ${(settings.address || 'હરસિદ્ધિ માતાના મંદિર પાસે') ? `<div style="font-size: 10px;">${settings.address || 'હરસિદ્ધિ માતાના મંદિર પાસે'}</div>` : ''}
          ${(settings.addressLine2 || 'મુ. વાસણા, પો. મહિસા, તા. મહુધા, જી. ખેડા') ? `<div style="font-size: 10px;">${settings.addressLine2 || 'મુ. વાસણા, પો. મહિસા, તા. મહુધા, જી. ખેડા'}</div>` : ''}
          <div style="font-size: 10px; margin-top: 3px;">Mo. ${phoneList.join('  Mo. ')}</div>
          ${(settings.gstNo || '24ADDPP1757F1ZP') ? `<div style="font-size: 9px; margin-top: 3px;">GSTIN: ${settings.gstNo || '24ADDPP1757F1ZP'}</div>` : ''}
          ${(settings.licenseNo || '01/1998 Dt.25-08-1998') ? `<div style="font-size: 9px;">લા.નં: ${settings.licenseNo || '01/1998 Dt.25-08-1998'}</div>` : ''}
        </div>

        <!-- 1. કાંટા વજન પત્રક -->
        <div class="text-center bold" style="font-size: 13px;">*** કાંટા વજન પત્રક ***</div>
        <div class="flex-between" style="font-size: 11px; margin-top: 2px;">
          <span>તા: ${formatDateDDMM(slip.date || bill.date)}</span>
          <span>સમય: ${slip.time || bill.time}</span>
        </div>
        <div class="flex-between" style="font-size: 12px; font-weight: bold; margin-top: 2px;">
          <span>ખેડૂત: ${slip.customerName || bill.customerName}</span>
          ${bill.billNoStr ? `<span>${bill.billNoStr}</span>` : ''}
        </div>
        <div class="divider"></div>
        ${weightItemsHtml}
        ${weightSummaryHtml}

        <!-- 2. વાઉચર બિલ -->
        <div class="strong-divider"></div>
        <div class="text-center bold" style="font-size: 13px; margin-bottom: 4px;">*** વાઉચર બિલ (હિસાબ) ***</div>
        ${billItemsHtml}
        <div class="divider"></div>
        <div class="flex-between bold" style="font-size: 15px; margin-top: 3px;">
          <span>ચોખ્ખી રકમ:</span>
          <span style="font-family: monospace; font-size: 17px; font-weight: 900;">${formatINR(bill.finalTotal)}</span>
        </div>
        <div class="divider"></div>
        <div class="text-center" style="font-size: 10px;">Computerized Weight Slip & Cash Voucher</div>
        <div class="text-center" style="font-size: 11px; margin-top: 2px;">${settings.footerNote || 'આભાર, ફરી પધારશો!'}</div>
      </body>
    </html>
  `;

  document.body.appendChild(iframe);
  const doc = iframe.contentWindow?.document;
  if (!doc) return;

  doc.open();
  doc.write(html);
  doc.close();

  setTimeout(() => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch (e) {
      console.warn('iframe print failed', e);
    } finally {
      setTimeout(() => {
        if (iframe.parentNode) {
          iframe.parentNode.removeChild(iframe);
        }
      }, 2000);
    }
  }, 250);
};

/**
 * Universal Direct Print Function:
 * If Web Bluetooth is available (and not inside restricted iframe), prints directly to Bluetooth printer (PSF588).
 * If not available or inside iframe, triggers direct system print.
 * NEVER shows any popup modal screen!
 */
export const printReceiptDirectly = async (
  bill: VoucherBill,
  settings: FirmSettings,
  onStatusUpdate?: (status: string) => void
): Promise<void> => {
  const resolvedSlip = resolveWeighmentSlip(bill);
  if (resolvedSlip) {
    return printCombinedDirectly(bill, resolvedSlip, settings, onStatusUpdate);
  }

  if (isWebBluetoothSupported() && !isInsideIframe()) {
    try {
      await printReceiptViaBluetooth(bill, settings, onStatusUpdate);
    } catch (err: any) {
      if (err?.message === 'IFRAME_PERMISSION_ERROR') {
        onStatusUpdate?.('પ્રિન્ટ મોકલાઈ રહી છે...');
        directSystemPrint(bill, settings);
        return;
      }
      // If error was due to temporary connection or GATT busy, retry once with fresh connect
      const msg = String(err?.message || '').toLowerCase();
      const isRecoverable =
        msg.includes('gatt') ||
        msg.includes('connection lost') ||
        msg.includes('disconnected') ||
        msg.includes('networkerror') ||
        err?.name === 'NetworkError';

      if (isRecoverable) {
        onStatusUpdate?.('પ્રિન્ટર સાથે ફરી જોડાણ કરી પ્રિન્ટ થઈ રહી છે...');
        await new Promise((res) => setTimeout(res, 600));
        await printReceiptViaBluetooth(bill, settings, onStatusUpdate);
        return;
      }
      throw err;
    }
  } else {
    onStatusUpdate?.('પ્રિન્ટ મોકલાઈ રહી છે...');
    directSystemPrint(bill, settings);
  }
};

/**
 * Universal Direct Print Function for Combined Slip (વજન પત્રક + વાઉચર બિલ):
 * Bluetooth or direct system print with zero popup!
 */
export const printCombinedDirectly = async (
  bill: VoucherBill,
  slip: WeighmentSlipData,
  settings: FirmSettings,
  onStatusUpdate?: (status: string) => void
): Promise<void> => {
  if (isWebBluetoothSupported() && !isInsideIframe()) {
    try {
      await printCombinedViaBluetooth(bill, slip, settings, onStatusUpdate);
    } catch (err: any) {
      if (err?.message === 'IFRAME_PERMISSION_ERROR') {
        onStatusUpdate?.('વજન અને બિલ પ્રિન્ટ મોકલાઈ રહી છે...');
        directSystemPrintCombined(bill, slip, settings);
        return;
      }
      const msg = String(err?.message || '').toLowerCase();
      const isRecoverable =
        msg.includes('gatt') ||
        msg.includes('connection lost') ||
        msg.includes('disconnected') ||
        msg.includes('networkerror') ||
        err?.name === 'NetworkError';

      if (isRecoverable) {
        onStatusUpdate?.('પ્રિન્ટર સાથે ફરી જોડાણ કરી પ્રિન્ટ થઈ રહી છે...');
        await new Promise((res) => setTimeout(res, 600));
        await printCombinedViaBluetooth(bill, slip, settings, onStatusUpdate);
        return;
      }
      throw err;
    }
  } else {
    onStatusUpdate?.('વજન અને બિલ પ્રિન્ટ મોકલાઈ રહી છે...');
    directSystemPrintCombined(bill, slip, settings);
  }
};

/**
 * Direct system print for Weight Slip (કાંટા વજન પત્રક)
 */
export const directSystemPrintWeighment = (slip: WeighmentSlipData, settings: FirmSettings): void => {
  if (typeof window === 'undefined') return;

  const iframe = document.createElement('iframe');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0px';
  iframe.style.height = '0px';
  iframe.style.border = 'none';
  iframe.setAttribute('title', 'Direct Weight Print');

  let phoneList = (settings.phone || '')
    .split(/[,/\n]+/)
    .map((p) => p.trim())
    .filter(Boolean);
  if (!phoneList.includes('9427077011') || !phoneList.includes('9313172801')) {
    phoneList = ['9427077011', '9313172801'];
  }

  const itemsHtml = slip.items
    .map((item) => {
      let bagsHtml = '';
      if (item.bags && item.bags.length > 0) {
        const half = Math.ceil(item.bags.length / 2);
        let rows = '';
        let leftColTotal = 0;
        let rightColTotal = 0;

        for (let i = 0; i < half; i++) {
          const lNum = i + 1;
          const lWeight = Number(item.bags[i]);
          leftColTotal += lWeight;
          const lW = lWeight.toFixed(1);

          const rIdx = i + half;
          let rHtml = '<span></span>';
          if (rIdx < item.bags.length) {
            const rWeight = Number(item.bags[rIdx]);
            rightColTotal += rWeight;
            rHtml = `<span>${String(rIdx + 1).padStart(2, '0')}) ${rWeight.toFixed(1)} kg</span>`;
          }

          rows += `
            <div style="display: flex; justify-content: space-between; font-family: monospace; font-size: 13px; font-weight: bold; padding: 2px 0;">
              <span>${String(lNum).padStart(2, '0')}) ${lW} kg</span>
              ${rHtml}
            </div>
          `;
        }

        const leftFormatted = parseFloat(leftColTotal.toFixed(1));
        const rightFormatted = parseFloat(rightColTotal.toFixed(1));

        bagsHtml = `
          <div style="margin: 3px 0; padding: 2px 0;">
            ${rows}
            <div style="display: flex; justify-content: space-between; font-family: monospace; font-size: 14.5px; font-weight: 900; border-top: 1px dashed #444; margin-top: 4px; padding-top: 3px;">
              <span>${leftFormatted} kg</span>
              ${rightColTotal > 0 ? `<span>${rightFormatted} kg</span>` : '<span></span>'}
            </div>
          </div>
        `;
      }

      return `
        <div style="margin-bottom: 6px; border-bottom: 1px dashed #ccc; padding-bottom: 5px;">
          <div style="font-weight: bold; font-size: 14px;">
            <span>માલ: ${item.productName}</span>
          </div>
          ${bagsHtml}
          ${!item.bags || item.bags.length === 0 ? `
          <div style="display: flex; justify-content: space-between; font-family: monospace; font-size: 14px; font-weight: bold; margin-top: 2px;">
            <span>વજન: ${item.weightKg} kg</span>
          </div>` : ''}
        </div>
      `;
    })
    .join('');

  // Summary calculation
  const grossW = slip.grossWeightKg ?? slip.items.reduce((acc, it) => {
    const itGross = it.grossWeightKg ?? (it.bags && it.bags.length > 0 ? it.bags.reduce((a, b) => a + Number(b), 0) : it.weightKg);
    return acc + itGross;
  }, 0);
  const roundedGross = Math.round(grossW * 10) / 10;

  let tareW = slip.tareWeightKg ?? slip.items.reduce((acc, it) => {
    const itGross = it.bags && it.bags.length > 0 ? it.bags.reduce((a, b) => a + Number(b), 0) : it.weightKg;
    const diff = Math.round((itGross - it.weightKg) * 10) / 10;
    return acc + (it.tareWeightKg || (diff > 0 ? diff : 0));
  }, 0);
  const roundedTare = Math.round(tareW * 10) / 10;

  const roundedNet = roundedTare > 0 ? Math.round((roundedGross - roundedTare) * 10) / 10 : Math.round(slip.totalWeightKg * 10) / 10;

  const summaryHtml = roundedTare > 0 ? `
    <div style="display: flex; justify-content: space-between; font-size: 13.5px; font-weight: bold; margin-top: 3px;">
      <span>કુલ વજન:</span>
      <span style="font-family: monospace; font-size: 16px; font-weight: 800;">${parseFloat(roundedGross.toFixed(1))} kg</span>
    </div>
    <div style="display: flex; justify-content: space-between; font-size: 13.5px; font-weight: bold; margin-top: 2px;">
      <span>કુલ થેલી: ${slip.totalBagsCount || ''}</span>
      <span style="font-family: monospace; font-size: 16px; font-weight: 800;">-${parseFloat(roundedTare.toFixed(1))} kg</span>
    </div>
    <div class="divider"></div>
    <div style="display: flex; justify-content: space-between; font-size: 16px; font-weight: 900; margin-top: 3px;">
      <span>નેટ વજન:</span>
      <span style="font-family: monospace; font-size: 19px; font-weight: 900;">${parseFloat(roundedNet.toFixed(1))} kg</span>
    </div>
  ` : `
    ${slip.totalBagsCount ? `
    <div style="display: flex; justify-content: space-between; font-size: 13px; font-weight: bold; margin-top: 2px;">
      <span>કુલ થેલી: ${slip.totalBagsCount}</span>
    </div>` : ''}
    <div style="display: flex; justify-content: space-between; font-size: 16px; font-weight: 900; margin-top: 3px;">
      <span>કુલ વજન:</span>
      <span style="font-family: monospace; font-size: 19px; font-weight: 900;">${parseFloat(roundedNet.toFixed(1))} kg</span>
    </div>
  `;

  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <title>કાંટા વજન પત્રક - ${slip.customerName}</title>
        <style>
          @page {
            margin: 0;
            size: ${settings.paperWidth === '80mm' ? '80mm' : '58mm'} auto;
          }
          body {
            margin: 0;
            padding: 8px 6px;
            font-family: monospace, sans-serif;
            font-size: 12px;
            color: #000;
            width: ${settings.paperWidth === '80mm' ? '72mm' : '48mm'};
          }
          .text-center { text-align: center; }
          .bold { font-weight: bold; }
          .border-b-dashed { border-bottom: 1px dashed #000; padding-bottom: 6px; margin-bottom: 6px; }
          .divider { border-top: 1px solid #000; margin: 4px 0; }
        </style>
      </head>
      <body>
        <div class="text-center border-b-dashed">
          <div style="font-size: 15px; font-weight: bold;">${settings.firmName || 'શ્રી કલેશ્વરી કૃપા ટ્રેડીંગ કાં.'}</div>
          ${(settings.tagline || 'અનાજ, કઠોળ, તેલીબીયા તથા કેટલફીડના વહેપારી') ? `<div style="font-size: 10px; margin-top: 2px;">${settings.tagline || 'અનાજ, કઠોળ, તેલીબીયા તથા કેટલફીડના વહેપારી'}</div>` : ''}
          ${(settings.address || 'હરસિદ્ધિ માતાના મંદિર પાસે') ? `<div style="font-size: 10px;">${settings.address || 'હરસિદ્ધિ માતાના મંદિર પાસે'}</div>` : ''}
          ${(settings.addressLine2 || 'મુ. વાસણા, પો. મહિસા, તા. મહુધા, જી. ખેડા') ? `<div style="font-size: 10px;">${settings.addressLine2 || 'મુ. વાસણા, પો. મહિસા, તા. મહુધા, જી. ખેડા'}</div>` : ''}
          <div style="font-size: 10px; margin-top: 3px;">Mo. ${phoneList.join('  Mo. ')}</div>
          ${(settings.gstNo || '24ADDPP1757F1ZP') ? `<div style="font-size: 9px; margin-top: 3px;">GSTIN: ${settings.gstNo || '24ADDPP1757F1ZP'}</div>` : ''}
          ${(settings.licenseNo || '01/1998 Dt.25-08-1998') ? `<div style="font-size: 9px;">લા.નં: ${settings.licenseNo || '01/1998 Dt.25-08-1998'}</div>` : ''}
        </div>
        <div class="text-center bold" style="font-size: 13px;">*** કાંટા વજન પત્રક ***</div>
        <div style="display: flex; justify-content: space-between; font-size: 11px; margin-top: 2px;">
          <span>તા: ${formatDateDDMM(slip.date)}</span>
          <span>સમય: ${slip.time}</span>
        </div>
        <div style="display: flex; justify-content: space-between; font-size: 12px; font-weight: bold; margin-top: 2px;">
          <span>ખેડૂત: ${slip.customerName}</span>
          ${slip.billNoStr ? `<span>${slip.billNoStr}</span>` : ''}
        </div>
        <div class="divider"></div>
        ${itemsHtml}
        ${summaryHtml}
        <div class="divider"></div>
        <div class="text-center" style="font-size: 10px;">Computerized Weight Slip</div>
        <div class="text-center" style="font-size: 11px; margin-top: 2px;">આભાર, ફરી પધારશો!</div>
      </body>
    </html>
  `;

  document.body.appendChild(iframe);
  const doc = iframe.contentWindow?.document;
  if (!doc) return;

  doc.open();
  doc.write(html);
  doc.close();

  setTimeout(() => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch (e) {
      console.warn('iframe print failed', e);
    } finally {
      setTimeout(() => {
        if (iframe.parentNode) {
          iframe.parentNode.removeChild(iframe);
        }
      }, 2000);
    }
  }, 250);
};

/**
 * Universal Direct Print Function for Weight Slip:
 * Bluetooth or direct system print with zero popup!
 */
export const printWeighmentDirectly = async (
  slip: WeighmentSlipData,
  settings: FirmSettings,
  onStatusUpdate?: (status: string) => void
): Promise<void> => {
  if (isWebBluetoothSupported() && !isInsideIframe()) {
    try {
      await printWeighmentViaBluetooth(slip, settings, onStatusUpdate);
    } catch (err: any) {
      if (err?.message === 'IFRAME_PERMISSION_ERROR') {
        onStatusUpdate?.('વજન પ્રિન્ટ મોકલાઈ રહી છે...');
        directSystemPrintWeighment(slip, settings);
        return;
      }
      const msg = String(err?.message || '').toLowerCase();
      const isRecoverable =
        msg.includes('gatt') ||
        msg.includes('connection lost') ||
        msg.includes('disconnected') ||
        msg.includes('networkerror') ||
        err?.name === 'NetworkError';

      if (isRecoverable) {
        onStatusUpdate?.('પ્રિન્ટર સાથે ફરી જોડાણ કરી વજન પ્રિન્ટ થઈ રહી છે...');
        await new Promise((res) => setTimeout(res, 600));
        await printWeighmentViaBluetooth(slip, settings, onStatusUpdate);
        return;
      }
      throw err;
    }
  } else {
    onStatusUpdate?.('વજન પ્રિન્ટ મોકલાઈ રહી છે...');
    directSystemPrintWeighment(slip, settings);
  }
};
