/**
 * Web Bluetooth ESC/POS Thermal Printer Driver with Auto-Pair & Auto-Reconnect
 * Specially optimized for PSF588 & standard 58mm/80mm thermal receipt printers.
 */
import { FirmSettings, VoucherBill, WeighmentSlipData } from '../types';
import { formatDateDDMM, formatINR } from './storage';

// Cached active Bluetooth device & characteristic for instant zero-prompt printing
let activeBluetoothDevice: any = null;
let activeGattServer: any = null;
let activeWriteCharacteristic: any = null;
let disconnectTimer: any = null;
let heartbeatInterval: any = null;
let autoReconnectTimer: any = null;
let isReconnecting = false;
let wakeLockSentinel: any = null;

// Concurrency locks to completely eliminate "GATT operation already in progress"
let bleQueue: Promise<any> = Promise.resolve();
let isPrinting = false;
let isConnecting = false;
let pendingConnectPromise: Promise<any> | null = null;

/**
 * Runs an operation serialized through the BLE queue with automatic retry
 * if a previous GATT operation was temporarily still in flight.
 */
export function runWithBleLock<T>(task: () => Promise<T>): Promise<T> {
  const next = bleQueue.then(async () => {
    let attempts = 0;
    while (true) {
      try {
        return await task();
      } catch (err: any) {
        attempts++;
        const msg = String(err?.message || '').toLowerCase();
        const isGattBusy =
          msg.includes('gatt operation already in progress') ||
          msg.includes('networkerror') ||
          err?.name === 'NetworkError';

        if (isGattBusy && attempts < 5) {
          console.warn(`BLE GATT busy, auto-retrying (${attempts}/5) after ${attempts * 120}ms...`);
          await new Promise((res) => setTimeout(res, attempts * 120));
          continue;
        }
        throw err;
      }
    }
  });

  bleQueue = next.catch(() => {});
  return next;
}

// Subscribers for live Bluetooth connection status changes
const statusListeners = new Set<(connected: boolean, deviceName: string) => void>();

export const subscribeBluetoothStatus = (
  listener: (connected: boolean, deviceName: string) => void
): (() => void) => {
  statusListeners.add(listener);
  // Emit immediately
  try {
    listener(isBluetoothConnected(), getActiveBluetoothDeviceName());
  } catch {}
  return () => {
    statusListeners.delete(listener);
  };
};

function notifyStatusChange(connected: boolean) {
  const name = getActiveBluetoothDeviceName();
  statusListeners.forEach((fn) => {
    try {
      fn(connected, name);
    } catch {}
  });
}

/**
 * Screen Wake Lock: Keeps the mobile screen awake and prevents Android / Chrome
 * from sleeping and killing Bluetooth connections during business hours.
 */
export const requestWakeLock = async (): Promise<void> => {
  if (typeof navigator !== 'undefined' && 'wakeLock' in navigator) {
    try {
      if (!wakeLockSentinel || wakeLockSentinel.released) {
        wakeLockSentinel = await (navigator as any).wakeLock.request('screen');
        wakeLockSentinel.addEventListener('release', () => {
          wakeLockSentinel = null;
        });
      }
    } catch (e) {
      // Benign if user agent disallows or battery saver active
    }
  }
};

export const releaseWakeLock = async (): Promise<void> => {
  if (wakeLockSentinel) {
    try {
      await wakeLockSentinel.release();
    } catch {}
    wakeLockSentinel = null;
  }
};

/**
 * Keep-Alive Heartbeat: Sends a harmless 0x00 (NUL byte) every 25 seconds.
 * In ESC/POS thermal printers, 0x00 is a safe padding/no-op byte that does not
 * advance paper or print anything, but continuously resets the printer's
 * internal 2-minute sleep timer and keeps the BLE radio active!
 * 
 * Protected by BLE Lock and completely suppressed during printing or connecting.
 */
export const startHeartbeat = (): void => {
  stopHeartbeat();
  heartbeatInterval = setInterval(async () => {
    if (isPrinting || isConnecting || isReconnecting) return;
    if (
      activeBluetoothDevice &&
      activeGattServer &&
      activeGattServer.connected &&
      activeWriteCharacteristic
    ) {
      try {
        await runWithBleLock(async () => {
          if (isPrinting || !activeGattServer?.connected || !activeWriteCharacteristic) return;
          const pingPacket = new Uint8Array([0x00]);
          await sendBleChunk(activeWriteCharacteristic, pingPacket);
        });
      } catch (err: any) {
        const msg = String(err?.message || '').toLowerCase();
        if (msg.includes('gatt operation already in progress')) {
          // A real operation was running, connection is obviously alive!
          return;
        }
        console.warn('Printer heartbeat ping failed, triggering auto-reconnect:', err);
        handleDisconnection();
      }
    } else {
      stopHeartbeat();
    }
  }, 25000);
};

export const stopHeartbeat = (): void => {
  if (heartbeatInterval) {
    clearInterval(heartbeatInterval);
    heartbeatInterval = null;
  }
};

const PAIRED_PRINTER_NAME_KEY = 'apmc_mandi_paired_printer_name';

export const getSavedPairedPrinterName = (): string => {
  try {
    return localStorage.getItem(PAIRED_PRINTER_NAME_KEY) || 'PSF588';
  } catch {
    return 'PSF588';
  }
};

export const setSavedPairedPrinterName = (name: string): void => {
  try {
    if (name) localStorage.setItem(PAIRED_PRINTER_NAME_KEY, name.trim());
  } catch {}
};

export const getActiveBluetoothDeviceName = (): string => {
  return activeBluetoothDevice?.name || getSavedPairedPrinterName() || 'PSF588';
};

// ESC/POS Bluetooth Service & Characteristic UUIDs
const PRINTER_SERVICES = [
  '000018f0-0000-1000-8000-00805f9b34fb', // Standard ESC/POS
  '49535343-fe7d-4ae5-8fa9-9fafd205e455', // ISSC transparent UART
  '0000fee7-0000-1000-8000-00805f9b34fb', // PSF588 / Jerry UART
  '0000fff0-0000-1000-8000-00805f9b34fb', // POS-58 / FFF0
  '0000ff00-0000-1000-8000-00805f9b34fb',
  '0000ae00-0000-1000-8000-00805f9b34fb',
  '0000af00-0000-1000-8000-00805f9b34fb',
  'e7810a71-73ae-499d-8c15-faa9aef0c3f2',
  '6e400001-b5a3-f393-e0a9-e50e24dcca9e', // Nordic UART
];

export const isWebBluetoothSupported = (): boolean => {
  return typeof navigator !== 'undefined' && Boolean((navigator as any).bluetooth);
};

export const isBluetoothConnected = (): boolean => {
  return Boolean(activeGattServer && activeGattServer.connected);
};

function handleDisconnection() {
  console.log('Bluetooth GATT disconnected, clearing session');
  activeGattServer = null;
  activeWriteCharacteristic = null;
  stopHeartbeat();
  notifyStatusChange(false);

  // Automatically attempt background reconnect after a brief pause
  scheduleSilentReconnect(2500);
}

function scheduleSilentReconnect(delayMs: number = 2500) {
  if (autoReconnectTimer) {
    clearTimeout(autoReconnectTimer);
  }
  if (!activeBluetoothDevice) return;

  autoReconnectTimer = setTimeout(async () => {
    if (isBluetoothConnected()) return;
    try {
      console.log('Attempting automatic background reconnect to printer...');
      await attemptSilentReconnect();
    } catch (e) {
      console.warn('Silent auto-reconnect failed, retry in 8s:', e);
      // Retry once more
      autoReconnectTimer = setTimeout(async () => {
        if (!isBluetoothConnected()) {
          try {
            await attemptSilentReconnect();
          } catch {}
        }
      }, 8000);
    }
  }, delayMs);
}

function bindDisconnectListener(device: any) {
  if (!device) return;
  try {
    device.removeEventListener('gattserverdisconnected', handleDisconnection);
    device.addEventListener('gattserverdisconnected', handleDisconnection);
  } catch {}
}

/**
 * Attempts silent reconnection to cached or previously paired Bluetooth device
 * without prompting the user or opening the pair dialog.
 */
export const attemptSilentReconnect = async (): Promise<boolean> => {
  if (isReconnecting || isConnecting || isPrinting) return false;
  if (isBluetoothConnected()) return true;
  if (!isWebBluetoothSupported()) return false;

  return runWithBleLock(async () => {
    if (isBluetoothConnected()) return true;
    try {
      isReconnecting = true;
      const res = await ensureConnectedPrinterInternal();
      return Boolean(res?.writeChar);
    } catch {
      return false;
    } finally {
      isReconnecting = false;
    }
  });
};

// Auto-reconnect and re-acquire WakeLock on tab visibility change or window focus
if (typeof document !== 'undefined') {
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      requestWakeLock();
      if (activeBluetoothDevice && (!activeGattServer || !activeGattServer.connected)) {
        attemptSilentReconnect();
      }
    }
  });
}
if (typeof window !== 'undefined') {
  window.addEventListener('focus', () => {
    if (activeBluetoothDevice && (!activeGattServer || !activeGattServer.connected)) {
      attemptSilentReconnect();
    }
  });
}

/**
 * Manually disconnects the Bluetooth printer
 */
export const disconnectBluetoothPrinter = () => {
  if (disconnectTimer) {
    clearTimeout(disconnectTimer);
    disconnectTimer = null;
  }
  if (autoReconnectTimer) {
    clearTimeout(autoReconnectTimer);
    autoReconnectTimer = null;
  }
  stopHeartbeat();
  releaseWakeLock();

  if (activeGattServer && activeGattServer.connected) {
    try {
      activeGattServer.disconnect();
    } catch {}
  }
  if (activeBluetoothDevice && activeBluetoothDevice.gatt && activeBluetoothDevice.gatt.connected) {
    try {
      activeBluetoothDevice.gatt.disconnect();
    } catch {}
  }
  activeGattServer = null;
  activeWriteCharacteristic = null;
  notifyStatusChange(false);
};

/**
 * Clean divider line on canvas
 */
function drawReceiptDivider(
  ctx: CanvasRenderingContext2D,
  x1: number,
  y: number,
  x2: number
) {
  ctx.save();
  ctx.fillStyle = '#000000';
  ctx.fillRect(x1, y, x2 - x1, 2);
  ctx.restore();
}

/**
 * Renders the identical, complete firm header on receipts:
 * Firm name, Tagline, Address lines, Phone numbers, GSTIN, and License number (લા.નં)
 */
function drawCommonReceiptHeader(
  ctx: CanvasRenderingContext2D,
  settings: FirmSettings,
  width: number,
  margin: number,
  rightX: number,
  startY = 40
): number {
  let y = startY;

  // 1. Firm Name (Bold & Large)
  ctx.textAlign = 'center';
  ctx.font = '700 32px "Noto Sans Gujarati", Arial, sans-serif';
  ctx.fillText(settings.firmName || 'શ્રી કલેશ્વરી કૃપા ટ્રેડીંગ કાં.', width / 2, y);
  y += 40;

  // 2. Tagline (Clear & readable)
  const tagline = settings.tagline || 'અનાજ, કઠોળ, તેલીબીયા તથા કેટલફીડના વહેપારી';
  if (tagline) {
    ctx.font = '500 18px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText(tagline, width / 2, y);
    y += 28;
  }

  // 3. Address Lines
  const addr1 = settings.address || 'હરસિદ્ધિ માતાના મંદિર પાસે';
  if (addr1) {
    ctx.font = '500 18px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText(addr1, width / 2, y);
    y += 28;
  }
  const addr2 = settings.addressLine2 || 'મુ. વાસણા, પો. મહિસા, તા. મહુધા, જી. ખેડા';
  if (addr2) {
    ctx.font = '500 18px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText(addr2, width / 2, y);
    y += 28;
  }

  // 4. Phones (Prominent)
  let phoneList = (settings.phone || '')
    .split(/[,/\n]+/)
    .map((p) => p.trim())
    .filter(Boolean);
  if (!phoneList.includes('9427077011') || !phoneList.includes('9313172801')) {
    phoneList = ['9427077011', '9313172801'];
  }
  ctx.font = '600 19px monospace';
  ctx.fillText(`Mo. ${phoneList.join(' | ')}`, width / 2, y);
  y += 30;

  // 5. GSTIN & License No (લા.નં:)
  const gstNo = settings.gstNo || '24ADDPP1757F1ZP';
  const licenseNo = settings.licenseNo || '01/1998 Dt.25-08-1998';
  if (gstNo || licenseNo) {
    ctx.font = '500 17px monospace';
    if (gstNo && licenseNo) {
      ctx.fillText(`GSTIN: ${gstNo}`, width / 2, y);
      y += 24;
      ctx.fillText(`લા.નં: ${licenseNo}`, width / 2, y);
      y += 26;
    } else if (gstNo) {
      ctx.fillText(`GSTIN: ${gstNo}`, width / 2, y);
      y += 26;
    } else if (licenseNo) {
      ctx.fillText(`લા.નં: ${licenseNo}`, width / 2, y);
      y += 26;
    }
  }

  // Divider line
  y += 4;
  drawReceiptDivider(ctx, margin, y, rightX);
  y += 28;

  return y;
}

/**
 * Renders the bill into a high-contrast monochrome bitmap for 58mm (384px) or 80mm (576px)
 * to support full Gujarati text rendering on all thermal printers!
 */
export const renderReceiptToCanvas = (
  bill: VoucherBill,
  settings: FirmSettings
): HTMLCanvasElement => {
  const is80mm = settings.paperWidth === '80mm';
  const width = is80mm ? 576 : 384;
  // Use edge-to-edge margin (4px) on 58mm to maximize printable area across the entire thermal head
  const margin = is80mm ? 10 : 4;
  const rightX = width - margin;

  // Generous height to accommodate all elements cleanly
  const estimatedHeight = 950 + (bill.items?.length || 1) * 80;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = estimatedHeight;

  const ctx = canvas.getContext('2d');
  if (!ctx) return canvas;

  // Fill pure white background
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, width, estimatedHeight);

  // Black ink
  ctx.fillStyle = '#000000';
  ctx.textBaseline = 'alphabetic';

  // Common Header (Firm Name, Tagline, Address, Phone, GSTIN, License No, Divider)
  let y = drawCommonReceiptHeader(ctx, settings, width, margin, rightX, 40);

  // 6. Bill Info (Large & bold)
  ctx.textAlign = 'left';
  ctx.font = '600 22px monospace';
  const billNum = bill.billNoStr || `${bill.session || 'M'}${bill.billNo}`;
  ctx.fillText(`બિલ નં: ${billNum}`, margin, y);

  ctx.textAlign = 'right';
  ctx.fillText(`તારીખ: ${formatDateDDMM(bill.date)}`, rightX, y);
  y += 34;

  // Customer Name (Prominent)
  ctx.textAlign = 'left';
  ctx.font = '600 23px "Noto Sans Gujarati", Arial, sans-serif';
  ctx.fillText(`ગ્રાહક: ${bill.customerName || 'સામાન્ય ગ્રાહક'}`, margin, y);
  y += 28;

  // Divider
  drawReceiptDivider(ctx, margin, y, rightX);
  y += 30;

  // 7 & 8. Items Table (Product Name replaces "માલ / વજન", kg only without man, pure numbers without ₹ symbol)
  const items = bill.items && bill.items.length > 0 ? bill.items : [];
  items.forEach((it, idx) => {
    // Top row: Product Name (e.g. 'બાજરી') on left, 'ભાવ' in center, 'રકમ' on right
    ctx.textAlign = 'left';
    ctx.font = 'bold 24px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText(it.productName, margin, y);

    ctx.textAlign = 'center';
    ctx.font = 'bold 21px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText('ભાવ', width * 0.52, y);

    ctx.textAlign = 'right';
    ctx.font = 'bold 21px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText('રકમ', rightX, y);
    y += 30;

    // Bottom row: Weight (kg only, no man count), Rate, Amount (pure number, no ₹ symbol)
    ctx.textAlign = 'left';
    ctx.font = 'bold 22px monospace';
    ctx.fillText(`${it.weightKg} kg`, margin, y);

    ctx.textAlign = 'center';
    ctx.font = 'bold 24px monospace';
    ctx.fillText(`${it.ratePer20Kg}`, width * 0.52, y);

    ctx.textAlign = 'right';
    ctx.font = 'bold 25px monospace';
    ctx.fillText(`${Math.round(it.amount).toLocaleString('en-IN')}`, rightX, y);
    y += 34;

    if (idx < items.length - 1) {
      y += 8;
    }
  });

  // Divider
  drawReceiptDivider(ctx, margin, y, rightX);
  y += 30;

  // 9. Summary & Totals (Pure numbers, no ₹ symbol)
  if (bill.discountLess > 0) {
    ctx.textAlign = 'left';
    ctx.font = '600 20px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText('કુલ રકમ:', margin, y);
    ctx.textAlign = 'right';
    ctx.font = '600 22px monospace';
    ctx.fillText(`${Math.round(bill.grossAmount).toLocaleString('en-IN')}`, rightX, y);
    y += 28;

    ctx.textAlign = 'left';
    ctx.font = '600 20px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText('કપાત / લેસ:', margin, y);
    ctx.textAlign = 'right';
    ctx.font = '600 22px monospace';
    ctx.fillText(`-${Math.round(bill.discountLess).toLocaleString('en-IN')}`, rightX, y);
    y += 28;
  }

  // Final Total (Big & Bold Total, pure number, no ₹ symbol)
  ctx.textAlign = 'left';
  ctx.font = 'bold 25px "Noto Sans Gujarati", Arial, sans-serif';
  ctx.fillText('ચોખ્ખી રકમ:', margin, y);

  ctx.textAlign = 'right';
  ctx.font = 'bold 34px monospace';
  ctx.fillText(`${Math.round(bill.finalTotal).toLocaleString('en-IN')}`, rightX, y);
  y += 40;

  // Divider
  drawReceiptDivider(ctx, margin, y, rightX);
  y += 30;

  // 10. Footer Note (Larger font)
  ctx.textAlign = 'center';
  ctx.font = '500 19px "Noto Sans Gujarati", Arial, sans-serif';
  ctx.fillText(settings.footerNote || 'આભાર, ફરી પધારશો!', width / 2, y);
  y += 28;

  ctx.font = '500 15px monospace';
  ctx.fillText('Computerized Cash Voucher', width / 2, y);
  y += 32;

  // ⭐️ Exact "માપ ટુ માપ" (Map-to-map) height - No wasteful blank paper at bottom!
  const finalHeight = y + 8;

  // Trim canvas to exact content height
  const trimmed = document.createElement('canvas');
  trimmed.width = width;
  trimmed.height = finalHeight;
  const tCtx = trimmed.getContext('2d');
  if (tCtx) {
    tCtx.fillStyle = '#FFFFFF';
    tCtx.fillRect(0, 0, width, finalHeight);
    tCtx.drawImage(canvas, 0, 0, width, finalHeight, 0, 0, width, finalHeight);
    return trimmed;
  }

  return canvas;
};

/**
 * Renders a detailed Weight Slip (કાંટા વજન પત્રક / લખેલા વજનની પાવતી) to canvas
 * with bag-by-bag weights displayed in balanced columns.
 */
export const renderWeighmentToCanvas = (
  slip: WeighmentSlipData,
  settings: FirmSettings
): HTMLCanvasElement => {
  const is80mm = settings.paperWidth === '80mm';
  const width = is80mm ? 576 : 384;
  const margin = is80mm ? 10 : 4;
  const rightX = width - margin;

  let totalBags = 0;
  slip.items.forEach((it) => {
    if (it.bags && it.bags.length > 0) {
      totalBags += it.bags.length;
    }
  });
  const estimatedHeight = 900 + Math.ceil(totalBags / 2) * 34 + slip.items.length * 100;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = Math.max(800, estimatedHeight);

  const ctx = canvas.getContext('2d');
  if (!ctx) return canvas;

  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, width, canvas.height);

  ctx.fillStyle = '#000000';
  ctx.textBaseline = 'alphabetic';

  // Common Header (Firm Name, Tagline, Address, Phone, GSTIN, License No, Divider)
  let y = drawCommonReceiptHeader(ctx, settings, width, margin, rightX, 38);

  // 3. Slip Title
  ctx.textAlign = 'center';
  ctx.font = '700 22px "Noto Sans Gujarati", Arial, sans-serif';
  ctx.fillText(slip.slipTitle || '*** કાંટા વજન પત્રક ***', width / 2, y);
  y += 28;

  // 4. Date & Time
  ctx.textAlign = 'left';
  ctx.font = '600 19px monospace';
  ctx.fillText(`તારીખ: ${formatDateDDMM(slip.date)}`, margin, y);

  ctx.textAlign = 'right';
  ctx.fillText(`સમય: ${slip.time}`, rightX, y);
  y += 28;

  // Customer Name & Bill No (if any)
  ctx.textAlign = 'left';
  ctx.font = '700 22px "Noto Sans Gujarati", Arial, sans-serif';
  ctx.fillText(`ખેડૂત: ${slip.customerName || 'સામાન્ય ખેડૂત'}`, margin, y);

  if (slip.billNoStr) {
    ctx.textAlign = 'right';
    ctx.font = '600 19px monospace';
    ctx.fillText(`બિલ નં: ${slip.billNoStr}`, rightX, y);
  }
  y += 28;

  // Divider
  drawReceiptDivider(ctx, margin, y, rightX);
  y += 26;

  // 5. Items & Individual Bag Weights Breakdown
  slip.items.forEach((item, itemIdx) => {
    ctx.textAlign = 'left';
    ctx.font = '700 24px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText(`માલ: ${item.productName}`, margin, y);
    y += 28;

    if (item.bags && item.bags.length > 0) {
      // Show bags directly in 2 balanced columns with bigger, clearer text
      const halfCount = Math.ceil(item.bags.length / 2);
      const leftColX = margin + 4;
      const rightColX = Math.round(width / 2) + 4;

      ctx.font = '800 22px monospace';
      let leftColTotal = 0;
      let rightColTotal = 0;

      for (let i = 0; i < halfCount; i++) {
        const leftBagNum = i + 1;
        const leftWeight = Number(item.bags[i]);
        leftColTotal += leftWeight;

        const leftText = `${String(leftBagNum).padStart(2, ' ')} ) ${leftWeight.toFixed(1)} kg`;

        ctx.textAlign = 'left';
        ctx.fillText(leftText, leftColX, y);

        const rightIdx = i + halfCount;
        if (rightIdx < item.bags.length) {
          const rightBagNum = rightIdx + 1;
          const rightWeight = Number(item.bags[rightIdx]);
          rightColTotal += rightWeight;

          const rightText = `${String(rightBagNum).padStart(2, ' ')} ) ${rightWeight.toFixed(1)} kg`;
          ctx.fillText(rightText, rightColX, y);
        }
        y += 28;
      }

      // Column Subtotals (વજન થોડું મોટું, 'ટોટલ' કાઢી નાખ્યું)
      y += 2;
      drawReceiptDivider(ctx, margin, y, rightX);
      y += 22;

      ctx.font = '900 26px monospace';
      ctx.textAlign = 'left';
      const leftFormatted = parseFloat(leftColTotal.toFixed(1));
      ctx.fillText(`${leftFormatted} kg`, leftColX, y);

      if (rightColTotal > 0) {
        const rightFormatted = parseFloat(rightColTotal.toFixed(1));
        ctx.fillText(`${rightFormatted} kg`, rightColX, y);
      }
      y += 26;
    } else {
      // Direct total weight (bigger font)
      ctx.textAlign = 'left';
      ctx.font = '800 24px monospace';
      ctx.fillText(`વજન: ${item.weightKg} kg`, margin, y);
      y += 28;
    }

    if (itemIdx < slip.items.length - 1) {
      drawReceiptDivider(ctx, margin, y, rightX);
      y += 22;
    }
  });

  // Divider
  drawReceiptDivider(ctx, margin, y, rightX);
  y += 28;

  // 6. Total Summary Section (Gross weight, Bags count, Tare deduction, Net weight)
  const grossW = slip.grossWeightKg ?? slip.items.reduce((acc, it) => {
    const itGross = it.grossWeightKg ?? (it.bags && it.bags.length > 0 ? it.bags.reduce((a, b) => a + Number(b), 0) : it.weightKg);
    return acc + itGross;
  }, 0);
  const roundedGross = Math.round(grossW * 10) / 10;

  let tareW = slip.tareWeightKg ?? slip.items.reduce((acc, it) => {
    const itGross = it.bags && it.bags.length > 0 ? it.bags.reduce((a, b) => a + Number(b), 0) : it.weightKg;
    const diff = Math.round((itGross - it.weightKg) * 10) / 10;
    return acc + (it.tareWeightKg || (diff > 0 ? diff : 0));
  }, 0);
  const roundedTare = Math.round(tareW * 10) / 10;

  const roundedNet = roundedTare > 0 ? Math.round((roundedGross - roundedTare) * 10) / 10 : Math.round(slip.totalWeightKg * 10) / 10;

  if (roundedTare > 0) {
    // 1. કુલ વજન: 724.5 kg
    ctx.textAlign = 'left';
    ctx.font = '700 24px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText('કુલ વજન:', margin, y);
    ctx.textAlign = 'right';
    ctx.font = '800 28px monospace';
    ctx.fillText(`${parseFloat(roundedGross.toFixed(1))} kg`, rightX, y);
    y += 30;

    // 2. એક જ લાઇન માં: 'કુલ થેલી: 20' (ડાબે) અને 724.5 ની નીચે જ '-4 kg' (જમણે, કોઈ કપાત શબ્દ વગર)
    ctx.textAlign = 'left';
    ctx.font = '700 24px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText(`કુલ થેલી: ${slip.totalBagsCount || ''}`, margin, y);
    ctx.textAlign = 'right';
    ctx.font = '800 28px monospace';
    ctx.fillText(`-${parseFloat(roundedTare.toFixed(1))} kg`, rightX, y);
    y += 30;

    // Divider before Net Weight
    drawReceiptDivider(ctx, margin, y, rightX);
    y += 24;

    // 3. નીચેની લાઇન માં નેટ વજન: 720.5 kg
    ctx.textAlign = 'left';
    ctx.font = '800 26px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText('નેટ વજન:', margin, y);
    ctx.textAlign = 'right';
    ctx.font = '900 34px monospace';
    ctx.fillText(`${parseFloat(roundedNet.toFixed(1))} kg`, rightX, y);
    y += 36;
  } else {
    // No tare deduction
    if (slip.totalBagsCount && slip.totalBagsCount > 0) {
      ctx.textAlign = 'left';
      ctx.font = '700 24px "Noto Sans Gujarati", Arial, sans-serif';
      ctx.fillText(`કુલ થેલી: ${slip.totalBagsCount}`, margin, y);
      y += 28;
    }

    ctx.textAlign = 'left';
    ctx.font = '800 26px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText('કુલ વજન:', margin, y);
    ctx.textAlign = 'right';
    ctx.font = '900 34px monospace';
    ctx.fillText(`${parseFloat(roundedNet.toFixed(1))} kg`, rightX, y);
    y += 36;
  }

  // Divider
  drawReceiptDivider(ctx, margin, y, rightX);
  y += 26;

  // 7. Footer
  ctx.textAlign = 'center';
  ctx.font = '500 17px monospace';
  ctx.fillText('Computerized Weight Slip', width / 2, y);
  y += 24;

  ctx.font = '600 18px "Noto Sans Gujarati", Arial, sans-serif';
  ctx.fillText('આભાર, ફરી પધારશો!', width / 2, y);
  y += 28;

  // Map-to-map exact height
  const finalHeight = y + 8;
  const trimmed = document.createElement('canvas');
  trimmed.width = width;
  trimmed.height = finalHeight;
  const tCtx = trimmed.getContext('2d');
  if (tCtx) {
    tCtx.fillStyle = '#FFFFFF';
    tCtx.fillRect(0, 0, width, finalHeight);
    tCtx.drawImage(canvas, 0, 0, width, finalHeight, 0, 0, width, finalHeight);
    return trimmed;
  }

  return canvas;
};

/**
 * Renders a Combined Slip: First the Weight Slip (કાંટા વજન પત્રક with individual bags),
 * and immediately below it the Cash Voucher Bill (વાઉચર બિલ) on a single seamless thermal receipt!
 */
export const renderCombinedReceiptToCanvas = (
  bill: VoucherBill,
  slip: WeighmentSlipData,
  settings: FirmSettings
): HTMLCanvasElement => {
  const is80mm = settings.paperWidth === '80mm';
  const width = is80mm ? 576 : 384;
  const margin = is80mm ? 10 : 4;
  const rightX = width - margin;

  let totalBags = 0;
  slip.items.forEach((it) => {
    if (it.bags && it.bags.length > 0) {
      totalBags += it.bags.length;
    }
  });

  const estimatedHeight =
    1350 +
    Math.ceil(totalBags / 2) * 34 +
    slip.items.length * 80 +
    (bill.items?.length || 1) * 80;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = Math.max(1000, estimatedHeight);

  const ctx = canvas.getContext('2d');
  if (!ctx) return canvas;

  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, width, canvas.height);

  ctx.fillStyle = '#000000';
  ctx.textBaseline = 'alphabetic';

  // Common Header (Firm Name, Tagline, Address, Phone, GSTIN, License No, Divider)
  let y = drawCommonReceiptHeader(ctx, settings, width, margin, rightX, 38);

  // ==========================================
  // PART 1: કાંટા વજન પત્રક (WEIGHT SECTION)
  // ==========================================
  ctx.textAlign = 'center';
  ctx.font = '700 21px "Noto Sans Gujarati", Arial, sans-serif';
  ctx.fillText('*** કાંટા વજન પત્રક ***', width / 2, y);
  y += 26;

  // Date & Time
  ctx.textAlign = 'left';
  ctx.font = '600 18px monospace';
  ctx.fillText(`તારીખ: ${formatDateDDMM(slip.date || bill.date)}`, margin, y);

  ctx.textAlign = 'right';
  ctx.fillText(`સમય: ${slip.time || bill.time}`, rightX, y);
  y += 26;

  // Farmer Name & Bill No
  ctx.textAlign = 'left';
  ctx.font = '700 21px "Noto Sans Gujarati", Arial, sans-serif';
  ctx.fillText(`ખેડૂત: ${slip.customerName || bill.customerName || 'સામાન્ય ખેડૂત'}`, margin, y);

  const billStr = bill.billNoStr || slip.billNoStr;
  if (billStr) {
    ctx.textAlign = 'right';
    ctx.font = '600 19px monospace';
    ctx.fillText(`બિલ: ${billStr}`, rightX, y);
  }
  y += 26;

  drawReceiptDivider(ctx, margin, y, rightX);
  y += 24;

  // Items & Bag weights
  slip.items.forEach((item, itemIdx) => {
    ctx.textAlign = 'left';
    ctx.font = '700 23px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText(`માલ: ${item.productName}`, margin, y);
    y += 26;

    if (item.bags && item.bags.length > 0) {
      const halfCount = Math.ceil(item.bags.length / 2);
      const leftColX = margin + 4;
      const rightColX = Math.round(width / 2) + 4;

      ctx.font = '800 21px monospace';
      let leftColTotal = 0;
      let rightColTotal = 0;

      for (let i = 0; i < halfCount; i++) {
        const leftBagNum = i + 1;
        const leftWeight = Number(item.bags[i]);
        leftColTotal += leftWeight;

        const leftText = `${String(leftBagNum).padStart(2, ' ')} ) ${leftWeight.toFixed(1)} kg`;
        ctx.textAlign = 'left';
        ctx.fillText(leftText, leftColX, y);

        const rightIdx = i + halfCount;
        if (rightIdx < item.bags.length) {
          const rightBagNum = rightIdx + 1;
          const rightWeight = Number(item.bags[rightIdx]);
          rightColTotal += rightWeight;

          const rightText = `${String(rightBagNum).padStart(2, ' ')} ) ${rightWeight.toFixed(1)} kg`;
          ctx.fillText(rightText, rightColX, y);
        }
        y += 26;
      }

      // Column Subtotals
      y += 2;
      drawReceiptDivider(ctx, margin, y, rightX);
      y += 20;

      ctx.font = '900 24px monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`${parseFloat(leftColTotal.toFixed(1))} kg`, leftColX, y);

      if (rightColTotal > 0) {
        ctx.fillText(`${parseFloat(rightColTotal.toFixed(1))} kg`, rightColX, y);
      }
      y += 24;
    } else {
      ctx.textAlign = 'left';
      ctx.font = '800 23px monospace';
      ctx.fillText(`વજન: ${item.weightKg} kg`, margin, y);
      y += 26;
    }

    if (itemIdx < slip.items.length - 1) {
      drawReceiptDivider(ctx, margin, y, rightX);
      y += 20;
    }
  });

  drawReceiptDivider(ctx, margin, y, rightX);
  y += 24;

  // Weight Summary (Gross, Bags, Tare, Net)
  const grossW = slip.grossWeightKg ?? slip.items.reduce((acc, it) => {
    const itGross = it.grossWeightKg ?? (it.bags && it.bags.length > 0 ? it.bags.reduce((a, b) => a + Number(b), 0) : it.weightKg);
    return acc + itGross;
  }, 0);
  const roundedGross = Math.round(grossW * 10) / 10;

  let tareW = slip.tareWeightKg ?? slip.items.reduce((acc, it) => {
    const itGross = it.bags && it.bags.length > 0 ? it.bags.reduce((a, b) => a + Number(b), 0) : it.weightKg;
    const diff = Math.round((itGross - it.weightKg) * 10) / 10;
    return acc + (it.tareWeightKg || (diff > 0 ? diff : 0));
  }, 0);
  const roundedTare = Math.round(tareW * 10) / 10;

  const roundedNet = roundedTare > 0 ? Math.round((roundedGross - roundedTare) * 10) / 10 : Math.round(slip.totalWeightKg * 10) / 10;

  if (roundedTare > 0) {
    ctx.textAlign = 'left';
    ctx.font = '700 22px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText('કુલ વજન:', margin, y);
    ctx.textAlign = 'right';
    ctx.font = '800 25px monospace';
    ctx.fillText(`${parseFloat(roundedGross.toFixed(1))} kg`, rightX, y);
    y += 28;

    ctx.textAlign = 'left';
    ctx.font = '700 22px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText(`કુલ થેલી: ${slip.totalBagsCount || ''}`, margin, y);
    ctx.textAlign = 'right';
    ctx.font = '800 25px monospace';
    ctx.fillText(`-${parseFloat(roundedTare.toFixed(1))} kg`, rightX, y);
    y += 28;

    drawReceiptDivider(ctx, margin, y, rightX);
    y += 22;

    ctx.textAlign = 'left';
    ctx.font = '800 24px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText('નેટ વજન:', margin, y);
    ctx.textAlign = 'right';
    ctx.font = '900 30px monospace';
    ctx.fillText(`${parseFloat(roundedNet.toFixed(1))} kg`, rightX, y);
    y += 34;
  } else {
    if (slip.totalBagsCount && slip.totalBagsCount > 0) {
      ctx.textAlign = 'left';
      ctx.font = '700 22px "Noto Sans Gujarati", Arial, sans-serif';
      ctx.fillText(`કુલ થેલી: ${slip.totalBagsCount}`, margin, y);
      y += 26;
    }

    ctx.textAlign = 'left';
    ctx.font = '800 24px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText('કુલ વજન:', margin, y);
    ctx.textAlign = 'right';
    ctx.font = '900 30px monospace';
    ctx.fillText(`${parseFloat(roundedNet.toFixed(1))} kg`, rightX, y);
    y += 34;
  }

  // ==========================================
  // PART 2: વાઉચર બિલ (BILL / PAYMENT SECTION)
  // ==========================================
  // Prominent separator
  ctx.save();
  ctx.fillStyle = '#000000';
  ctx.fillRect(margin, y, rightX - margin, 4);
  ctx.restore();
  y += 26;

  ctx.textAlign = 'center';
  ctx.font = '700 22px "Noto Sans Gujarati", Arial, sans-serif';
  ctx.fillText('*** વાઉચર બિલ (હિસાબ) ***', width / 2, y);
  y += 28;

  // Bill Items table
  const billItems = bill.items && bill.items.length > 0 ? bill.items : [
    {
      id: 'item_1',
      productId: 'p_1',
      productName: slip.items[0]?.productName || 'માલ',
      productShortcut: '',
      weightKg: roundedNet,
      ratePer20Kg: slip.items[0]?.ratePer20Kg || 0,
      amount: slip.totalAmount || bill.finalTotal || 0,
    },
  ];

  billItems.forEach((it, idx) => {
    // Header for first item
    if (idx === 0) {
      ctx.textAlign = 'left';
      ctx.font = 'bold 20px "Noto Sans Gujarati", Arial, sans-serif';
      ctx.fillText('માલ / વજન', margin, y);

      ctx.textAlign = 'center';
      ctx.fillText('ભાવ', width * 0.52, y);

      ctx.textAlign = 'right';
      ctx.fillText('રકમ', rightX, y);
      y += 26;
    }

    // Product Name (with item line number)
    ctx.textAlign = 'left';
    ctx.font = 'bold 21px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText(`${idx + 1}. ${it.productName}`, margin, y);
    y += 26;

    // Weight, Rate, Amount
    ctx.textAlign = 'left';
    ctx.font = 'bold 21px monospace';
    ctx.fillText(`${it.weightKg} kg`, margin, y);

    ctx.textAlign = 'center';
    ctx.font = 'bold 22px monospace';
    ctx.fillText(`${it.ratePer20Kg}`, width * 0.52, y);

    ctx.textAlign = 'right';
    ctx.font = 'bold 24px monospace';
    ctx.fillText(`${Math.round(it.amount).toLocaleString('en-IN')}`, rightX, y);
    y += 30;

    if (idx < billItems.length - 1) {
      y += 6;
    }
  });

  drawReceiptDivider(ctx, margin, y, rightX);
  y += 26;

  // Final Total
  if (bill.discountLess && bill.discountLess > 0) {
    ctx.textAlign = 'left';
    ctx.font = '600 20px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText('કુલ રકમ:', margin, y);
    ctx.textAlign = 'right';
    ctx.font = '600 22px monospace';
    ctx.fillText(`${Math.round(bill.grossAmount).toLocaleString('en-IN')}`, rightX, y);
    y += 26;

    ctx.textAlign = 'left';
    ctx.font = '600 20px "Noto Sans Gujarati", Arial, sans-serif';
    ctx.fillText('કપાત / લેસ:', margin, y);
    ctx.textAlign = 'right';
    ctx.font = '600 22px monospace';
    ctx.fillText(`-${Math.round(bill.discountLess).toLocaleString('en-IN')}`, rightX, y);
    y += 26;
  }

  ctx.textAlign = 'left';
  ctx.font = 'bold 24px "Noto Sans Gujarati", Arial, sans-serif';
  ctx.fillText('ચોખ્ખી રકમ:', margin, y);

  ctx.textAlign = 'right';
  ctx.font = 'bold 32px monospace';
  ctx.fillText(`${Math.round(bill.finalTotal).toLocaleString('en-IN')}`, rightX, y);
  y += 36;

  drawReceiptDivider(ctx, margin, y, rightX);
  y += 26;

  // Footer Note
  ctx.textAlign = 'center';
  ctx.font = '500 17px monospace';
  ctx.fillText('Computerized Weight Slip & Cash Voucher', width / 2, y);
  y += 24;

  ctx.font = '600 19px "Noto Sans Gujarati", Arial, sans-serif';
  ctx.fillText(settings.footerNote || 'આભાર, ફરી પધારશો!', width / 2, y);
  y += 28;

  const finalHeight = y + 8;
  const trimmed = document.createElement('canvas');
  trimmed.width = width;
  trimmed.height = finalHeight;
  const tCtx = trimmed.getContext('2d');
  if (tCtx) {
    tCtx.fillStyle = '#FFFFFF';
    tCtx.fillRect(0, 0, width, finalHeight);
    tCtx.drawImage(canvas, 0, 0, width, finalHeight, 0, 0, width, finalHeight);
    return trimmed;
  }

  return canvas;
};

/**
 * Converts canvas into ESC/POS Raster Bands.
 * Generates rock-solid 24-line bitmap bands for thermal ESC/POS printers.
 */
export const canvasToEscPosRasterBands = (
  canvas: HTMLCanvasElement,
  bandHeight = 48
): Uint8Array[] => {
  const width = canvas.width;
  const height = canvas.height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return [];

  const imgData = ctx.getImageData(0, 0, width, height);
  const pixels = imgData.data;
  const widthBytes = Math.ceil(width / 8);

  const bands: Uint8Array[] = [];

  for (let startY = 0; startY < height; startY += bandHeight) {
    const currentBandHeight = Math.min(bandHeight, height - startY);
    const rasterBytes = widthBytes * currentBandHeight;

    // Header: GS v 0 0 xL xH yL yH (8 bytes)
    const bandBuffer = new Uint8Array(8 + rasterBytes);
    bandBuffer[0] = 0x1d; // GS
    bandBuffer[1] = 0x76; // v
    bandBuffer[2] = 0x30; // 0
    bandBuffer[3] = 0x00; // mode 0 (normal)
    bandBuffer[4] = widthBytes & 0xff; // xL
    bandBuffer[5] = (widthBytes >> 8) & 0xff; // xH
    bandBuffer[6] = currentBandHeight & 0xff; // yL
    bandBuffer[7] = (currentBandHeight >> 8) & 0xff; // yH

    let offset = 8;
    for (let dy = 0; dy < currentBandHeight; dy++) {
      const y = startY + dy;
      for (let xByte = 0; xByte < widthBytes; xByte++) {
        let byteVal = 0;
        for (let bit = 0; bit < 8; bit++) {
          const x = xByte * 8 + bit;
          if (x < width) {
            const idx = (y * width + x) * 4;
            const r = pixels[idx];
            const g = pixels[idx + 1];
            const b = pixels[idx + 2];
            // High contrast threshold for thermal paper
            const lum = 0.299 * r + 0.587 * g + 0.114 * b;
            if (lum < 170) {
              byteVal |= 0x80 >> bit;
            }
          }
        }
        bandBuffer[offset++] = byteVal;
      }
    }
    bands.push(bandBuffer);
  }

  return bands;
};

/**
 * Legacy single-buffer raster generator for compatibility
 */
export const canvasToEscPosRaster = (canvas: HTMLCanvasElement): Uint8Array => {
  const bands = canvasToEscPosRasterBands(canvas, 24);
  let totalLength = 5; // ESC @ + ESC 3 0
  bands.forEach((b) => (totalLength += b.length));
  totalLength += 6; // ESC 2 + ESC d 4 + GS V 1

  const buffer = new Uint8Array(totalLength);
  let offset = 0;

  // ESC @ (init)
  buffer[offset++] = 0x1b;
  buffer[offset++] = 0x40;
  // ESC 3 0 (0 line space)
  buffer[offset++] = 0x1b;
  buffer[offset++] = 0x33;
  buffer[offset++] = 0x00;

  for (const band of bands) {
    buffer.set(band, offset);
    offset += band.length;
  }

  // Reset line space & feed
  buffer[offset++] = 0x1b;
  buffer[offset++] = 0x32;
  buffer[offset++] = 0x1b;
  buffer[offset++] = 0x64;
  buffer[offset++] = 0x04;
  buffer[offset++] = 0x1d;
  buffer[offset++] = 0x56;
  buffer[offset++] = 0x01;

  return buffer;
};

export interface BluetoothPrintResult {
  success: boolean;
  message: string;
  autoUnpairedInMs?: number;
  autoUnpairedInSeconds?: number;
}

/**
 * Helper to write a small packet safely to the Bluetooth Characteristic.
 * Uses 3.0ms pacing for writeWithoutResponse for smooth continuous printing.
 */
async function sendBleChunk(char: any, chunk: Uint8Array, delayMs = 3.0) {
  let attempts = 0;
  while (true) {
    try {
      // 1. High-speed writeWithoutResponse with 3ms pacing
      if (char.properties?.writeWithoutResponse && char.writeValueWithoutResponse) {
        await char.writeValueWithoutResponse(chunk);
        if (delayMs > 0) {
          await new Promise((res) => setTimeout(res, delayMs));
        }
        return;
      }

      // 2. Fallback if printer only supports write with response
      if (char.writeValueWithResponse) {
        await char.writeValueWithResponse(chunk);
        return;
      } else if (char.writeValue) {
        await char.writeValue(chunk);
        return;
      } else if (char.writeValueWithoutResponse) {
        await char.writeValueWithoutResponse(chunk);
        if (delayMs > 0) {
          await new Promise((res) => setTimeout(res, delayMs));
        }
        return;
      }
      return;
    } catch (err: any) {
      attempts++;
      const msg = String(err?.message || '').toLowerCase();
      const isGattBusy =
        msg.includes('gatt operation already in progress') ||
        msg.includes('networkerror') ||
        err?.name === 'NetworkError';

      if (isGattBusy && attempts <= 5) {
        await new Promise((res) => setTimeout(res, attempts * 30));
        continue;
      }
      throw err;
    }
  }
}

/**
 * Searches the GATT server for the ESC/POS write characteristic.
 * Prioritizes characteristics supporting writeWithoutResponse for continuous, stutter-free streaming.
 */
async function findWriteCharacteristic(server: any): Promise<any> {
  // Phase 1: Search known primary ESC/POS services for writeWithoutResponse
  for (const serviceUuid of PRINTER_SERVICES) {
    try {
      const service = await server.getPrimaryService(serviceUuid);
      const chars = await service.getCharacteristics();
      for (const c of chars) {
        if (c.properties.writeWithoutResponse) {
          return c;
        }
      }
    } catch {}
  }

  // Phase 2: Search known primary services for standard write (with response)
  for (const serviceUuid of PRINTER_SERVICES) {
    try {
      const service = await server.getPrimaryService(serviceUuid);
      const chars = await service.getCharacteristics();
      for (const c of chars) {
        if (c.properties.write) {
          return c;
        }
      }
    } catch {}
  }

  // Phase 3: Fallback across any primary service
  try {
    const services = await server.getPrimaryServices();
    for (const service of services) {
      try {
        const chars = await service.getCharacteristics();
        // First look for fast writeWithoutResponse
        for (const c of chars) {
          if (c.properties.writeWithoutResponse) {
            return c;
          }
        }
        // Then look for write
        for (const c of chars) {
          if (c.properties.write) {
            return c;
          }
        }
      } catch {}
    }
  } catch {}

  return null;
}

/**
 * Connects to device GATT with retries if GATT is temporarily busy
 */
async function safeGattConnect(device: any): Promise<any> {
  if (!device || !device.gatt) {
    throw new Error('બ્લૂટૂથ ડિવાઇસ મળ્યું નથી.');
  }
  if (device.gatt.connected) {
    return device.gatt;
  }
  let attempts = 0;
  while (true) {
    try {
      return await device.gatt.connect();
    } catch (err: any) {
      attempts++;
      const msg = String(err?.message || '').toLowerCase();
      const isGattBusy =
        msg.includes('gatt operation already in progress') ||
        msg.includes('networkerror') ||
        err?.name === 'NetworkError';
      if (isGattBusy && attempts <= 4) {
        await new Promise((res) => setTimeout(res, attempts * 150));
        if (device.gatt?.connected) return device.gatt;
        continue;
      }
      throw err;
    }
  }
}

/**
 * Internal worker for ensuring printer connection
 */
async function ensureConnectedPrinterInternal(
  settings?: FirmSettings,
  onStatusUpdate?: (status: string) => void
): Promise<{ device: any; server: any; writeChar: any }> {
  const preferredName = (settings?.pairedPrinterName || getSavedPairedPrinterName() || 'PSF588').trim();

  // 1. FAST PATH: Already connected! Zero latency, zero prompts!
  if (
    activeBluetoothDevice &&
    activeGattServer &&
    activeGattServer.connected &&
    activeWriteCharacteristic
  ) {
    return {
      device: activeBluetoothDevice,
      server: activeGattServer,
      writeChar: activeWriteCharacteristic,
    };
  }

  const navBt = (navigator as any).bluetooth;

  // 2. RECONNECT PATH: We hold device in memory, just reconnect GATT
  if (activeBluetoothDevice && activeBluetoothDevice.gatt) {
    try {
      onStatusUpdate?.(`${activeBluetoothDevice.name || preferredName} સાથે ફરી કનેક્ટ થઈ રહ્યું છે...`);
      const server = await safeGattConnect(activeBluetoothDevice);
      activeGattServer = server;
      const writeChar = await findWriteCharacteristic(server);
      if (writeChar) {
        activeWriteCharacteristic = writeChar;
        bindDisconnectListener(activeBluetoothDevice);
        startHeartbeat();
        requestWakeLock();
        notifyStatusChange(true);
        return { device: activeBluetoothDevice, server, writeChar };
      }
    } catch (e) {
      console.warn('Memory device reconnect failed:', e);
      activeGattServer = null;
      activeWriteCharacteristic = null;
    }
  }

  // 3. AUTO-PAIR PATH: Query navigator.bluetooth.getDevices() for previously authorized devices!
  if (navBt.getDevices) {
    try {
      const devices = await navBt.getDevices();
      if (devices && devices.length > 0) {
        const match =
          devices.find(
            (d: any) => d.name && d.name.toLowerCase().includes(preferredName.toLowerCase())
          ) ||
          devices.find(
            (d: any) => d.name && preferredName.toLowerCase().includes(d.name.toLowerCase())
          ) ||
          devices.find(
            (d: any) =>
              d.name &&
              (d.name.toLowerCase().includes('psf') ||
                d.name.toLowerCase().includes('588') ||
                d.name.toLowerCase().includes('printer'))
          ) ||
          devices[0];

        if (match && match.gatt) {
          onStatusUpdate?.(`${match.name || preferredName} સાથે ઑટો-કનેક્ટ થઈ રહ્યું છે...`);
          try {
            const server = await safeGattConnect(match);
            activeBluetoothDevice = match;
            activeGattServer = server;
            const writeChar = await findWriteCharacteristic(server);
            if (writeChar) {
              activeWriteCharacteristic = writeChar;
              bindDisconnectListener(match);
              if (match.name) setSavedPairedPrinterName(match.name);
              startHeartbeat();
              requestWakeLock();
              notifyStatusChange(true);
              return { device: match, server, writeChar };
            }
          } catch (autoErr) {
            console.warn('getDevices auto-connect failed:', autoErr);
          }
        }
      }
    } catch (e) {
      console.warn('navBt.getDevices error:', e);
    }
  }

  // 4. FIRST TIME PAIR PATH: User needs to pair PSF588 once in Chrome
  onStatusUpdate?.(`પ્રિન્ટર શોધી રહ્યું છે (${preferredName} પસંદ કરો)...`);
  let device: any = null;
  try {
    device = await navBt.requestDevice({
      acceptAllDevices: true,
      optionalServices: PRINTER_SERVICES,
    });
  } catch (err: any) {
    if (err?.name === 'NotFoundError') {
      throw new Error('કોઈ પ્રિન્ટર પસંદ કરવામાં આવ્યું નથી.');
    }
    if (
      err?.name === 'SecurityError' ||
      String(err?.message || '').toLowerCase().includes('permissions policy') ||
      String(err?.message || '').toLowerCase().includes('disallowed')
    ) {
      throw new Error('IFRAME_PERMISSION_ERROR');
    }
    throw new Error(`બ્લૂટૂથ એરર: ${err?.message || err}`);
  }

  if (!device || !device.gatt) {
    throw new Error('બ્લૂટૂથ ડિવાઇસ મળ્યું નથી.');
  }

  activeBluetoothDevice = device;
  if (device.name) {
    setSavedPairedPrinterName(device.name);
  }

  onStatusUpdate?.(`${device.name || preferredName} સાથે કનેક્ટ થઈ રહ્યું છે...`);
  const server = await safeGattConnect(device);
  activeGattServer = server;

  const writeChar = await findWriteCharacteristic(server);
  if (!writeChar) {
    disconnectBluetoothPrinter();
    throw new Error('આ બ્લૂટૂથ ડિવાઇસમાં પ્રિન્ટ રાઇટ સર્વિસ મળી નથી.');
  }

  activeWriteCharacteristic = writeChar;
  bindDisconnectListener(device);
  startHeartbeat();
  requestWakeLock();
  notifyStatusChange(true);

  return { device, server, writeChar };
}

/**
 * Ensures Bluetooth printer is connected with intelligent Auto-Pair & deduplication
 */
export const ensureConnectedPrinter = async (
  settings?: FirmSettings,
  onStatusUpdate?: (status: string) => void
): Promise<{ device: any; server: any; writeChar: any }> => {
  if (!isWebBluetoothSupported()) {
    throw new Error('તમારા બ્રાઉઝરમાં Web Bluetooth સપોર્ટ નથી. કૃપા કરીને Google Chrome વાપરો.');
  }

  // Fast path: if already connected, return synchronously without lock
  if (
    activeBluetoothDevice &&
    activeGattServer &&
    activeGattServer.connected &&
    activeWriteCharacteristic
  ) {
    return {
      device: activeBluetoothDevice,
      server: activeGattServer,
      writeChar: activeWriteCharacteristic,
    };
  }

  if (pendingConnectPromise) {
    return pendingConnectPromise;
  }

  pendingConnectPromise = runWithBleLock(async () => {
    isConnecting = true;
    try {
      return await ensureConnectedPrinterInternal(settings, onStatusUpdate);
    } finally {
      isConnecting = false;
      pendingConnectPromise = null;
    }
  });

  return pendingConnectPromise;
};

/**
 * Core Canvas Printing Routine over Bluetooth LE:
 * Prints any given canvas via high-speed ESC/POS raster bands.
 */
export const printCanvasViaBluetooth = async (
  canvas: HTMLCanvasElement,
  settings: FirmSettings,
  onStatusUpdate?: (status: string) => void
): Promise<BluetoothPrintResult> => {
  if (!isWebBluetoothSupported()) {
    throw new Error('તમારા બ્રાઉઝરમાં Web Bluetooth સપોર્ટ નથી. કૃપા કરીને Google Chrome વાપરો.');
  }

  return runWithBleLock(async () => {
    isPrinting = true;
    stopHeartbeat();

    try {
      // 1. Ensure connection FIRST so user gesture is preserved for requestDevice()
      const { device, writeChar } = await ensureConnectedPrinterInternal(settings, onStatusUpdate);

      onStatusUpdate?.('પ્રિન્ટ તૈયાર થઈ રહી છે...');
      if (typeof document !== 'undefined' && (document as any).fonts?.ready) {
        try {
          await (document as any).fonts.ready;
        } catch {}
      }

      // 48-line bands provide seamless continuous printing while staying safe from any hardware limits
      const bands = canvasToEscPosRasterBands(canvas, 48);

      onStatusUpdate?.('પ્રિન્ટ થઈ રહી છે...');

      // 1. Quick Hardware Initialize: Flush buffers and prepare printer
      const initCmd = new Uint8Array([0x1b, 0x40]); // ESC @
      await sendBleChunk(writeChar, initCmd, 15);
      await new Promise((res) => setTimeout(res, 25));

      const zeroSpacingCmd = new Uint8Array([0x1b, 0x33, 0x00]); // ESC 3 0 (0 line space)
      await sendBleChunk(writeChar, zeroSpacingCmd, 10);
      await new Promise((res) => setTimeout(res, 10));

      // 2. High-speed smooth printing:
      const RASTER_PACKET_SIZE = 192;
      const totalBands = bands.length;

      for (let bIndex = 0; bIndex < totalBands; bIndex++) {
        const bandData = bands[bIndex];
        const header = bandData.slice(0, 8);
        const rasterBytes = bandData.slice(8);

        // Send header cleanly
        await sendBleChunk(writeChar, header, 2.0);

        // Stream raster data line-aligned (192 bytes = 4 full lines) at fast 3.0ms pacing
        for (let i = 0; i < rasterBytes.length; i += RASTER_PACKET_SIZE) {
          const chunk = rasterBytes.slice(i, i + RASTER_PACKET_SIZE);
          await sendBleChunk(writeChar, chunk, 3.0);
        }

        // Paced inter-band pause (25ms)
        await new Promise((res) => setTimeout(res, 25));
      }

      // 3. Post-print Paper Feed & Cut
      const endCmd = new Uint8Array([
        0x1b, 0x32, // ESC 2 (Reset line feed)
        0x1b, 0x64, 0x02, // ESC d 2 (Feed exactly 2 lines past tear bar)
        0x1d, 0x56, 0x01, // GS V 1 (Cut paper if auto-cutter supported)
      ]);
      for (let i = 0; i < endCmd.length; i += RASTER_PACKET_SIZE) {
        await sendBleChunk(writeChar, endCmd.slice(i, i + RASTER_PACKET_SIZE), 3.0);
      }

      onStatusUpdate?.('કાગળ બહાર આવી રહ્યો છે...');
      await new Promise((res) => setTimeout(res, 50));

      // ⭐️ PERSISTENT CONNECTION LOGIC
      const shouldKeepConnected = settings.keepBluetoothConnected !== false;

      if (shouldKeepConnected) {
        onStatusUpdate?.(`✅ પ્રિન્ટ સફળ! ${device?.name || 'PSF588'} સાથે કનેક્શન ચાલુ છે.`);
        return {
          success: true,
          message: 'પ્રિન્ટ સફળતાપૂર્વક પૂર્ણ થઈ અને પ્રિન્ટર તૈયાર છે!',
        };
      } else {
        const delay = settings.autoDisconnectDelayMs || 150;
        setTimeout(() => {
          disconnectBluetoothPrinter();
        }, delay);
        onStatusUpdate?.('✅ પ્રિન્ટ સફળતાપૂર્વક પૂર્ણ થઈ!');
        return {
          success: true,
          message: 'પ્રિન્ટ સફળતાપૂર્વક પૂર્ણ થઈ અને પ્રિન્ટર મુક્ત થઈ ગયું!',
        };
      }
    } catch (err: any) {
      activeGattServer = null;
      activeWriteCharacteristic = null;
      throw err;
    } finally {
      isPrinting = false;
      startHeartbeat();
    }
  });
};

/**
 * Connects to Bluetooth Thermal Printer (with Auto-Pair & Persistent Connection),
 * prints receipt using fast banded raster chunks, and maintains connection for instant subsequent prints!
 */
export const printReceiptViaBluetooth = async (
  bill: VoucherBill,
  settings: FirmSettings,
  onStatusUpdate?: (status: string) => void
): Promise<BluetoothPrintResult> => {
  if (typeof document !== 'undefined' && (document as any).fonts?.ready) {
    try {
      await (document as any).fonts.ready;
    } catch {}
  }
  const canvas = renderReceiptToCanvas(bill, settings);
  return printCanvasViaBluetooth(canvas, settings, onStatusUpdate);
};

/**
 * Directly prints a Weight Slip (કાંટા વજન પત્રક) with bag-by-bag weights to Bluetooth printer
 */
export const printWeighmentViaBluetooth = async (
  slip: WeighmentSlipData,
  settings: FirmSettings,
  onStatusUpdate?: (status: string) => void
): Promise<BluetoothPrintResult> => {
  if (typeof document !== 'undefined' && (document as any).fonts?.ready) {
    try {
      await (document as any).fonts.ready;
    } catch {}
  }
  const canvas = renderWeighmentToCanvas(slip, settings);
  return printCanvasViaBluetooth(canvas, settings, onStatusUpdate);
};

/**
 * Directly prints a Combined Slip (કાંટા વજન પત્રક + વાઉચર બિલ) to Bluetooth printer
 */
export const printCombinedViaBluetooth = async (
  bill: VoucherBill,
  slip: WeighmentSlipData,
  settings: FirmSettings,
  onStatusUpdate?: (status: string) => void
): Promise<BluetoothPrintResult> => {
  if (typeof document !== 'undefined' && (document as any).fonts?.ready) {
    try {
      await (document as any).fonts.ready;
    } catch {}
  }
  const canvas = renderCombinedReceiptToCanvas(bill, slip, settings);
  return printCanvasViaBluetooth(canvas, settings, onStatusUpdate);
};

/**
 * User-initiated pairing or connecting specifically to PSF588 from Settings
 */
export const pairOrConnectPrinter = async (
  preferredName: string = 'PSF588',
  forcePicker: boolean = false,
  onStatusUpdate?: (status: string) => void
): Promise<{ success: boolean; deviceName: string }> => {
  if (!isWebBluetoothSupported()) {
    throw new Error('તમારા બ્રાઉઝરમાં Web Bluetooth સપોર્ટ નથી.');
  }

  const targetName = (preferredName || getSavedPairedPrinterName() || 'PSF588').trim();
  const navBt = (navigator as any).bluetooth;
  let device: any = null;

  if (!forcePicker && navBt.getDevices) {
    try {
      const paired = await navBt.getDevices();
      if (paired && paired.length > 0) {
        const match =
          paired.find((d: any) => d.name && d.name.toLowerCase().includes(targetName.toLowerCase())) ||
          paired.find((d: any) => d.name && targetName.toLowerCase().includes(d.name.toLowerCase())) ||
          paired[0];
        if (match) {
          device = match;
        }
      }
    } catch {}
  }

  if (!device) {
    onStatusUpdate?.(`પ્રિન્ટર લિસ્ટમાંથી ${targetName} પસંદ કરો...`);
    device = await navBt.requestDevice({
      acceptAllDevices: true,
      optionalServices: PRINTER_SERVICES,
    });
  }

  activeBluetoothDevice = device;
  if (device.name) {
    setSavedPairedPrinterName(device.name);
  }

  onStatusUpdate?.(`${device.name || targetName} સાથે કનેક્ટ કરી રહ્યું છે...`);
  const server = await device.gatt.connect();
  activeGattServer = server;

  const writeChar = await findWriteCharacteristic(server);
  if (!writeChar) {
    disconnectBluetoothPrinter();
    throw new Error('આ પ્રિન્ટરમાં ESC/POS રાઇટ સર્વિસ મળી નથી.');
  }

  activeWriteCharacteristic = writeChar;
  bindDisconnectListener(device);
  startHeartbeat();
  requestWakeLock();
  notifyStatusChange(true);

  onStatusUpdate?.(`✅ ${device.name || targetName} સફળતાપૂર્વક પેર અને કનેક્ટ થઈ ગયું!`);

  return {
    success: true,
    deviceName: device.name || targetName,
  };
};

/**
 * Sends a quick test receipt to PSF588 to verify setup
 */
export const printTestSlipViaBluetooth = async (
  settings: FirmSettings,
  onStatusUpdate?: (status: string) => void
): Promise<boolean> => {
  const testBill: VoucherBill = {
    id: `test_${Date.now()}`,
    billNo: 0,
    billNoStr: '#TEST',
    date: new Date().toISOString().split('T')[0],
    time: new Date().toLocaleTimeString('gu-IN', { hour: '2-digit', minute: '2-digit' }),
    session: 'M',
    customerName: 'ટેસ્ટ પ્રિન્ટ (PSF588 પેરિંગ)',
    items: [
      {
        id: 'test_item_1',
        productId: 'p_test',
        productName: 'PSF588 બ્લૂટૂથ પેરિંગ સફળ',
        productShortcut: 't',
        weightKg: 20,
        ratePer20Kg: 500,
        amount: 500,
      },
    ],
    totalWeightKg: 20,
    totalWeightMan: 1,
    grossAmount: 500,
    discountLess: 0,
    finalTotal: 500,
    createdAt: Date.now(),
  };

  const res = await printReceiptViaBluetooth(testBill, settings, onStatusUpdate);
  return res.success;
};
